/*
Navicat MySQL Data Transfer

Source Server         : IPSCLC
Source Server Version : 50516
Source Host           : localhost:3306
Source Database       : u550095972_nemo

Target Server Type    : MYSQL
Target Server Version : 50516
File Encoding         : 65001

Date: 2018-07-06 08:51:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `ci_sessions`
-- ----------------------------
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_addresss` varchar(45) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ci_sessions
-- ----------------------------

-- ----------------------------
-- Table structure for `tm_articles`
-- ----------------------------
DROP TABLE IF EXISTS `tm_articles`;
CREATE TABLE `tm_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `img` varchar(255) DEFAULT '',
  `upload_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upload_by` int(11) NOT NULL,
  `status` set('0','1','2') NOT NULL DEFAULT '0',
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_articles
-- ----------------------------
INSERT INTO `tm_articles` VALUES ('1', 'Post One', 'post-one', 'Technology professionals, software developers, web designers, and business and creative professionals use Safari Books Online as their primary resource for research, problem solving, learning, and certification training.', 'boss.png', '2017-12-11 06:10:09', '1', '1', '1');
INSERT INTO `tm_articles` VALUES ('2', 'Post Two', 'Post-Two', '<p>I want to thank everyone who helped out in one way or another. My colleagues at the University of Hartford’s Multimedia Web Design and Development program were always helpful when I posed a query of one type or another. Professor John Gray, the epartment chair, was encouraging and helpful as always. Dr. Brian Dorn, my office next-door neighbor, who caught the bulk of my queries, was obliging, knowledgeable, and patient.</p>\r\n', 'plane.png', '2017-12-12 23:59:25', '1', '1', '1');
INSERT INTO `tm_articles` VALUES ('3', 'Post Three', 'Post-Three', '<p>I was fortunate enough to meet Michael Bourque of the Boston PHP group at the in augural Northeast PHP Conference, and appreciate his encouragement for this project. I look forward to working with Michael and the Boston PHP group more in exploring advanced PHP programming.</p>\r\n', 'team.png', '2017-12-13 00:00:13', '1', '1', '2');
INSERT INTO `tm_articles` VALUES ('4', 'Post Four', 'Post-Four', '<p>Slowly but surely, my programming habits began to change. By adding a little OOP here and there and incorporating a design pattern now and again, in time, I didn’t want to program any other way.</p>\r\n', 'tracking.png', '2017-12-13 00:00:17', '1', '0', '2');
INSERT INTO `tm_articles` VALUES ('5', 'Post Five', 'Post-Five', 'Test Post from user role', 'human.jpg', '2017-12-13 12:57:12', '2', '0', '1');

-- ----------------------------
-- Table structure for `tm_categories`
-- ----------------------------
DROP TABLE IF EXISTS `tm_categories`;
CREATE TABLE `tm_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_categories
-- ----------------------------
INSERT INTO `tm_categories` VALUES ('1', 'Business', '0000-00-00 00:00:00');
INSERT INTO `tm_categories` VALUES ('2', 'Technology', '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for `tm_login`
-- ----------------------------
DROP TABLE IF EXISTS `tm_login`;
CREATE TABLE `tm_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(32) NOT NULL,
  `password` text NOT NULL,
  `hash` text,
  `expired` date DEFAULT NULL,
  `verify` set('0','1') NOT NULL DEFAULT '0',
  `role_id` set('1','2') NOT NULL DEFAULT '2',
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_login
-- ----------------------------
INSERT INTO `tm_login` VALUES ('1', 'administrator@ipsclc.com', '$2y$10$jUq/eZ3.gys2d3B7H7oot.kr3aizjRzQ7U7WEfEHwNf4mO0ir4/4K', null, null, '0', '1', '2017-12-12 22:53:17');
INSERT INTO `tm_login` VALUES ('2', 'dummy@ipsclc.com', '$2y$10$QDgcdIK3oIdwNT5uVcl.PeGKz5hkQres.j7QGWAKhSqziVb6XAtZi', null, null, '0', '2', '2017-12-12 22:53:17');
INSERT INTO `tm_login` VALUES ('3', 'wibowo.yosafat@gmail.com', '$2y$10$0tM3YiD6dWWKc6H6ejqP8efP9bAzLt6kG9G2gT/idTUnLiUpjJCKC', null, null, '0', '2', '2018-02-20 13:05:47');
