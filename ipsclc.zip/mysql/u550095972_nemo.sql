/*
Navicat MySQL Data Transfer

Source Server         : IPSCLC
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : u550095972_nemo

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-07-31 19:16:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `ci_sessions`
-- ----------------------------
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_addresss` varchar(45) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ci_sessions
-- ----------------------------

-- ----------------------------
-- Table structure for `tc_login`
-- ----------------------------
DROP TABLE IF EXISTS `tc_login`;
CREATE TABLE `tc_login` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `ttl` varchar(255) DEFAULT NULL,
  `tgl` varchar(255) DEFAULT NULL,
  `address` text,
  `img` varchar(255) DEFAULT 'no_image.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tc_login
-- ----------------------------
INSERT INTO `tc_login` VALUES ('1', 'Administrator', '08568183610', 'Venice', '28/11/85', 'Somewhere I belong street, no 234', 'no_image.jpg');
INSERT INTO `tc_login` VALUES ('2', 'Yoshi', '', '', '', '', 'no_image.jpg');
INSERT INTO `tc_login` VALUES ('3', 'Sintyadi', '', '', '', '', 'no_image.jpg');

-- ----------------------------
-- Table structure for `tc_portfolio`
-- ----------------------------
DROP TABLE IF EXISTS `tc_portfolio`;
CREATE TABLE `tc_portfolio` (
  `id` int(11) NOT NULL,
  `nama_a` varchar(255) DEFAULT NULL,
  `posisi_a` varchar(255) DEFAULT NULL,
  `divisi_a` varchar(255) DEFAULT NULL,
  `start_a` varchar(255) DEFAULT NULL,
  `end_a` varchar(255) DEFAULT NULL,
  `desc_a` text,
  `nama_b` varchar(255) DEFAULT NULL,
  `posisi_b` varchar(255) DEFAULT NULL,
  `divisi_b` varchar(255) DEFAULT NULL,
  `start_b` varchar(255) DEFAULT NULL,
  `end_b` varchar(255) DEFAULT NULL,
  `desc_b` text,
  `nama_c` varchar(255) DEFAULT NULL,
  `posisi_c` varchar(255) DEFAULT NULL,
  `divisi_c` varchar(255) DEFAULT NULL,
  `start_c` varchar(255) DEFAULT NULL,
  `end_c` varchar(255) DEFAULT NULL,
  `desc_c` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tc_portfolio
-- ----------------------------
INSERT INTO `tc_portfolio` VALUES ('1', 'PT.A', 'Manager', 'IT', '12/05/2018', '', 'bla bla bla', 'PT.B', 'Senior', 'IT', '11/03/2015', '11/03/2018', 'bla bla', 'PT.C', 'Junior', 'IT', '11/01/2012', '11/01/2015', 'bla');
INSERT INTO `tc_portfolio` VALUES ('2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `tc_portfolio` VALUES ('3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `tc_portfolio` VALUES ('10', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for `tc_study`
-- ----------------------------
DROP TABLE IF EXISTS `tc_study`;
CREATE TABLE `tc_study` (
  `id` int(11) NOT NULL,
  `nama_a` varchar(255) DEFAULT NULL,
  `jenjang_a` varchar(255) DEFAULT NULL,
  `jurusan_a` varchar(255) DEFAULT NULL,
  `tahun_a` varchar(255) DEFAULT NULL,
  `nilai_a` varchar(255) DEFAULT NULL,
  `nama_b` varchar(255) DEFAULT NULL,
  `jenjang_b` varchar(255) DEFAULT NULL,
  `jurusan_b` varchar(255) DEFAULT NULL,
  `tahun_b` varchar(255) DEFAULT NULL,
  `nilai_b` varchar(255) DEFAULT NULL,
  `nama_c` varchar(255) DEFAULT NULL,
  `jenjang_c` varchar(255) DEFAULT NULL,
  `jurusan_c` varchar(255) DEFAULT NULL,
  `tahun_c` varchar(255) DEFAULT NULL,
  `nilai_c` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tc_study
-- ----------------------------
INSERT INTO `tc_study` VALUES ('1', 'PT.A', '', '', '', '', 'PT.B', '', '', '', '', 'PT.C', '', '', '', '');
INSERT INTO `tc_study` VALUES ('2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `tc_study` VALUES ('3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `tc_study` VALUES ('10', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for `tm_articles`
-- ----------------------------
DROP TABLE IF EXISTS `tm_articles`;
CREATE TABLE `tm_articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `img` varchar(255) DEFAULT 'no_image.png',
  `upload_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upload_by` int(11) NOT NULL,
  `status` set('0','1','2') NOT NULL DEFAULT '0',
  `category_id` int(11) DEFAULT NULL,
  `tags` text,
  `reason` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_articles
-- ----------------------------
INSERT INTO `tm_articles` VALUES ('1', 'PHP', 'PHP', '<p>PHP is a server scripting language, and a powerful tool for making dynamic and interactive Web pages.</p>', 'b3683ad50bac059a9a1cf9eac85fb80f.jpg', '2018-07-30 20:15:07', '1', '1', null, 'php, code', null);
INSERT INTO `tm_articles` VALUES ('3', 'Post Three', 'Post-Three', '<p>I was fortunate enough to meet Michael Bourque of the Boston PHP group at the in augural Northeast PHP Conference, and appreciate his encouragement for this project. I look forward to working with Michael and the Boston PHP group more in exploring advanced PHP programming.</p>\r\n', 'no_image.png', '2017-12-07 12:48:08', '3', '1', null, 'php, code', null);
INSERT INTO `tm_articles` VALUES ('4', 'Post Four', 'Post-Four', '<p>Slowly but surely, my programming habits began to change. By adding a little OOP here and there and incorporating a design pattern now and again, in time, I didn’t want to program any other way.</p>\r\n', 'no_image.png', '2018-07-31 18:10:11', '3', '1', null, 'php, code', 'too slow');
INSERT INTO `tm_articles` VALUES ('6', 'sdsad', 'sdsad', '<p>dsdasd</p>', '0b2ba6e83c9b5131b47ffbd47e545cec.jpg', '2018-07-31 18:10:09', '3', '1', null, 'php, code', null);

-- ----------------------------
-- Table structure for `tm_categories`
-- ----------------------------
DROP TABLE IF EXISTS `tm_categories`;
CREATE TABLE `tm_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_categories
-- ----------------------------
INSERT INTO `tm_categories` VALUES ('1', 'Business', '0000-00-00 00:00:00');
INSERT INTO `tm_categories` VALUES ('2', 'Technology', '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for `tm_login`
-- ----------------------------
DROP TABLE IF EXISTS `tm_login`;
CREATE TABLE `tm_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(32) NOT NULL,
  `password` text NOT NULL,
  `hash` text,
  `expired` date DEFAULT NULL,
  `verify` set('0','1') NOT NULL DEFAULT '0',
  `role_id` set('1','2') NOT NULL DEFAULT '2',
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_login
-- ----------------------------
INSERT INTO `tm_login` VALUES ('1', 'administrator@ipsclc.com', '$2y$10$jUq/eZ3.gys2d3B7H7oot.kr3aizjRzQ7U7WEfEHwNf4mO0ir4/4K', null, null, '0', '1', '2017-12-12 22:53:17');
INSERT INTO `tm_login` VALUES ('2', 'wibowo.yosafat@gmail.com', '$2y$10$jUq/eZ3.gys2d3B7H7oot.kr3aizjRzQ7U7WEfEHwNf4mO0ir4/4K', null, null, '0', '1', '2018-07-21 04:47:49');
INSERT INTO `tm_login` VALUES ('3', 'dummy@ipsclc.com', '$2y$10$jUq/eZ3.gys2d3B7H7oot.kr3aizjRzQ7U7WEfEHwNf4mO0ir4/4K', null, null, '0', '2', '2018-07-21 04:48:02');

-- ----------------------------
-- Table structure for `tm_news`
-- ----------------------------
DROP TABLE IF EXISTS `tm_news`;
CREATE TABLE `tm_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `img` varchar(255) DEFAULT NULL COMMENT 'no_image.png',
  `upload_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `upload_by` int(11) NOT NULL,
  `short` varchar(255) DEFAULT NULL,
  `tags` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_news
-- ----------------------------
INSERT INTO `tm_news` VALUES ('1', 'Rekrutan Baru Liverpool Akan Bikin Para Fans Senang', 'rekrutan-baru-liverpool-akan-bikin-para-fans-senang', 'Jakarta - Liverpool sudah mendatangkan beberapa pemain top. Aktivitas The Reds, utamanya outfield player, dinilai sudah mampu menyenangkan fans.\r\n\r\nDi bursa transfer musim panas 2018, Liverpool sudah mendatangkan empat pemain. Rinciannya satu kiper dan tiga pemain di posisi lainnya.\r\n\r\nAlisson Becker merupakan pembelian termahal dengan tebusan 67 juta pound sterling. Selain itu ada Naby Keita, Fabinho, dan Xherdan Shaqiri.\r\n\r\nFullback Liverpool, Alberto Moreno, meyakini bahwa para pemain baru Si Merah itu akan mampu membawa mereka menjalani musim yang luar biasa.', 'no_image.png', '2018-07-31 12:19:58', '1', 'Rekutan Baru Liverpool', 'liverpool');
INSERT INTO `tm_news` VALUES ('2', 'Bukan Ruud Gullit, Ini Tahith Chong Pemain Masa Depan MU', 'bukan-ruud-gullit-ini-tahith-chong-pemain-masa-depan-mu', 'Los Angeles - Mulai musim depan, fans Manchester United bakal sering melihat penampakan Ruud Gullit. Tapi bukan Gullit beneran, melainkan pemain asal Belanda Tahit Chong.\r\n\r\nNama Chong menjadi buah bibir setelah tampil impresif saat MU menghadapi Club America pada laga persahabatan kemarin. Main selama 30 menit, ia terlihat menonjol sebagai pemain sayap.\r\n\r\nPuncaknya adalah ketika Chong memberikan umpan tarik yang dimanfaatkan oleh Juan Mata untuk menjadi gol penyama kedudukan. Tak cuma soal performanya, Chong menarik perhatian karena gaya rambut gondrong keriting mirip Gullit yang sama-sama berasal dari Belanda.\r\n\r\n\r\nLalu siapa sebenarnya Chong? Kenapa dia tiba-tiba ada di skuat utama MU pada laga pramusim tersebut?\r\n\r\nPemain 18 tahun itu direkrut dari Feyeenord pada 2016 dan langsung menjadi bagian tim U-18 MU yang dipimpin Kieran McKenna. Sempat mengalami cedera parah dan absen 10 bulan, kiprah pemain kelahiran 4 Desember 1999 ini terus menanjak.\r\n\r\nChong adalah pemain kidal yang bisa biasa bermain di sayap kiri. Tapi, pada debutnya di MU U-23 ia dijadikan sayap kanan. Terlepas dari itu, pergerakan sang pemain terbilang apik dalam penyerangan dan cukup fleksibel.\r\n\r\nPerforma apik Chong membuatnya menjadi pemain terbaik MU U-23 pada akhir musim lalu mengalahkan Lee O\'Connor dan James Garner.\r\n\r\nMenurut Manchester Evening News, Jose Mourinho sudah mengonfirmasi bahwa Chong akan berlatih bersama tim utama pada musim depan. Ia sepertinya akan menjadi opsi sayap MU yang terbilang tak cukup dalam.\r\n\r\n\r\nSeperti diketahui, MU tak memiliki sayap murni musim lalu. Hanya Alexis Sanchez yang terbilang terbiasa main di sana, sementara Marcus Rashford dan Anthony Martial sejatinya adalah striker, sedangkan Juan Mata merupakan playmaker.\r\n\r\nSayap murni MU malah berubah posisi dan jadi andalan di pos full-back yakni Ashley Young dan Antonio Valencia. Tak ayal, Chong bisa menjadi opsi menarik di posisi tersebut.\r\n\r\n\"Menjadi mimpi untuk semua orang di ruang ganti bermain bersama tim utama. Tapi, kami masih fokus dan bekerja keras untuk berada di sana. Tapi ya, ini mimpi,\" ujar Chong.\r\n\r\nMourinho pun memberikan pujian kepada Chong setelah laga MU melawan Club America. Menurutnya Chong adalah opsi yang baik walau belum bisa dibilang sempurna.\r\n\r\n\"Aksinya saat melakukan umpan tarik sebelum gol sangat cantik. Dia sangat antusias dan punya kepercayaan diri dalam bermain. Jelas dia punya keterbatasan terkait fisik, dia kerap terjatuh saat disenggol lawan dan kalah saat kontak badan. Tapi, kualitasnya terlihat ketika dia bisa menggerakkan bola dan menyerang lawan satu lawan satu. Dia adalah pemain yang bagus,\" tutur Mourinho.', 'no_image.png', '2018-07-31 12:19:56', '1', 'Bukan Ruud Gullit', 'ruud gullit');
INSERT INTO `tm_news` VALUES ('3', 'Pesta Juara Dunia Griezmann di Kampung Halaman', 'pesta-juara-dunia-griezmann-di-kampung-halaman', 'Macon Sepakbola - Antoine Griezmann jadi pahlawan Prancis saat jadi juara Piala Dunia 2018. Penyerang 26 tahun itu pun merayakan pesta juara di kampung halaman.', 'no_image.png', '2018-07-31 12:19:55', '3', '', 'juara dunia');
INSERT INTO `tm_news` VALUES ('4', 'Spalletti Yakin Icardi dan Perisic Bakal Bertahan', 'spalletti-yakin-icardi-dan-perisic-bakal-bertahan', 'Sion - Pelatih Inter Milan, Luciano Spalletti, yakin betul dua pemain andalannya Ivan Perisic dan Mauro Icardi, tak akan hengkang musim panas ini.\r\n\r\nMasa depan dua pemain itu memang gencar dispekulasikan. Perisic yang baru melewati performa gemilang di Piala Dunia 2018 kembali dihubungkan dengan Manchester United.\r\n\r\nSedangkan sang kapten Icardi dirumorkan menjadi incaran Real Madrid yang baru saja kehilangan Cristiano Ronaldo. El Real memang masih mencari sosok andalan baru yang tepat untuk jadi andalan di lini depan.\r\n\r\nMelihat kondisi keuangan kedua klub itu dan juga statusnya saat ini, Inter patut was-was dua pemain topnya itu sewaktu-waktu bisa menerima pinangan dan pergi.\r\n\r\nMeski begitu, Spalletti nyatanya tak takut dengan spekulasia tersebut.. Dia mengklaim Icardi dan Perisic sudah memberikan sinyal kuat untuk bertahan di Giuseppe Meazza musim depan.\r\n\r\n\r\n\"Mereka adalah pemain profesional yang luar biasa, menjadi pemain andalan, dan mewakili karakter kuat tim ini ,\" ujar Spalletti kepada Rai yang dilansir Football Italia.\r\n\r\n\"Lolos ke Liga Champions memberikan stimulus baru bagi tim. Kekompakan para pemain sudah sering jadi senjata andalan tim. Untuk alasan ini, saya punya tim yang solid saat ini,\" sambungnya.\r\n\r\n\"Saya sudah berbicara dengan Ivan. Dia kelelahan dan sedang beristirahat. Setelah itu dia akan kembali dengan. Dia tak memberikan sinyal apapun untuk hengkang, sama seperti Mauro.\"\r\n\r\n\"Sangat jelas dia (Icardi) ingin memperpanjang kontrak. Semua sinyal yang ada sangat positif. Mereka pasti bertahan,\" tandas pelatih berkepala plontos tersebut.\r\n', 'no_image.png', '2018-07-31 12:19:54', '2', '', 'spalleti');
INSERT INTO `tm_news` VALUES ('5', 'Andre Schuerrle Menuju Pintu Keluar Dortmund', 'Andre-Schuerrle-Menuju-Pintu-Keluar-Dortmund', '<p>Chicago - Borussia Dortmund tak lagi membutuhkan tenaga Andre Schuerrle. Penyerang berusia 27 tahun itu kini sedang mengurus kepindahannya ke klub lain. Schuerrle tak dilibatkan saat Dortmund mengalahkan Manchester City 1-0 di ajang International Champions Cup yang dilangsungkan di Soldier Field, Chicago, Amerika Serikat, Sabtu (21/7/2018) pagi WIB. Seusai pertandingan, Dortmund mengonfirmasi bahwa Schuerrle absen karena sedang melakukan negosiasi dengan klub lain. Akan tetapi, klub lain yang dimaksud Dortmund masih dirahasiakan.</p>', 'c1d44fe63eae5deee27cb3ddb4c6127d.jpg', '2018-07-30 15:06:46', '1', 'Andre Schuerrle', 'andre');

-- ----------------------------
-- Table structure for `tm_portfolio`
-- ----------------------------
DROP TABLE IF EXISTS `tm_portfolio`;
CREATE TABLE `tm_portfolio` (
  `id` int(11) NOT NULL,
  `desc` text,
  `course` text,
  `total` varchar(255) DEFAULT NULL,
  `study` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tm_portfolio
-- ----------------------------
INSERT INTO `tm_portfolio` VALUES ('1', 'Deskripsimu', 'Pilihanku', '32', 'Dimana-Manamu');
INSERT INTO `tm_portfolio` VALUES ('2', null, null, null, null);
INSERT INTO `tm_portfolio` VALUES ('3', 'aaaa', 'aaa', '21212', '123213');
INSERT INTO `tm_portfolio` VALUES ('10', null, null, null, null);

-- ----------------------------
-- View structure for `v`
-- ----------------------------
DROP VIEW IF EXISTS `v`;
CREATE ALGORITHM=UNDEFINED DEFINER=`u550095972_holy`@`localhost` SQL SECURITY DEFINER VIEW `v` AS select count(`tm_articles`.`upload_by`) AS `total` from `tm_articles` where (`tm_articles`.`status` = '1') group by `tm_articles`.`upload_by` ;
