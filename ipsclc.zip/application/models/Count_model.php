<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Count_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function submitted() {

		$this->db->select('COUNT(id) as total');
		$this->db->where('upload_by', $_SESSION['user_id']); 
		$query = $this->db->get('tm_articles');

		return $query->row();
	}

	public function approved() {
		
		$this->db->select('COUNT(id) as total');
		$this->db->where('upload_by', $_SESSION['user_id']); 
		$this->db->where('status', '1'); 
		$query = $this->db->get('tm_articles');

		return $query->row();

	}

	public function rank() {

		$this->db->query("DROP VIEW v");
		$this->db->query("CREATE VIEW v AS SELECT count(upload_by) AS total 
									FROM tm_articles
									WHERE status = '1'
									GROUP BY upload_by");

		$query = $this->db->query("SELECT @rownum:=@rownum+1 total 
									FROM v,(SELECT @rownum:=0) r
									ORDER BY total DESC");

		return $query->row();
		
	}

	public function whole() {
		
		$this->db->select('COUNT(id) as total');
		$this->db->where('status', '1'); 
		$query = $this->db->get('tm_articles');

		return $query->row();

	}

}