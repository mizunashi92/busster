<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function login($email) {

		$result = $this->db->select('id, password, role_id')
						   ->get_where('tm_login', array('email' => $email));
		
		if($result->num_rows() == 1) {

			return $result->row();

		} else {

			return FALSE;

		}

	}

	public function register($enc_password) {
		
		$data = array(
			'email' => $this->input->post('email',TRUE),
			'password' => $enc_password,
			'verify' => '0',
			'role_id' => '2'
		);
		
		$this->db->insert('tm_login', $data);

		$last_id = $this->db->insert_id();
		$tc_log = array('id' => $last_id);
		$this->db->insert('tc_study',$tc_log);
		$this->db->insert('tc_portfolio',$tc_log);
		$this->db->insert('tm_portfolio',$tc_log);
		return  $this->db->insert('tc_login',$tc_log);

	}

	public function check_email_exists($email) {

		$query = $this->db->get_where('tm_login', array('email' => $email));

		if(empty($query->row())){

			return TRUE;

		} else {

			return FALSE;

		}
	}

	public function read_profile() {

		$this->db->select('email,name,phone,ttl,tgl,address,img');
		$this->db->join('tm_login', 'tm_login.id = tc_login.id');
		$query = $this->db->get_where('tc_login',array('tc_login.id' => $_SESSION['user_id']));

		return $query->row_array();

	}

	public function update_profile($post_image) {

		$this->db->set('email', $this->input->post('email'));
		$this->db->where('id', $_SESSION['user_id']);
		$this->db->update('tm_login');
		
		$data = array(
					'name' => $this->input->post('name'),
					'phone' => $this->input->post('phone'),
					'ttl' => $this->input->post('ttl'),
					'tgl' => $this->input->post('tgl'),
					'address' => $this->input->post('address'),
					'img' => $post_image
				);

		$this->db->where('id', $_SESSION['user_id']);
		
		return $this->db->update('tc_login', $data);

	}

}