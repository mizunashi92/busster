<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function login($email) {

		$result = $this->db->select('id, password, role_id')
						   ->get_where('tm_login', array('email' => $email));
		
		if($result->num_rows() == 1) {

			return $result->row();

		} else {

			return FALSE;

		}

	}

	public function register($enc_password) {

		$data = array(
			'email' => $this->input->post('email',TRUE),
			'password' => $enc_password,
			'verify' => '0',
			'role_id' => '2'
		);
	
		return $this->db->insert('tm_login', $data);

	}

	public function check_email_exists($email) {

		$query = $this->db->get_where('tm_login', array('email' => $email));

		if(empty($query->row())){

			return TRUE;

		} else {

			return FALSE;

		}
	}

}