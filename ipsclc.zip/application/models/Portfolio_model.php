<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Portfolio_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function read_portfolio() {

		//$this->db->select('desc,course');
		$this->db->join('tc_study', 'tm_portfolio.id = tc_study.id');
		$this->db->join('tc_portfolio', 'tm_portfolio.id = tc_portfolio.id');
		$query = $this->db->get_where('tm_portfolio',array('tm_portfolio.id' => $_SESSION['user_id']));

		return $query->row_array();

	}

	public function update_portfolio() {

		$this->db->set('nama_a', $this->input->post('nama_a'));
		$this->db->set('posisi_a', $this->input->post('posisi_a'));
		$this->db->set('divisi_a', $this->input->post('divisi_a'));
		$this->db->set('start_a', $this->input->post('start_a'));
		$this->db->set('end_a', $this->input->post('end_a'));
		$this->db->set('desc_a', $this->input->post('desc_a'));
		$this->db->set('nama_b', $this->input->post('nama_b'));
		$this->db->set('posisi_b', $this->input->post('posisi_b'));
		$this->db->set('divisi_b', $this->input->post('divisi_b'));
		$this->db->set('start_b', $this->input->post('start_b'));
		$this->db->set('end_b', $this->input->post('end_b'));
		$this->db->set('desc_b', $this->input->post('desc_b'));
		$this->db->set('nama_c', $this->input->post('nama_c'));
		$this->db->set('posisi_c', $this->input->post('posisi_c'));
		$this->db->set('divisi_c', $this->input->post('divisi_c'));
		$this->db->set('start_c', $this->input->post('start_c'));
		$this->db->set('end_c', $this->input->post('end_c'));
		$this->db->set('desc_c', $this->input->post('desc_c'));
		$this->db->where('id', $_SESSION['user_id']);
		$this->db->update('tc_portfolio');

		$this->db->set('nama_a', $this->input->post('nama_a'));
		$this->db->set('jenjang_a', $this->input->post('jenjang_a'));
		$this->db->set('jurusan_a', $this->input->post('jurusan_a'));
		$this->db->set('tahun_a', $this->input->post('tahun_a'));
		$this->db->set('nilai_a', $this->input->post('nilai_a'));
		$this->db->set('nama_b', $this->input->post('nama_b'));
		$this->db->set('jenjang_b', $this->input->post('jenjang_b'));
		$this->db->set('jurusan_b', $this->input->post('jurusan_b'));
		$this->db->set('tahun_b', $this->input->post('tahun_b'));
		$this->db->set('nilai_b', $this->input->post('nilai_b'));
		$this->db->set('nama_c', $this->input->post('nama_c'));
		$this->db->set('jenjang_c', $this->input->post('jenjang_c'));
		$this->db->set('jurusan_c', $this->input->post('jurusan_c'));
		$this->db->set('tahun_c', $this->input->post('tahun_c'));
		$this->db->set('nilai_c', $this->input->post('nilai_c'));
		$this->db->where('id', $_SESSION['user_id']);
		$this->db->update('tc_study');
		
		$this->db->set('desc', $this->input->post('desc'));
		$this->db->set('course', $this->input->post('course'));
		$this->db->set('total', $this->input->post('total'));
		$this->db->set('study', $this->input->post('study'));
		$this->db->where('id', $_SESSION['user_id']);

		return $this->db->update('tm_portfolio', $data);

	}

}