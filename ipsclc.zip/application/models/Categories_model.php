<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function read() {

		$query = $this->db->select('*')
						  ->from('tm_categories')
						  ->order_by('name')
						  ->get();

		$result = $query->result();

		if(isset($result)) {

			return $result;
		}
	
	}


	public function create_category() {

		$data = array('name' => $this->input->post('name',TRUE));

		return $this->db->insert('tm_categories', $data);
	
	}

}