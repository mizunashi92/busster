<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Articles_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function notVerify() {
		$query = $this->db->select('*')
						  ->from('tm_articles')
						  ->where('status','0')
						  ->count_all_results();

		$row = $query;

		if(isset($row)) {

			return $row;
		}
	}

	public function read($slug = FALSE) {

		if($slug === FALSE) {

			$query = $this->db->get_where('tm_articles', array('status' => '0'));

			return $query->result();

		} else {

			$query = $this->db->get_where('tm_articles', array('status' => '0', 'slug' => $slug));

			return $query->row();

		}

	}

	public function approve($id) {

		$data = array('status' => '1');
		$this->db->where('id',$id);
		
		return $this->db->update('tm_articles',$data);
	}

	public function feedback() {

		$data = array('status' => '2', 
					  'reason' => $this->input->post('reason'));	
		$this->db->where('id', $this->input->post('id'));

		return $this->db->update('tm_articles',$data);
	}
	

}