<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News_model extends CI_Model {
	
	public function get_all_news() {

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_news.id,
										tm_news.title,
										tm_news.slug,
										tm_news.content,
										tm_news.img,
										tm_news.upload_on,
										tm_news.upload_by,
										tm_news.tags,
										tc_login.name,
										tm_news.short,
										tc_login.img as `dp`
										FROM tm_news
										INNER JOIN tm_login ON tm_news.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										ORDER BY tm_news.upload_on DESC");
	
		return $query->result_array();
		
	}

	function get_page_news($limit, $start){

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_news.id,
										tm_news.title,
										tm_news.slug,
										tm_news.content,
										tm_news.img,
										tm_news.upload_on,
										tm_news.upload_by,
										tm_news.tags,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_news
										INNER JOIN tm_login ON tm_news.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										ORDER BY tm_news.upload_on DESC
										LIMIT $start, $limit");
        
        
		return $query->result_array();
    }

	public function get_news_by_periode($slug, $limit, $start){

		

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_news.id,
										tm_news.title,
										tm_news.slug,
										tm_news.content,
										tm_news.img,
										tm_news.upload_on,
										tm_news.upload_by,
										tm_news.tags,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_news
										INNER JOIN tm_login ON tm_news.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										WHERE upload_on LIKE '$slug%'
										ORDER BY tm_news.upload_on DESC
										LIMIT $start, $limit");
		
		return $query->result_array();

	}

	public function get_news_by_tags($slug, $limit, $start){

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_news.id,
										tm_news.title,
										tm_news.slug,
										tm_news.content,
										tm_news.img,
										tm_news.upload_on,
										tm_news.upload_by,
										tm_news.tags,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_news
										INNER JOIN tm_login ON tm_news.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										WHERE tags LIKE '%$slug%'
										ORDER BY tm_news.upload_on DESC
										LIMIT $start, $limit");
		
		return $query->result_array();

	}

	public function get_news($slug) {

		$this->db->where('slug', $slug);
		$query = $this->db->get('tm_news');

		return $query->row();
		
	}

	public function create_news($post_image) {

		$slug = url_title($this->input->post('title',TRUE));

		$data = array(
			'title' => $this->input->post('title',TRUE),
			'slug' => $slug,
			'content' => $this->input->post('content',TRUE),
			'img' => $post_image,
			'upload_by' => $_SESSION['user_id'],
			'short' => $this->input->post('short',TRUE),
			'tags' => $this->input->post('tags',TRUE),
			'upload_on' => date('Y-m-d H:i:s'));

		return $this->db->insert('tm_news', $data);

	}

	public function update_news($post_image) {

		$slug = url_title($this->input->post('title',TRUE));

		$data = array(
			'title' => $this->input->post('title',TRUE),
			'slug' => $slug,
			'content' => $this->input->post('content',TRUE),
			'img' => $post_image,
			'short' => $this->input->post('short',TRUE),
			'tags' => $this->input->post('tags',TRUE),
			'upload_on' => date('Y-m-d H:i:s'));

		$this->db->where('id',$this->input->post('id',TRUE));
		
		return $this->db->update('tm_news', $data);

	}

	public function delete_news($id) {

		$this->db->where('id', $id);
		$this->db->delete('tm_news');

		return TRUE;
	}

	public function yearArchieve() {

		$query = $this->db->query("SELECT YEAR(upload_on) as `year` FROM tm_news GROUP BY YEAR(upload_on) ORDER BY upload_on DESC");
		
		return $query->result();
	}

}