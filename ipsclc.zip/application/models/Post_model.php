<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function get_posts($slug = FALSE) {

		if($slug === FALSE) {

			$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags,
										tm_articles.reason,
										tm_articles.status,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										WHERE tm_articles.status = '1'
										ORDER BY tm_articles.upload_on DESC");
			return $query->result();

		}

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags,
										tm_articles.reason,
										tm_articles.status
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										WHERE tm_articles.status = '1'
										AND tm_articles.slug = '$slug'");
		return $query->row();
	
	}

	public function get_page_posts($limit, $start) {

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags,
										tm_articles.reason,
										tm_articles.status,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										WHERE tm_articles.status = '1'
										ORDER BY tm_articles.upload_on DESC
										LIMIT $start, $limit");

		return $query->result();

	}
	public function get_posts_by_periode($slug, $limit, $start){

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags,
										tm_articles.reason,
										tm_articles.status,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										WHERE tm_articles.status = '1'
										AND upload_on LIKE '$slug%'
										ORDER BY tm_articles.upload_on DESC
										LIMIT $start, $limit");
		
		return $query->result();

	}


	public function get_posts_by_tags($slug, $limit, $start){

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags,
										tm_articles.reason,
										tm_articles.status,
										tc_login.name,
										tc_login.img as `dp`
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tc_login ON tm_login.id = tc_login.id
										WHERE tm_articles.status = '1'
										AND tags LIKE '%$slug%'
										ORDER BY tm_articles.upload_on DESC
										LIMIT $start, $limit");
		
		return $query->result();

	}

	public function get_my_posts($slug = FALSE) {

		if($slug === FALSE) {

			$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags,
										tm_articles.status,
										tm_articles.reason
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										WHERE tm_articles.upload_by = '$_SESSION[user_id]'
										ORDER BY tm_articles.upload_on DESC");
			return $query->result();

		}

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.status
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										WHERE tm_articles.upload_by = '$_SESSION[user_id]'
										AND tm_articles.slug = '$slug'");
		return $query->row();
	
	}

	public function get_rejected_post($slug) {

			$query = $this->db->query("SELECT
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_articles.tags
										FROM tm_articles
										WHERE tm_articles.slug = '$slug'");
			return $query->row();

	}

	public function create_post($post_image) {

		$slug = url_title($this->input->post('title',TRUE));

		$data = array(
			'title' => $this->input->post('title',TRUE),
			'slug' => $slug,
			'content' => $this->input->post('content',TRUE),
			'img' => $post_image,
			'upload_by' => $_SESSION['user_id'],
			'status' => '0',
			'tags' => $this->input->post('tags',TRUE),
			'upload_on' => date('Y-m-d H:i:s'));

		return $this->db->insert('tm_articles', $data);

	}

	public function delete_post($id) {

		$this->db->where('id', $id);
		$this->db->delete('tm_articles');

		return TRUE;
	}

	public function update_post($post_image) {

		$slug = url_title($this->input->post('title',TRUE));

		$data = array(
			'title' => $this->input->post('title',TRUE),
			'slug' => $slug,
			'content' => $this->input->post('content',TRUE),
			'status' => '0',
			'img' => $post_image,
			'tags' => $this->input->post('tags',TRUE),
			'upload_on' => date('Y-m-d H:i:s'));

		$this->db->where('id',$this->input->post('id',TRUE));
		
		return $this->db->update('tm_articles', $data);

	}

	public function get_categories() {

		$this->db->order_by('name');
		$query = $this->db->get('tm_categories');

		return $query->result();
	
	}

	public function yearArchieve() {

		$query = $this->db->query("SELECT YEAR(upload_on) as `year` FROM tm_articles GROUP BY YEAR(upload_on) ORDER BY upload_on DESC");
		
		return $query->result();
	}


}