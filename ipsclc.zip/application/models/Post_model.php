<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function get_posts($slug = FALSE) {

		if($slug === FALSE) {

			$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_categories.name
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tm_categories ON tm_articles.category_id = tm_categories.id
										WHERE tm_articles.status = '1'
										ORDER BY tm_articles.id DESC");
			return $query->result();

		}

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.upload_by,
										tm_categories.name
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tm_categories ON tm_articles.category_id = tm_categories.id
										WHERE tm_articles.status = '1'
										AND tm_articles.slug = '$slug'");
		return $query->row();
	
	}

	public function get_my_posts($slug = FALSE) {

		if($slug === FALSE) {

			$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.status,
										tm_categories.name
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tm_categories ON tm_articles.category_id = tm_categories.id
										WHERE tm_articles.upload_by = '$_SESSION[user_id]'
										ORDER BY tm_articles.id DESC");
			return $query->result();

		}

		$query = $this->db->query("SELECT
										tm_login.email,
										tm_articles.id,
										tm_articles.title,
										tm_articles.slug,
										tm_articles.content,
										tm_articles.img,
										tm_articles.upload_on,
										tm_articles.status,
										tm_categories.name
										FROM tm_articles
										INNER JOIN tm_login ON tm_articles.upload_by = tm_login.id
										INNER JOIN tm_categories ON tm_articles.category_id = tm_categories.id
										WHERE tm_articles.upload_by = '$_SESSION[user_id]'
										AND tm_articles.slug = '$slug'");
		return $query->row();
	
	}

	public function create_post($post_image) {

		$slug = url_title($this->input->post('title',TRUE));

		$data = array(
			'title' => $this->input->post('title',TRUE),
			'slug' => $slug,
			'content' => $this->input->post('content',TRUE),
			'img' => $post_image,
			'upload_by' => '2',
			'status' => '0',
			'category_id' => $this->input->post('category_id',TRUE));

		return $this->db->insert('tm_articles', $data);

	}

	public function delete_post($id) {

		$this->db->where('id', $id);
		$this->db->where('upload_by',$_SESSION['user_id']);
		$this->db->delete('tm_articles');

		return TRUE;
	}

	public function update_post() {

		$slug = url_title($this->input->post('title',TRUE));

		$data = array(
			'title' => $this->input->post('title',TRUE),
			'slug' => $slug,
			'content' => $this->input->post('content',TRUE),
			'status' => '0',
			'category_id' => $this->input->post('category_id',TRUE));

		$this->db->where('upload_by',$_SESSION['user_id']);
		$this->db->where('id',$this->input->post('id',TRUE));
		
		return $this->db->update('tm_articles', $data);

	}

	public function get_categories() {

		$this->db->order_by('name');
		$query = $this->db->get('tm_categories');

		return $query->result();
	
	}

}