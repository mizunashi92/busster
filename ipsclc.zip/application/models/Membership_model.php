<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Membership_model extends CI_Model {

	public function __construct() {

		parent::__construct();

	}

	public function validate($email) {

		$query 	= $this->db->select('email,password,role_id,id')
							->from('tm_login')
							->where('email', $email)
							->get();

		$row 	=   $query->row();

		if(isset($row)){

			return $row;
		
		}
	
	}

	public function read() {
		$query 	= $this->db->select('*')
							->from('tm_login')
							->order_by('role_id','ASC')
							->get();

		$result 	=   $query->result();

		if(isset($result)){

			return $result;
		
		}

	}

}