<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	public function __construct() {

		parent::__construct();
		
		if($_SESSION['role_id'] != 1 AND $_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}
		
	}

	public function index($slug = FALSE) {

		$data['submitted'] = $this->Count_model->submitted(); 
		$data['approved'] = $this->Count_model->approved(); 
		$data['rank'] = $this->Count_model->rank(); 
		$data['whole'] = $this->Count_model->whole(); 
		$data['news'] = $this->News_model->get_all_news();
		$data['approval'] = $this->Articles_model->read($slug);
		//print_r($data['approval']);
		$this->load->view('xpanel/header');
		$this->load->view('xpanel/admin/index',$data);
		$this->load->view('xpanel/footer');

	}

	public function read($slug = FALSE) {

		$data['news'] = $this->News_model->get_news($slug);
	
		if(empty($data['news'])){
			show_404();
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/admin/read',$data);
		$this->load->view('xpanel/footer');

	}

	public function create() {

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/admin/create');
		$this->load->view('xpanel/footer');

	}

	public function doCreate() {

		$this->form_validation->set_rules('title','Title','trim|required|min_length[1]|max_length[254]');
		$this->form_validation->set_rules('short','Short','trim|required|min_length[1]|max_length[254]');
		$this->form_validation->set_rules('content','Content','trim|required|min_length[1]|max_length[4999]');
		$this->form_validation->set_rules('tags','Tags','trim|max_length[4999]');

		if($this->form_validation->run() === FALSE) {
			
			$this->load->view('xpanel/header');
			$this->load->view('xpanel/admin/create');
			$this->load->view('xpanel/footer');

		}else{
			
			#Picture
			$config['upload_path']          = './assets/news/';
	        $config['allowed_types']        = 'gif|jpg|jpeg|png';
	        $config['max_size']             = 2048;
	        $config['max_width']            = 1024;
	        $config['max_height']           = 768;
	        $config['file_ext_tolower']		= TRUE;
	        $config['remove_spaces']		= TRUE;
	        $config['detect_mime']			= TRUE;
	        $config['encrypt_name']			= TRUE;	

	        $this->load->library('upload', $config);
	      
	        if (!$this->upload->do_upload('userfile')) {
	            #No photo upload    
	            $data = array('upload_data' => $this->upload->data());
		        $post_image = "no_image.png";

		  	    #Insert into DB
				$this->News_model->create_news($post_image);

				$this->session->set_flashdata('news_updated', 'News has been submitted.');

				redirect('admin');

	        }else{
	            #Landscape
	            if( $this->upload->data('image_width') <  $this->upload->data('image_height')){

		        	$error = array('error' => $this->upload->display_errors());
		            					
					$this->session->set_flashdata('error',$error['error']);

					$this->load->view('xpanel/header');
					$this->load->view('xpanel/news/create');
					$this->load->view('xpanel/footer');
					
					
	        	}else{   


		         	$data = array('upload_data' => $this->upload->data());
		           	$post_image = $this->upload->data('file_name');

		  	      	 #Insert into DB
					$this->News_model->create_news($post_image);

					$this->session->set_flashdata('news_updated', 'News has been submitted.');

					redirect('admin');
		        }

	        }   
			
		}	

	}

	public function update($slug = FALSE) {

		$data['news'] = $this->News_model->get_news($slug);
	
		if(empty($data['news'])){
			show_404();
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/admin/update',$data);
		$this->load->view('xpanel/footer');

	}

	public function doUpdate() {

		$this->form_validation->set_rules('title','Title','trim|required|min_length[1]|max_length[254]');
		$this->form_validation->set_rules('short','Short','trim|required|min_length[1]|max_length[254]');
		$this->form_validation->set_rules('content','Content','trim|required|min_length[1]|max_length[4999]');
		$this->form_validation->set_rules('tags','Tags','trim|max_length[4999]');

		if($this->form_validation->run() === FALSE) {
			#validate failed
			$slug = $this->input->post('slug');
			
			$data['news'] = $this->News_model->get_news($slug);
		
			if(empty($data['news'])){
				show_404();
			}

			$this->load->view('xpanel/header');
			$this->load->view('xpanel/admin/update',$data);
			$this->load->view('xpanel/footer');

		}else{
			
			#Picture
			$config['upload_path']          = './assets/news/';
	        $config['allowed_types']        = 'gif|jpg|jpeg|png';
	        $config['max_size']             = 2048;
	        $config['max_width']            = 1024;
	        $config['max_height']           = 768;
	        $config['file_ext_tolower']		= TRUE;
	        $config['remove_spaces']		= TRUE;
	        $config['detect_mime']			= TRUE;
	        $config['encrypt_name']			= TRUE;	

	        $this->load->library('upload', $config);
	      
	        if (!$this->upload->do_upload('userfile')) {
	            #No photo upload    
	            $data = array('upload_data' => $this->upload->data());
		        $post_image = $this->input->post('image');

		  	    #Insert into DB
				$this->News_model->update_news($post_image);

				$this->session->set_flashdata('news_updated', 'News has been updated.');

				redirect('admin');

	        }else{
	            #Landscape
	            if( $this->upload->data('image_width') <  $this->upload->data('image_height')){

		        	$slug = $this->input->post('slug');
				
					$data['news'] = $this->News_model->get_news($slug);
					$error = array('error' => $this->upload->display_errors());
		            
					if(empty($data['news'])){
						show_404();
					}
					$this->session->set_flashdata('error',$error['error']);

					$this->load->view('xpanel/header');
					$this->load->view('xpanel/admin/update',$data);
					$this->load->view('xpanel/footer');
					
					
	        	}else{   


		         	$data = array('upload_data' => $this->upload->data());
		           	$post_image = $this->upload->data('file_name');

		  	      	 #Insert into DB
					$this->News_model->update_news($post_image);

					$this->session->set_flashdata('news_updated', 'News has been updated.');

					redirect('admin');
		        }

	        }   
			
		}	

	}

	public function doDelete($slug) {

		$this->News_model->delete_news($slug);
		
		$this->session->set_flashdata('news_deleted', 'News has been deleted.');

		redirect('admin');

	}

	public function doApproval($id) {

		$this->Articles_model->approve($id);
		
		$this->session->set_flashdata('Approval', 'Article has been approved.');

		redirect('admin');

	}

	public function doReject($id) {

		$this->Post_model->delete_post($id);
		
		$this->session->set_flashdata('articles_deleted', 'Article has been deleted.');

		redirect('admin');

	}

	public function feedback($slug = FALSE) {

		$data['post'] = $this->Post_model->get_rejected_post($slug);
	
		if(empty($data['post'])){
			show_404();
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/admin/feedback',$data);
		$this->load->view('xpanel/footer');

	}

	public function dofeedback() {

		$this->Articles_model->feedback();
		
		$this->session->set_flashdata('articles_feedback', ' Send feedback.');

		redirect('admin');

	}
}