<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function index() {

		$this->load->view('xpanel/index');

	}

	public function login() {

		$this->form_validation->set_rules('email','email','trim|valid_email|required');
		$this->form_validation->set_rules('password','password','trim|required|min_length[6]');

		if($this->form_validation->run() == FALSE) {

			$this->load->view('xpanel/index');
		
		}else{

			$password = $this->input->input_stream('password',TRUE);
			$email    = $this->input->input_stream('email',TRUE);
			$password = $this->security->xss_clean($password);
			$email    = $this->security->xss_clean($email);
			
			if($member = $this->Membership_model->validate($email)) {

				$verify = $this->encryption_code->hash_verify($password, $member->password);

				if($verify) {

					$session = array('email'  => $member->email,
							         'user_id'  => $member->id,
							         'role_id'  => $member->role_id,
							         'logged_in' => TRUE);

					switch($member->role_id){

						case 1:
							$this->session->set_userdata($session);
							redirect('dashboard');
						break;
						case 2:
							$this->session->set_userdata($session);
							redirect('articles');
						break;

						default:
							$data['error'] = "The page you requested was not found.";
							$this->load->view('xpanel/index',$data);
					}

				}

			}else{

					$data['error'] = "Wrong password. Try again.";
					$this->load->view('xpanel/index',$data);

			}

		}

	}

	public function logout() {

		$this->session->sess_destroy();

		$this->session->unset_userdata('logged_in');
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('role_id');
		$this->session->unset_userdata('email');

		$this->session->set_flashdata('user_loggedout', 'You are now logged out');

     	redirect('','refresh');
	}

}
