<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Breaking_news extends CI_Controller {

	public function index() {

		//Config pagination
        $config['base_url'] = site_url('breaking_news/index');
        $config['total_rows'] = $this->db->count_all('tm_news'); 
        $config['per_page'] = 5;  
        $config["uri_segment"] = 3;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //Style pagination
        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="selected">';
        $config['cur_tag_close']    = '</li>';
      	$config['next_tag_open']    = '<li>';
        $config['next_tagl_close']  = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tagl_close']  = 'Next</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tagl_close']  = '</li>';
      

        //Initialize pagination
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['news'] = $this->News_model->get_page_news($config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();
		$data['years'] = $this->News_model->yearArchieve();
		$data['empty'] = "";

		$this->load->view('templates/header');
		$this->load->view('breaking_news',$data);
		$this->load->view('templates/footer');

	}

	public function archieves($slug) {

		//Config pagination
        $config['base_url'] = site_url('breaking_news/archieves/'.$slug);
        $config['total_rows'] = $this->db->like('upload_on', $slug, 'after')->from("tm_news")->count_all_results();
        $config['per_page'] = 5;  
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //Style pagination
        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="selected">';
        $config['cur_tag_close']    = '</li>';
      	$config['next_tag_open']    = '<li>';
        $config['next_tagl_close']  = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tagl_close']  = 'Next</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tagl_close']  = '</li>';

        //Initialize pagination
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data['news'] = $this->News_model->get_news_by_periode($slug, $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();
		$data['years'] = $this->News_model->yearArchieve();

		if(empty($data['news'])){
			$data['empty'] = "News not found";
		}else{
			$data['empty'] = "";
		}

		$this->load->view('templates/header');
		$this->load->view('breaking_news',$data);
		$this->load->view('templates/footer');

	}

	public function tags($slug) {

		//Config pagination
        $config['base_url'] = site_url('breaking_news/tags/'.$slug);
        $config['total_rows'] = $this->db->like('tags', $slug, 'both')->from("tm_news")->count_all_results();
        $config['per_page'] = 5;  
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //Style pagination
        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="selected">';
        $config['cur_tag_close']    = '</li>';
      	$config['next_tag_open']    = '<li>';
        $config['next_tagl_close']  = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tagl_close']  = 'Next</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tagl_close']  = '</li>';

        //Initialize pagination
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data['news'] = $this->News_model->get_news_by_tags($slug, $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();
		$data['years'] = $this->News_model->yearArchieve();

		if(empty($data['news'])){
			$data['empty'] = "News not found";
		}else{
			$data['empty'] = "";
		}

		$this->load->view('templates/header');
		$this->load->view('breaking_news',$data);
		$this->load->view('templates/footer');

	}

}