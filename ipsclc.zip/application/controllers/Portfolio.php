<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Portfolio extends CI_Controller {
	
	public function __construct() {

		parent::__construct();
		
		if($_SESSION['role_id'] != 1 AND $_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}
		
	}

	public function index() {

		$data['portfolio'] = $this->Portfolio_model->read_portfolio();

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/portfolio',$data);
		$this->load->view('xpanel/footer');

	}

	
	public function update_portfolio() {

		$this->form_validation->set_rules('desc', 'Deskripsi', 'trim|required|min_length[1]|max_length[4500]');
		$this->form_validation->set_rules('course', 'Minat', 'trim|required|min_length[1]|max_length[4500]');
		$this->form_validation->set_rules('total', 'Total', 'trim|required|min_length[1]|max_length[255]');
		$this->form_validation->set_rules('study', 'Pendidikan', 'trim|required|min_length[1]|max_length[255]');

		if($this->form_validation->run() === FALSE) {

			redirect('portfolio');
		
		} else {

			$this->Portfolio_model->update_portfolio();
			
			redirect('portfolio');
		}
	}
}