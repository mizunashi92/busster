<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

	public function index() {

		//Config pagination
        $config['base_url'] = site_url('posts/index');
        $config['total_rows'] = $this->db->count_all('tm_articles'); 
        $config['per_page'] = 10;  
        $config["uri_segment"] = 3;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //Style pagination
        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="selected">';
        $config['cur_tag_close']    = '</li>';
      	$config['next_tag_open']    = '<li>';
        $config['next_tagl_close']  = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tagl_close']  = 'Next</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tagl_close']  = '</li>';
      

        //Initialize pagination
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['posts'] = $this->Post_model->get_page_posts($config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();
		$data['years'] = $this->Post_model->yearArchieve();
		$data['empty'] = "";

		$this->load->view('templates/header');
		$this->load->view('articles',$data);
		$this->load->view('templates/footer');

	}

	public function archieves($slug) {

		//Config pagination
        $config['base_url'] = site_url('posts/archieves/'.$slug);
        $config['total_rows'] = $this->db->like('upload_on', $slug, 'after')->from("tm_articles")->count_all_results();
        $config['per_page'] = 10;  
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //Style pagination
        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="selected">';
        $config['cur_tag_close']    = '</li>';
      	$config['next_tag_open']    = '<li>';
        $config['next_tagl_close']  = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tagl_close']  = 'Next</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tagl_close']  = '</li>';
      

        //Initialize pagination
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data['posts'] = $this->Post_model->get_posts_by_periode($slug, $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();
		$data['years'] = $this->Post_model->yearArchieve();

		if(empty($data['posts'])){
			$data['empty'] = "Articles not found";
		}else{
			$data['empty'] = "";
		}

		$this->load->view('templates/header');
		$this->load->view('articles',$data);
		$this->load->view('templates/footer');

	}

	public function tags($slug) {

		//Config pagination
        $config['base_url'] = site_url('posts/tags/'.$slug);
        $config['total_rows'] = $this->db->like('tags', $slug, 'both')->from("tm_articles")->count_all_results();
        $config['per_page'] = 10;  
        $config["uri_segment"] = 4;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //Style pagination
        $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagination"><ul>';
        $config['full_tag_close']   = '</ul></div>';
        $config['num_tag_open']     = '<li>';
        $config['num_tag_close']    = '</li>';
        $config['cur_tag_open']     = '<li class="selected">';
        $config['cur_tag_close']    = '</li>';
      	$config['next_tag_open']    = '<li>';
        $config['next_tagl_close']  = '</li>';
        $config['prev_tag_open']    = '<li>';
        $config['prev_tagl_close']  = 'Next</li>';
        $config['first_tag_open']   = '<li>';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open']    = '<li>';
        $config['last_tagl_close']  = '</li>';
      

        //Initialize pagination
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data['posts'] = $this->Post_model->get_posts_by_tags($slug, $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();
		$data['years'] = $this->Post_model->yearArchieve();

		if(empty($data['posts'])){
			$data['empty'] = "Articles not found";
		}else{
			$data['empty'] = "";
		}

		$this->load->view('templates/header');
		$this->load->view('articles',$data);
		$this->load->view('templates/footer');

	}

	public function view($slug = NULL) {

		$data['post'] = $this->Post_model->get_posts($slug);
		
		if(empty($data['post'])){
			show_404();
		}

		$this->load->view('templates/header');
		$this->load->view('view_article',$data);
		$this->load->view('templates/footer');

	}

	public function view_my_articles() {

		$data['posts'] = $this->Post_model->get_my_posts();

		if(empty($data['posts'])){
			$data['empty'] = 'You dont have any articles';

			$this->load->view('templates/header');
			$this->load->view('view_my_articles',$data);
			$this->load->view('templates/footer');

		}

		
		$this->load->view('templates/header');
		$this->load->view('view_my_articles',$data);
		$this->load->view('templates/footer');

	}

	public function view_my_article($slug) {

		$data['post'] = $this->Post_model->get_my_posts($slug);

		if(empty($data['post'])){
			show_404();

		}
		
		$this->load->view('templates/header');
		$this->load->view('view_my_article',$data);
		$this->load->view('templates/footer');

	}

	public function create() {

		$data['categories'] = $this->Post_model->get_categories();

		$this->form_validation->set_rules('title','Title','required');
		$this->form_validation->set_rules('content','Content','required');

		if($this->form_validation->run() === FALSE) {

			$this->load->view('templates/header');
			$this->load->view('create_article',$data);
			$this->load->view('templates/footer');			
		
		} else {

			//Upload File
			$config['upload_path'] = './asset/img/articles';
			$config['allowed_types'] = 'jpg|png|gif';
			$config['max_size'] = '2048';
			$config['max_width'] = '2000';
			$config['max_height'] = '2000';

			$this->load->library('upload',$config);

			if(!$this->upload->do_upload()) {
				
				$errors = array('error' => $this->upload->display_errors());
				$post_image = "noimage.jpg";

			} else {
				
				$data = array('upload_data' => $this->upload->data());
				$post_image  = $_FILES['userfile']['name'];

			}

			$this->Post_model->create_post($post_image);

			// Set message
			$this->session->set_flashdata('post_created', 'Your post has been created.');

			redirect('articles');

		}

	}

	public function delete($id) {

		$this->Post_model->delete_post($id);
		// Set message
		$this->session->set_flashdata('post_deleted', 'Your post has been deleted.');

		redirect('articles');

	}

	public function edit($slug) {

		$data['post'] = $this->Post_model->get_posts($slug);
		$data['categories'] = $this->Post_model->get_categories();
		
		if(empty($data['post'])){
			show_404();
		}

		$this->load->view('templates/header');
		$this->load->view('update_article',$data);
		$this->load->view('templates/footer');		
	
	}

	public function edit_my_article($slug) {
	
		$data['post'] = $this->Post_model->get_my_posts($slug);
		$data['categories'] = $this->Post_model->get_categories();
		
		if(empty($data['post'])){
			show_404();
		}

		$this->load->view('templates/header');
		$this->load->view('update_article',$data);
		$this->load->view('templates/footer');		
	
	}

	public function update() {

		$this->Post_model->update_post();

		// Set message
		$this->session->set_flashdata('post_updated', 'Your post has been updated.');

		redirect('articles');

	}
}
