<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct() {

		parent::__construct();

		$this->load->library(array('Encryption_code'));
		$this->load->model('Users_model');
	}

	public function index() {

		$this->load->view('templates/header');
		$this->load->view('index');
		$this->load->view('templates/footer');

	}

	public function login() {

		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('password','Password','required');

		if($this->form_validation->run() === FALSE) {

			$this->load->view('templates/header');
			$this->load->view('sign_up');
			$this->load->view('templates/footer');

		} else {

			$email = $this->input->post('email',TRUE);
			$user_id = $this->Users_model->login($email);

			if($user_id) {
				
				$verify = $this->encryption_code->hash_verify($this->input->post('password'), $user_id->password);

				if($verify) {

					$user_data = array('email'  => $user_id->email,
							           'user_id'  => $user_id->id,
							           'role_id'  => $user_id->role_id,
							           'logged_in' => TRUE);

					$this->session->set_userdata($user_data);

					// Set message
					$this->session->set_flashdata('user_loggedin', 'You are now logged in.');
					redirect('my_panel');

				} else {

					$this->session->set_flashdata('login_failed', 'Login is invalid.');
					redirect('sign_up');

				}
				
			} else {

				$this->session->set_flashdata('login_failed', 'Login is invalid.');
				redirect('sign_up');

			}

		}

	}

	public function register() {

		$this->form_validation->set_rules('email','Email','required|callback_check_email_exists');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('confpassword','Confirmation Password','required|matches[password]');
	
		if($this->form_validation->run() === FALSE) {

			$this->load->view('templates/header');
			$this->load->view('sign_up');
			$this->load->view('templates/footer');

		} else {

			// Encrypt password
			$enc_password = $this->encryption_code->hash_generate($this->input->post('password'));

			$this->Users_model->register($enc_password);

			// Set message
			$this->session->set_flashdata('user_registered', 'You are now registered and can log in.');
			
			redirect('sign_up');

		}
	}

	public function logout() {

		$this->session->sess_destroy();

		$this->session->unset_userdata('logged_in');
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('role_id');
		$this->session->unset_userdata('email');

		// Message
		$this->session->set_flashdata('user_loggedout', 'You are now logged out');
		redirect('sign_up');
	}

	public  function check_email_exists($email) {

		$this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one.');

		if($this->Users_model->check_email_exists($email)) {

			return TRUE;

		} else {

			return FALSE;

		}
	}

}
