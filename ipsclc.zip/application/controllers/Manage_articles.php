<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_articles extends CI_Controller {

	public function __construct() {

		parent::__construct();

		$this->load->helper(array('form','url','html'));	
		$this->load->model('Articles_model');	
	
		if($_SESSION['role_id'] != 1 AND $_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}

	}

	public function index() {

		$result = $this->Articles_model->read();

		$data['articles'] = $result;
		
		$this->load->view('xpanel/header');
		$this->load->view('xpanel/manage_articles',$data);
		$this->load->view('xpanel/footer');

	}

	public function view($slug = NULL) {

		$data['article'] = $this->Articles_model->read($slug);
		
		if(empty($data['article'])){
			show_404();
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/check_article',$data);
		$this->load->view('xpanel/footer');

	}

	public function approve($id = NULL) {

		if($id === NULL){
			show_404();
		}

		$this->Articles_model->approve($id);

		$this->session->set_flashdata('article_approved', 'This article has been approved');
		redirect('manage_articles');

	}

	public function reject($id = NULL) {

		if($id === NULL){
			show_404();
		}

		$this->Articles_model->reject($id);
		
		$this->session->set_flashdata('article_rejected', 'This article has been rejected');
		redirect('manage_articles');
		
	}
	
}
