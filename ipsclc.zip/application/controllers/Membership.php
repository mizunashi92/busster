<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Membership extends CI_Controller {

	public function __construct() {

		parent::__construct();
		
		$this->load->helper(array('form','url','html'));	
		$this->load->model('membership_model');

		if($_SESSION['role_id'] != 1 AND $_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}

	}

	public function index() {

		$result = $this->membership_model->read();
		$data['member'] = null;

		if($result) {
			$data['member'] = $result;
		}
		
		$this->load->view('xpanel/header');
		$this->load->view('xpanel/membership',$data);
		$this->load->view('xpanel/footer');
		
	}
	
}
