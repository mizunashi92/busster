<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Articles extends CI_Controller {
	
	public function __construct() {

		parent::__construct();
		
		if($_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}
		
	}

	public function index($slug = FALSE) {

		if($_SESSION['role_id'] == 1){
			$data['posts'] = $this->Post_model->get_posts($slug);
		}else{
			$data['posts'] = $this->Post_model->get_my_posts($slug);
		}
		$this->load->view('xpanel/header');
		$this->load->view('xpanel/articles/index',$data);
		$this->load->view('xpanel/footer');

	}

	public function read($slug = FALSE) {

		$data['post'] = $this->Post_model->get_posts($slug);
	
		if(empty($data['post'])){
			show_404();
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/articles/read',$data);
		$this->load->view('xpanel/footer');

	}

	public function create($slug = FALSE) {

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/articles/create');
		$this->load->view('xpanel/footer');

	}

	public function doCreate() {

		$this->form_validation->set_rules('title','Title','trim|required|min_length[1]|max_length[254]');
		$this->form_validation->set_rules('content','Content','trim|required|min_length[1]|max_length[4999]');
		$this->form_validation->set_rules('tags','Tags','trim|max_length[4999]');

		if($this->form_validation->run() === FALSE) {
			
			$this->load->view('xpanel/header');
			$this->load->view('xpanel/articles/create');
			$this->load->view('xpanel/footer');

		}else{
			
			#Picture
			$config['upload_path']          = './assets/articles/';
	        $config['allowed_types']        = 'gif|jpg|jpeg|png';
	        $config['max_size']             = 2048;
	        $config['max_width']            = 1024;
	        $config['max_height']           = 768;
	        $config['file_ext_tolower']		= TRUE;
	        $config['remove_spaces']		= TRUE;
	        $config['detect_mime']			= TRUE;
	        $config['encrypt_name']			= TRUE;	

	        $this->load->library('upload', $config);
	      
	        if (!$this->upload->do_upload('userfile')) {
	            #No photo upload    
	            $data = array('upload_data' => $this->upload->data());
		        $post_image = "no_image.png";

		  	    #Insert into DB
				$this->Post_model->create_post($post_image);

				$this->session->set_flashdata('article_updated', 'Your article has been submitted, please wait for validation.');

				redirect('articles');

	        }else{
	            #Landscape
	            if( $this->upload->data('image_width') <  $this->upload->data('image_height')){

		        	$error = array('error' => $this->upload->display_errors());
		            					
					$this->session->set_flashdata('error',$error['error']);

					$this->load->view('xpanel/header');
					$this->load->view('xpanel/articles/create');
					$this->load->view('xpanel/footer');
					
					
	        	}else{   


		         	$data = array('upload_data' => $this->upload->data());
		           	$post_image = $this->upload->data('file_name');

		  	      	 #Insert into DB
					$this->Post_model->create_post($post_image);

					$this->session->set_flashdata('article_updated', 'Your article has been submitted, please wait for validation.');

					redirect('articles');
		        }

	        }   
			
		}	

	}

	public function update($slug = FALSE) {

		$data['post'] = $this->Post_model->get_posts($slug);
	
		if(empty($data['post'])){
			show_404();
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/articles/update',$data);
		$this->load->view('xpanel/footer');

	}

	public function doUpdate() {

		$this->form_validation->set_rules('title','Title','trim|required|min_length[1]|max_length[254]');
		$this->form_validation->set_rules('content','Content','trim|required|min_length[1]|max_length[4999]');
		$this->form_validation->set_rules('tags','Tags','trim|max_length[4999]');

		if($this->form_validation->run() === FALSE) {
			#validate failed
			$slug = $this->input->post('slug');
			
			$data['post'] = $this->Post_model->get_posts($slug);
		
			if(empty($data['post'])){
				show_404();
			}

			$this->load->view('xpanel/header');
			$this->load->view('xpanel/articles/update',$data);
			$this->load->view('xpanel/footer');

		}else{
			
			#Picture
			$config['upload_path']          = './assets/articles/';
	        $config['allowed_types']        = 'gif|jpg|jpeg|png';
	        $config['max_size']             = 2048;
	        $config['max_width']            = 1024;
	        $config['max_height']           = 768;
	        $config['file_ext_tolower']		= TRUE;
	        $config['remove_spaces']		= TRUE;
	        $config['detect_mime']			= TRUE;
	        $config['encrypt_name']			= TRUE;	

	        $this->load->library('upload', $config);
	      
	        if (!$this->upload->do_upload('userfile')) {
	            #No photo upload    
	            $data = array('upload_data' => $this->upload->data());
		        $post_image = $this->input->post('image');

		  	    #Insert into DB
				$this->Post_model->update_post($post_image);

				$this->session->set_flashdata('article_updated', 'Your article has been updated, please wait for validation.');

				redirect('articles');

	        }else{
	            #Landscape
	            if( $this->upload->data('image_width') <  $this->upload->data('image_height')){

		        	$slug = $this->input->post('slug');
				
					$data['post'] = $this->Post_model->get_posts($slug);
					$error = array('error' => $this->upload->display_errors());
		            
					if(empty($data['post'])){
						show_404();
					}
					$this->session->set_flashdata('error',$error['error']);

					$this->load->view('xpanel/header');
					$this->load->view('xpanel/articles/update',$data);
					$this->load->view('xpanel/footer');
					
					
	        	}else{   


		         	$data = array('upload_data' => $this->upload->data());
		           	$post_image = $this->upload->data('file_name');

		  	      	 #Insert into DB
					$this->Post_model->update_post($post_image);

					$this->session->set_flashdata('article_updated', 'Your article has been updated, please wait for validation.');

					redirect('articles');
		        }

	        }   
			
		}	

	}

	public function doDelete($slug) {

		$this->Post_model->delete_post($slug);
		
		$this->session->set_flashdata('articles_deleted', 'Your article has been deleted.');

		redirect('articles');

	}
}