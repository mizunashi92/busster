<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_categories extends CI_Controller {

	public function __construct() {

		parent::__construct();

		$this->load->helper(array('form','url','html'));	
		$this->load->model('Categories_model');	
	
		if($_SESSION['role_id'] != 1 AND $_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}

	}

	public function index() {

		$result = $this->Categories_model->read();

		$data['categories'] = null;
		
		if($result) {
			$data['categories'] = $result;
		}

		$this->load->view('xpanel/header');
		$this->load->view('xpanel/manage_categories',$data);
		$this->load->view('xpanel/footer');

	}

	public function create() {

		$this->form_validation->set_rules('name', 'Name', 'required');

		if ($this->form_validation->run() === FALSE) {

			$this->load->view('xpanel/header');
			$this->load->view('xpanel/create_category');
			$this->load->view('xpanel/footer');

		} else {

			$this->Categories_model->create_category();

			$this->session->set_flashdata('category_created', 'Your category has been created');
			
			redirect('Manage_categories');

		}
	
	}

}
