<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {

		parent::__construct();
		
		if($_SESSION['role_id'] != 1 AND $_SESSION['logged_in'] != TRUE){
			redirect('auth');
		}
		
	}

	public function index() {

		$data['profile'] = $this->Users_model->read_profile();
		$data['submitted'] = $this->Count_model->submitted(); 
		$data['approved'] = $this->Count_model->approved(); 
		$data['rank'] = $this->Count_model->rank(); 
		$data['whole'] = $this->Count_model->whole(); 
		
		$this->load->view('xpanel/header');
		$this->load->view('xpanel/dashboard',$data);
		$this->load->view('xpanel/footer');

	}
	
	public function update_profile() {

		$this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[1]|max_length[255]');
		$this->form_validation->set_rules('email','Email Address','trim|required|valid_email');

		if($this->form_validation->run() === FALSE) {


			redirect('dashboard');
		
		} else {

			$config['upload_path']          = './assets/users/';
            $config['allowed_types']        = 'gif|jpg|jpeg|png';
            $config['max_size']             = 2048;
            $config['max_width']            = 1024;
            $config['max_height']           = 768;
            $config['file_ext_tolower']		= TRUE;
            $config['remove_spaces']		= TRUE;
            $config['detect_mime']			= TRUE;
            $config['encrypt_name']			= TRUE;
           
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('userfile')) {
                
                $errors = array('error' => $this->upload->display_errors());
                $post_image = $this->input->post('image');

            }else{
               
            	$data = array('upload_data' => $this->upload->data());
              	$post_image = $this->upload->data('file_name');

            }

            $this->Users_model->update_profile($post_image);
			
			redirect('dashboard');
		}
	}
}
