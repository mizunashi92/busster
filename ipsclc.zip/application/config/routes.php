<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['articles/edit/(:any)'] = 'Posts/edit/$1';
$route['articles/create'] = 'Posts/create';
$route['articles/(:any)'] = 'Posts/view/$1';
$route['articles'] = 'Posts/index';
$route['default_controller'] = 'Home';

$route['manage_articles/(:any)'] = 'Manage_articles/view/$1';
$route['manage_articles'] = 'Manage_articles/index';

$route['categories'] = "Manage_categories/index";
$route['categories/create'] = 'Manage_categories/create';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
