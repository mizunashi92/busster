<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//######################## BED ############################//
//Admin Articles
$route['admin'] = 'admin/index';
$route['articles'] = 'articles/index';
$route['news'] = 'news/index';

//######################## FED ###########################//
$route['posts/edit/(:any)'] = 'posts/edit/$1';
$route['posts/create'] = 'posts/create';
$route['posts/(:any)'] = 'posts/view/$1';

$route['breaking_news/tags/(:any)'] = 'breaking_news/tags/$1';
$route['breaking_news/archieves/(:any)'] = 'breaking_news/archieves/$1';
$route['breaking_news'] = 'breaking_news/index';

$route['posts/tags/(:any)'] = 'posts/tags/$1';
$route['posts/archieves/(:any)'] = 'posts/archieves/$1';
$route['posts'] = 'posts/index';
$route['default_controller'] = 'Home';

$route['manage_articles/(:any)'] = 'manage_articles/view/$1';
$route['manage_articles'] = 'manage_articles/index';

$route['categories'] = "manage_categories/index";
$route['categories/create'] = 'manage_categories/create';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
