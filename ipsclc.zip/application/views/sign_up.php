	<div id="contents">
		<div id="blog" class="area">
			<div class="main">
				<h2 class="heading3">Register</h2>
				<?php 
					echo"<div class='flashdata2'>";
					echo validation_errors();
					echo "</div>";
				 	echo form_open('users/register');
				 ?>
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="email" placeholder="Your email." required="" autofocus=""/>
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" class="form-control" name="password" placeholder="Your password." required="" autofocus=""/>
				</div>
				<div class="form-group">
					<label>Retype Password</label>
					<input type="password" class="form-control" name="confpassword" placeholder="Retype password." required="" autofocus=""/>
				</div>
				<button type="submit" class="signup" />Register</button>
				<?php echo form_close(); ?>
			</div>
			<div class="sidebar">
				<h2 class="heading1">Login</h2>
				<?php echo form_open('auth/login'); ?>
				<div class="form-group">
					<label>Email</label>
					<input type="text" class="form-control" name="email" placeholder="Your email." required="" autofocus="" />
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" class="form-control" name="password" placeholder="Your password." required="" autofocus=""/>
				</div>
				<button type="submit" />Login</button>
				<?php echo form_close(); ?>
			</div>
		</div>
	</div>
