	<div id="contents">
		<div id="blog" class="area">
			<div class="main">
				<img src="<?php echo base_url(); ?>asset/img/articles/<?= $post->img; ?>" alt="Img" height="130" width="130" />
				<div>
					<h3><?= $post->title ?> </h3>
					<p><?= $post->content ?> </p>
					<small class="postedby"> by: <?= $post->email ?></small> 
					<small class="postedon"><?= $post->upload_on ?> in <?= $post->name ?></small>
				</div>

			</div>
			<div class="sidebar">
				<h2 class="heading1">My Panel</h2>
				<div class="box2">
					<div>
						<ul class="archives">
							<li><a href="<?php echo base_url(); ?>articles/create"><img src="<?php echo base_url(); ?>asset/img/create_article.png"> Create Posts</a></li>
							<li><a href="<?php echo base_url(); ?>posts/view_my_articles"><img src="<?php echo base_url(); ?>asset/img/archieve.png"> My Posts</a></li>
							<li><a href="<?php echo base_url(); ?>users/logout"><img src="<?php echo base_url(); ?>asset/img/logout.png"> Log out</a></li>
						</ul>
					</div>
				</div>	
			</div>
		</div>
	</div>
