	<div id="contents">
		<div id="about" class="area">
			<div class="section">
				<div class="box">
					<div>
						<div>
							<h3>IPSCLC</h3>
							<p>
								Indonesia Procurement Supply Chain and Logistics (IPSCLC) started its activities through a Whatsapp forum which grows up to 1117 members as per September 27th, 2016. It was founded in November, 18th 2015 in Jakarta with ever growing number of members consisting members from Java, Sumatra, Kalimantan and Sulawesi.
</br>
</br>								
There are several diversifying things about IPSCLC for example:</br>
<i>-> Whatsapp group which helps in vendor sourcing as well as problem solving for procurement and purchasing matters.</br>
-> Frequent gathering at least 3 times a year filled with seminars and knowledge sharing.</br>
-> IPSCLC does not affiliate itself with any company, industry, organization or instances, making IPSCLC neutral in many ways.
</i>
</br>
</br>

IPSCLC tries to combine best minds in the area of business and industry to freely share their knowledge, experience and expertise so that its members can benefit from the group.

							</p>
							<h3>What we have done</h3>
								<h4>1st Gathering and Seminar : January 30th, 2016 - Serpong </br> <b>Skill Techniques Negotiation</b> by <i>Togap Siagian, CPSM</i></h4>
<h4></br>2nd Gathering & Seminar : April 23rd, 2016 - Bekasi </br> <b>Gaining better Cost Reduction Through Total Cost of Ownership Analysis</b> by <i>Teuku Yuza Shahanshah, STi, MEM, CIPM</i></h4>
<h4></br>3rd Gathering & Training : June 4th, 2016 - Jakarta </br> <b>Export Import :
Management Exim, shipping, and customs</br> by <i>Sutomo Asngadi, SS, MM</i></h4>
<h4></br>4th Gathering & Panel Discussion : July 23rd, 2016 - Jakarta </br>
<ul><li><b>Procurement and Supply Chain Roles in MEA</b> by <i>Prof Nyoman Pujawan, Ph.D, CSCP; R, Sumardji (Ptk 007 Team); Teuku Yuza Shahanshah, STi, MEM, CIPM</i></li>
<li><b>How Spend Analysis can be used To Identity Saving
Opportunies and Business Strategie</b> by <i>Nyoman Pujawan,
Ph.D, CSCP</i></li></ul></h4>
<h4></br>5th Gathering & Workshop : October 6th, 2016 - Jakarta </br> <b>Production Management Workshop</b> by <i>Efrata
Denny Saputra Yunus, ST, Mis. Mcom</i></h4>
							</p>
							<h3>Be Part of Our Community</h3>
							<p>
								If you share the same enthusiasms on Procurement, Supply Chain and Logistics, join the discussion <a href="http://www.ipsclc.com/contact/">on our forum</a> and meet other people in the community who share the same interests with you.
							</p>
							
							
						</div>
					</div>
				</div>
			</div>
			<div class="section">
				<div class="box">
					<div>
						<div>
							<img src="<?php echo base_url(); ?>asset/img/Yuza.png" alt="Img" height="100" width="100" align = "left"/>
							<h2></br>Teuku Yuza Shahanshah </br> Chairman</h2>
							<p>
								</br>
							</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div>
						<div>
							<img src="<?php echo base_url(); ?>asset/img/Dendi.png" alt="Img" height="100" width="100" align = "left"/>
							<h2></br>Dendi Bangun Ambuko </br> Vice Chairman</h2>
							<p>
								</br>
							</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div>
						<div>
							<img src="<?php echo base_url(); ?>asset/img/Andie.png" alt="Img" height="100" width="100" align = "left"/>
							<h2></br>Andie Setiyawan </br> General Secretary</h2>
							
							<p>
								</br>
							</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div>
						<div>
						<img src="<?php echo base_url(); ?>asset/img/Tute.png" alt="Img" height="100" width="100" align = "left"/>
							<h2></br>Sri Hartuti </br> Treasury</h2>
							
							<p>
								</br>
							</p>
						</div>
					</div>
				</div>
				<div class="box">
					<div>
						<div>
							<h2>The Rest or Our Members</h2>
							<h4>
								</b>Public Relation</b> - <i>Mutia Sari Syamsul</i></br>
								</b>Education, Development and Improvement</b> - <i>Dion Yoske</i></br>
								</b>Communication & Technology</b> - <i>Sintyadi Thong</i></br>
								</b>Communication & Technology</b> - <i>Tommi Indianto</i></br>
								</b>Organization</b> - <i>Indra Hermawan</i></br>
								</b>Organization</b> - <i>Irvan Idris</i></br>
							</h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
