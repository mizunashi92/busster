	<div id="contents">
		<div id="adbox">
			<div class="area">
				<ul>
					<li>
						<div>
							<h2><span>LAND</span> TRANSPORT</h2>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a>
							</p>
						</div>
					</li>
					<li>
						<div>
							<h2><span>Ocean</span> TRANSPORT</h2>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a>
							</p>
						</div>
					</li>
					<li>
						<div>
							<h2><span>Air</span> TRANSPORT</h2>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a>
							</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<div class="area">
			<div class="main">
				<h2>FREE WEBSITE TEMPLATES</h2>
				<p>
					This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us. If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forums/">Forum</a>.
				</p>
				<div id="features">
					<h2>Why Choose Us</h2>
					<ul>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/agents.png" alt="Img" height="100" width="100" />
							<h3>Easy Transactions</h3>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free.
							</p>
						</li>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/shopping.png" alt="Img" height="100" width="100" />
							<h3>Hassle Free</h3>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free.
							</p>
						</li>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/smiling.png" alt="Img" height="100" width="100" />
							<h3>Mobile Tracking</h3>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free.
							</p>
						</li>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/buildings.png" alt="Img" height="100" width="100" />
							<h3>World Wide Office</h3>
							<p>
								This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free.
							</p>
						</li>
					</ul>
				</div>
			</div>
			<div class="blog">
				<?php if(!isset($_SESSION['logged_in'])){ ?>
				<h2>Login</h2>
				<div class="frame">
					<?php 
						echo validation_errors();
						echo form_open('users/login');
					?>
						<div class="form-group">
							<label>Email</label>
							<input type="text" class="form-control" name="email" placeholder="Your email." required="" autofocus="" />
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control" name="password" placeholder="Your password." required="" autofocus=""/>
						</div>
						<button type="submit" />Login</button>
					<?php echo form_close(); ?>
				</div>
				<h3>Register here!</h3>
				<div>
					<?php 
						echo validation_errors();
				 	  	echo form_open('users/register');
				 	?>
						<div class="form-group">
							<label>Email</label>
							<input type="text" class="form-control" name="email" placeholder="Your email." required="" autofocus=""/>
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control" name="password" placeholder="Your password." required="" autofocus=""/>
						</div>
						<div class="form-group">
							<label>Retype Password</label>
							<input type="password" class="form-control" name="confpassword" placeholder="Retype password." required="" autofocus=""/>
						</div>
						<button type="submit" class="signup" />Register</button>
				</div>
					<?php echo form_close(); ?>

					<?php } else { ?>
						<h2>Recent Blog Post</h2>
						<div class="frame">
							<img src="<?php echo base_url(); ?>asset/img/checker.jpg" alt="Img" height="216" width="268" />
						</div>
						<h3>We Aim Higher</h3>
						<p>
							This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us. If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forums/">Forum</a>.
						</p>
					<?php } ?>
				
			</div>
		</div>
	</div>