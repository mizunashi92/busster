	<div id="contents">
		<div id="contact" class="area">
			<div class="section">
				<h3>Contact Us</h3>
				<p>
					Citing an Indonesian proverb, "Unrecognizion equals to unlove", therefore get to know us better by joining us on our <a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw">Telegram Group</a>. At this group, you can join our discussion, as well as finding ways to resolve problems together.
				</p>
				<p>
					Should you need further information about us, please feel free to mail us at </br>
					<a href="mailto:ipsclc.pusat@gmail.com?subject=Informasi&cc=andie.setiyawan@gmail.com" target="_blank" class="mail">ipsclc.pusat@gmail.com</a>
					<span>Call or e-mail us for help with any aspect of IPSCLC, online or offline.</span>
				</p>
				<p class="numbers">
					Andie Setiyawan: +62 822-9872-3888<br>
					Sri Hastuti: +62 852-1887-7889<br>
				</p>
				<p class="address">
					<span>Mailing Address</span> <br>IPSCLC<br> Pondok Gede Permai<br>
Jalan Nusa Indah VII Blok C6 No 12<br>
Jatiasih, Bekasi - Jawa Barat - Indonesia
				</p>
			</div>
			<div class="section">
				<h2 class="heading2">IPSCLC</h2>
				<ul class="list">
					<li>
						<img src="<?php echo base_url(); ?>asset/img/agents.png" alt="Img" height="100" width="100" />
						<div>
							<h3>Training</h3>
							<p>
								Get our latest updates on trainings on our <a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw">IPSCLC Telegram</a> <br> <br> <br>
							</p>
						</div>
					</li>
					<li>
						<img src="<?php echo base_url(); ?>asset/img/shopping.png" alt="Img" height="100" width="100" />
						<div>
							<h3>Group Discussion</h3>
							<p>
								We invite great minds to discuss on our group chat at <u><a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw">IPSCLC Telegram</a></u> <br> <br> <br>
							</p>
						</div>
					</li>
					<li>
						<img src="<?php echo base_url(); ?>asset/img/smiling.png" alt="Img" height="100" width="100" />
						<div>
							<h3>Bonding</h3>
							<p>
								Widen your network through IPSCLC, a social community for people with procurement, inventory, logistics and supply chain background as well as enthusiasts on the subjects. <br>
							</p>
						</div>
					</li>
					<li>
						<img src="<?php echo base_url(); ?>asset/img/buildings.png" alt="Img" height="100" width="100" />
						<div>
							<h3>Consultation</h3>
							<p>
								We are composed of several people with different backgrounds with years of experience in the implementation and consultation areas. Feel free to contact us <a href="contact.php">here</a>.
							</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
