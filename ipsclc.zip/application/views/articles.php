	<div id="contents">
		<div id="blog" class="area">
			<div class="main">
				<ul class="list">
					<?php foreach($posts as $row){ 
						$content  = substr($row->content,0,200);
						?>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/articles/<?= $row->img; ?>" alt="Img" height="130" width="130" />
							<div>
								<h3><?= $row->title ?> </h3>
								<p><?= $content ?> </p>
								<span class="views"> <a href="<?php echo site_url('/articles/'.$row->slug); ?>">Read more</a></span> <span class="time"><?= $row->upload_on ?> in <?= $row->name ?> <br>by <?= $row->email ?></span>
							</div>
						</li>
					<?php }?>
				</ul>
				<div class="pagination">
					<ul>
						<li>
							<a href="blog.html">First</a>
						</li>
						<li class="selected">
							<a href="blog.html">1</a>
						</li>
						<li>
							<a href="blog.html">2</a>
						</li>
						<li>
							<a href="blog.html">3</a>
						</li>
						<li>
							<a href="blog.html">4</a>
						</li>
						<li>
							<a href="blog.html">5</a>
						</li>
						<li>
							<a href="blog.html">6</a>
						</li>
						<li>
							<a href="blog.html">7</a>
						</li>
						<li>
							<a href="blog.html">8</a>
						</li>
						<li>
							<a href="blog.html">9</a>
						</li>
						<li>
							<a href="blog.html">10</a>
						</li>
						<li class="last">
							<a href="blog.html">Last</a>
						</li>
					</ul>
				</div>
			</div>	
			<div class="sidebar">
				<h2 class="heading1">Archive</h2>
				<div class="box2">
					<div>
						<ul class="archives">
							<li class="selected">
								<span>2018</span>
								<ul>
									<li>
										<a href="blog.php">December</a>
									</li>
									<li>
										<a href="blog.php">November</a>
									</li>
									<li>
										<a href="blog.php">October</a>
									</li>
									<li>
										<a href="blog.php">September</a>
									</li>
									<li>
										<a href="blog.php">August</a>
									</li>
									<li>
										<a href="blog.php">July</a>
									</li>
									<li>
										<a href="blog.php">June</a>
									</li>
									<li>
										<a href="blog.php">May</a>
									</li>
									<li>
										<a href="blog.php">April</a>
									</li>
									<li>
										<a href="blog.php">March</a>
									</li>
									<li>
										<a href="blog.php">Febuary</a>
									</li>
									<li>
										<a href="blog.php">Janruary</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
