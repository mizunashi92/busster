	<div id="contents">
		<div id="blog" class="area">
			<div class="main">
				<?= $empty; ?>
				<ul class="list">
					<?php foreach($posts as $row){ 
						$content  = substr($row->content,0,100);
						?>
						<li>
							<img src="<?php echo base_url(); ?>assets/articles/<?= $row->img; ?>" alt="Img" height="130" width="130" />
							<div>
								<h3><?= $row->title ?> </h3>
								<p><?= $content ?> </p>
								<span class="views"> <a href="<?php echo site_url('/articles/'.$row->slug); ?>">Read more</a></span><span class="time"><?= $row->upload_on ?> </span>
								<p><img src="<?php echo base_url(); ?>assets/users/<?= $row->dp; ?>" alt="" style="width:24px; border-radius: 50%;">
									<b><?=$row->name?></b>
								</p>
								
									<?php 
										$tags = $row->tags;
										$tag = explode(",", $tags);
										 
										for ( $i = 0; $i < count( $tag ); $i++ ) {
											echo " <span class='label other'> <a href='".base_url()."posts/tags/".str_replace(' ', '', $tag[$i])."'>".$tag[$i]. "</a></span>";
										}
									?>
							
							</div>
						</li>
					<?php }?>
				</ul>
				<div class="pagination">
			            <?= $pagination; ?>
			    </div>
			</div>	
			<div class="sidebar">
				<h2 class="heading1">Archive</h2>
				<div class="box2">
					<div>
						<ul class="archives">
								<?php foreach($years as $year){ ?>
							<li class="selected">
							
									<span><?= $year->year; ?></span>
								<ul>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-12">December</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-11">November</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-10">October</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-09">September</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-08">August</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-07">July</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-06">June</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-05">May</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-04">April</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-03">March</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-02">Febuary</a>
									</li>
									<li>
										<a href="<?php echo base_url();?>posts/archieves/<?= $year->year; ?>-01">Janruary</a>
									</li>
								</ul>

							</li>
							<?php  } ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
