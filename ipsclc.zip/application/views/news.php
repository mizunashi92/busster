<div class="firstview">
<div class="spwrap">
<div class="whatsnew">
<div>
<ul>
	<li>2/20/2018 update [ABOUT|<a href="about.html">Outline</a>][WORLD|<a href="world.html">Story</a>][CHARACTERS|<a href="character.html">TOP</a>,<a href="subcharacter.html?sub=character03">Roger</a>,<a href="subcharacter-1.html?sub=character05">Plachta</a>,<a href="subcharacter-2.html?sub=character06">Fritz</a>,<a href="subcharacter-3.html?sub=character07">Drossel</a>,<a href="subcharacter-4.html?sub=character09">Honnete</a>,<a href="subcharacter02.html?sub=character03">Captain Backen</a>,<a href="subcharacter02-1.html?sub=character04">Corneria</a>,<a href="subcharacter02-2.html?sub=character05">Pamela</a>,<a href="subcharacter02-3.html?sub=character06">Hagel</a>][SYSTEM|<a href="system.html">Synthesis</a>][<a href="movie.html">MOVIE</a>][<a href="preorder.html">PRE ORDER</a>]</li>
	
	<li>1/23/2018 update [WORLD|<a href="world02.html">The Flow of the Game</a>,<a href="world03.html">The Worlds Within Paintings</a>,<a href="world04.html">Side Quests</a>][SYSTEM|<a href="system02.html">Battles</a>,<a href="system03.html">The Smithy</a>][CHARACTERS|<a href="character05.html">Mathias</a>,<a href="character06.html">Alt</a>,<a href="subcharacter.html?sub=character03">Fuoco</a>,<a href="subcharacter-5.html?sub=character04">Grace</a>,<a href="subcharacter-1.html?sub=character05">Lucia</a>,<a href="subcharacter-2.html?sub=character06">Neige</a>,<a href="subcharacter-3.html?sub=character07">Mireille</a>][<a href="movie.html">MOVIE</a>]</li>
	
	<li>11/14/2017 update[<a href="about.html">ABOUT</a>][WORLD|<a href="world02.html">The Flow of the Game</a>][CHARACTERS|<a href="character.html">Lydie</a>,<a href="character02.html">Suelle</a>,<a href="character03.html">Sophie</a>,<a href="character04.html">Firis</a>,<a href="subcharacter-6.html">Liane</a>,<a href="subcharacter-7.html?sub=character02">Ilmeria</a>][<a href="movie.html">MOVIE</a>]</li>
	
<li>9/22/2017 Official site open!</li>
</ul>
<p class="more"><a href="#more">MORE INFO</a></p>
</div>
<!--//.whatsnew-->
</div>
</div>
</div>