<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<title>IPSCLC</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>asset/css/styles.css" type="text/css" />
	<script src="http://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>

	
</head>
<body>
	<div id="header">
		<div class="area">
			<div id="logo">
				<a href="index.html"><img src="<?php echo base_url(); ?>asset/img/logo.png" alt="LOGO" height="65" width="128" /></a>
			</div>
			<?php 
				$select1 = null;
				$select2 = null;
				$select3 = null;
				$select4 = null;
				$select5 = null;
				$select6 = null;
				if($this->uri->segment(1)==null or $this->uri->segment(1)=="home"){
					$select1 = "selected";
				} elseif($this->uri->segment(1)==="about") {
					$select2 = "selected";
				} elseif($this->uri->segment(1)==="posts") {
					$select3 = "selected";
				} elseif($this->uri->segment(1)==="breaking_news") {
					$select4 = "selected";
				} elseif($this->uri->segment(1)==="contact") {
					$select5 = "selected";
				} elseif($this->uri->segment(1)==="sign_up") {
					$select6 = "selected";
				}
				 else{
					$select1 = "";
				} 
			?>
			<?php if(!isset($_SESSION['logged_in'])){ ?>
				<ul id="navigation">
					<li class = "<?= $select1 ?>">
						<a href="<?php echo base_url();?>">Home</a>
					</li>
					<li class = "<?= $select2 ?>">
						<a href="<?php echo base_url();?>about">About</a>
					</li>
					<li class = "<?= $select3 ?>">
						<a href="<?php echo base_url();?>posts">Articles</a>
					</li>
					<li class = "<?= $select4 ?>">
						<a href="<?php echo base_url();?>breaking_news">News</a>
					</li>
					<li class = "<?= $select5 ?>">
						<a href="<?php echo base_url();?>contact">Contact</a>
					</li>
					<li class = "<?= $select6 ?>">
						<a href="<?php echo base_url();?>sign_up">Register</a>
					</li>
				</ul>
			<?php } else { ?>
				<ul id="navigation">
					<li class = "<?= $select1 ?>">
						<a href="<?php echo base_url();?>">Home</a>
					</li>
					<li class = "<?= $select2 ?>">
						<a href="<?php echo base_url();?>about">About</a>
					</li>
					<li class = "<?= $select3 ?>">
						<a href="<?php echo base_url();?>posts">Articles</a>
					</li>
					<li class = "<?= $select4 ?>">
						<a href="<?php echo base_url();?>breaking_news">News</a>
					</li>
					<li class = "<?= $select6 ?>">
						<a href="<?php echo base_url();?>contact">Contact</a>
					</li>
					<li class = "<?= $select6 ?>">
						<a href="<?php echo base_url();?>my_panel">My Panel</a>
					</li>
				</ul>

			<?php } ?>
			
		</div>
	</div>
	<div class="flashdata">
		<?php if($this->session->flashdata('user_registered')){?>
			<?php echo '<p>'.$this->session->flashdata('user_registered').'</p>'; ?>
		<?php } ?>
		<?php if($this->session->flashdata('post_created')){?>
			<?php echo '<p>'.$this->session->flashdata('post_created').'</p>'; ?>
		<?php } ?>
		<?php if($this->session->flashdata('post_updated')){?>
			<?php echo '<p>'.$this->session->flashdata('post_updated').'</p>'; ?>
		<?php } ?>
		<?php if($this->session->flashdata('post_deleted')){?>
			<?php echo '<p>'.$this->session->flashdata('post_deleted').'</p>'; ?>
		<?php } ?>
		<?php if($this->session->flashdata('user_loggedin')){?>
			<?php echo '<p>'.$this->session->flashdata('user_loggedin').'</p>'; ?>
		<?php } ?>
		<?php if($this->session->flashdata('login_failed')){?>
			<?php echo '<p>'.$this->session->flashdata('login_failed').'</p>'; ?>
		<?php } ?>
		<?php if($this->session->flashdata('user_loggedout')){?>
			<?php echo '<p>'.$this->session->flashdata('user_loggedout').'</p>'; ?>
		<?php } ?>
	</div>