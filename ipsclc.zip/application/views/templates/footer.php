	<div id="footer">
		<span class="divider"></span>
		<div class="area">
			<div id="connect">
				<a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw" target="_blank" class="tele"></a> <a href="https://www.linkedin.com/groups/8513287" target="_blank" class="linkedin"></a> <a href="https://www.facebook.com/groups/569141793268777/" target="_blank" class="facebook"></a> <a href="https://twitter.com/IPSCLC1" target="_blank" class="twitter"></a> <a href="mailto:ipsclc.pusat@gmail.com?subject=Informasi&cc=andie.setiyawan@gmail.com" target="_blank" class="mail"></a>
			</div>
			<p>
				© 2018 IPSCLC. All Rights Reserved.
			</p>
		</div>
	</div>
</body>
<script> CKEDITOR.replace('editor1');</script>
<script src="<?php echo base_url(); ?>asset/js/bootstrap.min.js" type="text/javascript"></script>
</html>