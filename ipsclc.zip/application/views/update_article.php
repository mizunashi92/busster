	<div id="contents">
		<div id="blog" class="area">
			<div class="main">

				<?php 
				echo validation_errors();
				echo form_open('Posts/update'); 
				?>
				<div class="form-group">
					<label>Title</label>
					<input type="text" class="form-control" name="title" placeholder="Add title" value="<?= $post->title ?>" />
				</div>
				<div class="form-group">
					<label>Content</label>
					<textarea class="form-control" id="editor1" name="content" placeholder="Add content" ><?= $post->content ?></textarea>
				</div>
				<div class="form-group">
					<label>Category</label>
					<select class="form-control" name="category_id">
						<?php foreach($categories as $category) { ?> 
							<option value="<?php echo $category->id ?>"><?= $category->name ?></option>
						<?php } ?>
					</select>
				</div>
				<input type="hidden" name="id" value="<?= $post->id ?>">
				<button type="submit" class="btn btn-default">Submit</button>
				<?php echo form_close(); ?>
			</div>
			<div class="sidebar">
				<h2 class="heading1">My Panel</h2>
				<div class="box2">
					<div>
						<ul class="archives">
							<li><a href="<?php echo base_url(); ?>articles/create"><img src="<?php echo base_url(); ?>asset/img/create_article.png"> Create Posts</a></li>
							<li><a href="<?php echo base_url(); ?>posts/view_my_articles"><img src="<?php echo base_url(); ?>asset/img/archieve.png"> My Posts</a></li>
							<li><a href="<?php echo base_url(); ?>users/logout"><img src="<?php echo base_url(); ?>asset/img/logout.png"> Log out</a></li>
						</ul>
					</div>
				</div>	
			</div>
		</div>
	</div>
