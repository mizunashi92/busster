
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header"></div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th>Title</th>
                                    	<th>Content</th>
                                    	<th></th>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            foreach($articles as $row) : 
                                               $content  = substr($row->content,0,100);
                                        ?>
                                        <tr>
                                            <td><b><?=$row->title ?></b></td>
                                            <td><small><?=$content?></small></td>
                                            <td>
                                                <a href="<?php echo base_url();?>manage_articles/view/<?=$row->slug;?>" class="btn btn-default"><img src="<?php echo base_url();?>asset/img/read_more.png"> Read more</a>
                                            </td> 
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

      