<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Indonesia Procurement Supply Chain and Logistics</title>
	<meta name="description" content="Design and coding Wibowo Yosafat - Shang Xiang">
    <meta name="keywords" content="Wibowo Yosafat, Shang Xiang, Coder-X, Geronimo">
    <meta name="author" content="Wibowo Yosafat & Shang Xiang">
  	<meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/flexslider.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/flaticon/font/flaticon.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.theme.default.min.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
	<!-- Theme Table  -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/dataTables.bootstrap.min.css">
    <!-- CK Editor -->
    <script src="http://cdn.ckeditor.com/4.7.3/standard-all/ckeditor.js"></script>
	<!-- Modernizr JS -->
	<script src="<?php echo base_url();?>assets/js/modernizr-2.6.2.min.js"></script>
	
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
	<div id="colorlib-page">
		<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
		<aside id="colorlib-aside" role="complementary" class="border js-fullheight">
			<h1 id="colorlib-logo"><a href="index.html">IPSCLC</a></h1>
			<nav id="colorlib-main-menu" role="navigation">
				<ul>
					<li class="<?php if($this->uri->segment(1) == 'dashboard'){echo "colorlib-active";}?>""><a href="<?php echo base_url();?>dashboard">Home</a></li>
					<li class="<?php if($this->uri->segment(1) == 'portfolio'){echo "colorlib-active";}?>""><a href="<?php echo base_url();?>portfolio">Portfolio</a></li>
					<?php 
						if($_SESSION['role_id'] == 1 AND $this->uri->segment(1) == 'admin') {
							echo"
							<li class='colorlib-active'><a href='".base_url()."admin'>Admin Page</a></li>
							<li><a href='".base_url()."articles'>Articles</a></li>";
						}elseif($_SESSION['role_id'] == 1 AND $this->uri->segment(1) == 'articles') {
							echo"
							<li><a href='".base_url()."admin'>Admin Page</a></li>
							<li  class='colorlib-active'><a href='".base_url()."articles'>Articles</a></li>";
						}elseif($_SESSION['role_id'] == 1 ){
							echo"
							<li><a href='".base_url()."admin'>Admin Page</a></li>
							<li><a href='".base_url()."articles'>Articles</a></li>";
						}elseif($_SESSION['role_id'] == 2 ){
							echo"
							<li><a href='".base_url()."articles'>Articles</a></li>";
						}else{

						}
					?>
					<li><a href="<?php echo base_url(); ?>Auth/logout">Log Out</a></li>
				</ul>
			</nav>

			<div class="colorlib-footer">
				<p><small>&copy; <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made through joint collaboration of Geronimo - ShangXiang Creative Web <i class="icon-heart" aria-hidden="true"></i><span> with  <a href="https://colorlib.com" target="_blank"><font size="-1">Colorlib</font></a></span>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --> </span>
				<ul>
					<li><a href="#"><i class="icon-facebook2"></i></a></li>
					<li><a href="#"><i class="icon-twitter2"></i></a></li>
					<li><a href="#"><i class="icon-instagram"></i></a></li>
					<li><a href="#"><i class="icon-linkedin2"></i></a></li>
				</ul>
			</div>

		</aside>