
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                               <a href="<?php echo base_url();?>categories/create"> <img src="<?php echo base_url();?>asset/img/create.png"> </a>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th>Name</th>
                                    </thead>
                                    <tbody>
                                        <?php foreach($categories as $row): ?>
                                        <tr>
                                            <td><?=$row->name; ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

      