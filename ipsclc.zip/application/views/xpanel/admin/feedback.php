<div id="colorlib-main">

			<div class="colorlib-blog">
				<div class="colorlib-narrow-content">
					<h3 align = "center">News Panel</h3>
					<div class="main">
						<?php 
						if(validation_errors()){echo "<div class='alert alert-danger'>
						<strong>Warning!</strong>"
						.validation_errors()
						."</div>";}
						if($this->session->flashdata('error')){echo "<div class='alert alert-danger'>
					  	<strong>Warning!</strong>"
						.$this->session->flashdata('error')
						."</div>";}
						echo form_open('admin/dofeedback'); 
						?>

						<div class="form-group">
							<label>Reason</label>
							<textarea class="form-control" id="editor1" name="reason" required></textarea>
						</div>
						<input type="hidden" name="id" value="<?= $post->id ?>">
						<button type="submit" class="btn btn-default">Submit</button>
						
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>