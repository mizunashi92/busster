<div id="colorlib-main">

			<div class="colorlib-blog">
				<div class="colorlib-narrow-content">
					<h3 align = "center">News Panel</h3>
					<div class="main">
						<div class="form-group">
							<h3><?= $news->title ?></h3>
						</div>
						<div class="form-group">
							<?= $news->short ?>
						</div>
						<div class="form-group">
							<?= $news->content ?>
						</div>
						<div class="form-group">
							<b>Tags:</b>
							<?php 
								$tags = $news->tags;
								$tag = explode(",", $tags);
								 
								for ( $i = 0; $i < count( $tag ); $i++ ) {
									echo " <span class='label label-default'> ". $tag[$i] . " </span> &nbsp;";
								}
							?>
						</div>
						<div class="form-group">
							<img src="<?php echo base_url();?>assets/news/<?=$news->img ?>" style="width: 150px;">
	    				</div>
					</div>
				</div>
			</div>
		</div>