<div id="colorlib-main">

			<div class="colorlib-about">
				<h3 align="center">News Panel</h3>
				
				<?php
						if($this->session->flashdata('news_updated')){echo "<div class='alert alert-success'>
					  	<strong>Success!</strong>"
						.$this->session->flashdata('news_updated')
						."</div>";}
						if($this->session->flashdata('news_deleted')){echo "<div class='alert alert-success'>
						<strong>Success!</strong>"
						.$this->session->flashdata('news_deleted')
						."</div>";}
						if($this->session->flashdata('articles_deleted')){echo "<div class='alert alert-success'>
						<strong>Success!</strong>"
						.$this->session->flashdata('articles_deleted')
						."</div>";}
						if($this->session->flashdata('articles_feedback')){echo "<div class='alert alert-success'>
						<strong>Success!</strong>"
						.$this->session->flashdata('articles_feedback')
						."</div>";}
					?>
				<a href="<?php echo base_url(); ?>admin/create" class="btn btn-primary">+</a>	
				<table id="news_panel" class="table table-striped table-bordered" style="width:100%">
			        <thead>
			            <tr>
			                <th>Title</th>
			                <th>Short</th>
			                <th>Content</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php foreach($news as $row) : ?>	
			            <tr>
			                <td><?php echo substr($row['title'], 0, 30); ?></td>
			                <td><?php echo substr($row['short'], 0, 30); ?></td>
			                <td><?php echo substr($row['content'], 0, 30); ?></td>
			                <td>
			                	<a class="btn btn-info btn-xs pull-left" href="<?php echo site_url('/admin/read/'.$row['slug']); ?>"><span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
			                	</a> 
								<a class="btn btn-success btn-xs pull-left" href="<?php echo site_url('/admin/update/'.$row['slug']); ?>"><span class="icon"><i class="flaticon-worker"></i></span>
								</a>
								<?php echo form_open('/admin/doDelete/'.$row['id']); ?>
									<input type="submit" value="D" class="btn btn-danger btn-xs flaticon-skyline">
								</form>
							</td>
			            </tr>
			            <?php endforeach; ?>
			        </tbody>
			        <tfoot>
			            <tr>
			                <th>Title</th>
			                <th>Short</th>
			                <th>Content</th>
			                <th>Action</th>
			            </tr>
			        </tfoot>
			    </table>
			</div>
			
			<div class="colorlib-about">
				<h3 align="center">Approval Articles</h3>
				<table id="approval_articles" class="table table-striped table-bordered" style="width:100%">
			        <thead>
			            <tr>
			                <th>Title</th>
			                <th>Content</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php foreach($approval as $app) : ?>	
			            <tr>
			                <td><?php echo substr($app->title, 0, 50); ?></td>
			                <td><?php echo substr($app->content, 0, 50); ?></td>
			                <td>
			                	<a class="btn btn-info btn-xs pull-left" href="<?php echo site_url('/admin/doApproval/'.$app->id); ?>"><span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
			                	</a> 
			                	
								<a class="btn btn-success btn-xs pull-left" href="<?php echo site_url('/admin/feedback/'.$app->slug); ?>"><span class="icon"><i class="flaticon-worker"></i></span>
								</a>
								<a class="btn btn-danger btn-xs pull-left" href="<?php echo site_url('/admin/doReject/'.$app->id); ?>"><span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
			                	</a> 
								
							</td>
			            </tr>
			            <?php endforeach; ?>
			        </tbody>
			        <tfoot>
			            <tr>
			                <th>Title</th>
			                <th>Content</th>
			                <th>Action</th>
			            </tr>
			        </tfoot>
			    </table>
			</div>
			
			
		<div id="colorlib-counter" class="colorlib-counters" style="background-image: url(<?php echo base_url();?>assets/images/cover_bg_1.jpg);" data-stellar-background-ratio="0.5">
				<div class="overlay"></div>
				<div class="colorlib-narrow-content">
					<div class="row">
					</div>
					<div class="row">
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-skyline"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $submitted->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Articles Submitted</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-engineer"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $approved->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Approved</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $rank->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Current Rank</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-worker"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $whole->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Whole IPSCLC Articles</span>
						</div>
					</div>
				</div>
			</div>

			
		</div>