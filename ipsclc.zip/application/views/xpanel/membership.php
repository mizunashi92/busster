        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th>Email</th>
                                    	<th>Role as</th>
                                    </thead>
                                    <tbody>
                                    <?php 
                                        foreach($member as $row) :
                                            
                                            if($row->role_id ==1) {
                                                $role = "Administrator";
                                            }else{
                                                $role = "Member";
                                            }
                                    ?>
                                        <tr>
                                            <td><?=$row->email; ?></td>
                                            <td><?=$role; ?></td>
                                        </tr>     
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
