<div id="colorlib-main">

			<div class="colorlib-contact">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta">Experiences</span>
							<h2 class="colorlib-heading">Fill your Details</h2>
						</div>
					</div>
					<?php echo form_open('portfolio/update_portfolio'); ?>
					<div class="row">
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
									 	<h3 class="one">Nama</h3>
										<div class="form-group">
											<textarea id="message" cols="30" rows="7" class="form-control" placeholder="Jelaskan secara singkat mengenai diri anda" name="desc" required><?= $portfolio['desc']; ?></textarea>
										</div>
										<div class="form-group">
											<textarea id="message" cols="30" rows="3" class="form-control" placeholder="Bidang yang diminati" name="course" required><?= $portfolio['course']; ?></textarea>
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Total Pengalaman Kerja" name="total" required value="<?= $portfolio['total']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Pendidikan Terakhir" name="study" required value="<?= $portfolio['study']; ?>">
										</div>
								</div>					
							</div>
						</div>
					</div>
					<div><br><br></div>
					<div class="row">
						<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
							<h3 class="one">Riwayat Pekerjaan</h3><h4>(3 Pekerjaan Terakhir)</h4>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama Institusi" name="nama_a"  value="<?= $portfolio['nama_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Posisi" name="posisi_a" value="<?= $portfolio['posisi_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Divisi" name="divisi_a" value="<?= $portfolio['divisi_a']; ?>">
										</div>
										<div class="form-group ">
											<input type="text" class="form-control" placeholder="Bergabung Sejak (dd/mm/yyyy)" name="start_a" value="<?= $portfolio['start_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Hingga (dd/mm/yyyy)" name="end_a" value="<?= $portfolio['end_a']; ?>">
										</div>
										<div class="form-group">
											<textarea id="message" cols="30" rows="7" class="form-control" placeholder="Deskripsi mengenai job-desc dan pencapaian" name="desc_a"><?= $portfolio['desc_a']; ?></textarea>
										</div>
										<br>
								</div>					
							</div>
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-push-1 animate-box" data-animate-effect="fadeInLeft">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama Institusi" name="nama_b" value="<?= $portfolio['nama_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Posisi" name="posisi_b" value="<?= $portfolio['posisi_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Divisi" name="divisi_b" value="<?= $portfolio['divisi_b']; ?>">
										</div>
										<div class="form-group ">
											<input type="text" class="form-control" placeholder="Bergabung Sejak (dd/mm/yyyy)" name="start_b" value="<?= $portfolio['start_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Hingga (dd/mm/yyyy)" name="end_b" value="<?= $portfolio['end_b']; ?>">
										</div>
										<div class="form-group">
											<textarea id="message" cols="30" rows="7" class="form-control" placeholder="Deskripsi mengenai job-desc dan pencapaian" name="desc_b"><?= $portfolio['desc_b']; ?></textarea>
										</div>
										<br>
								</div>					
							</div>
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama Institusi" name="nama_c" value="<?= $portfolio['nama_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Posisi" name="posisi_c" value="<?= $portfolio['posisi_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Divisi" name="divisi_c" value="<?= $portfolio['divisi_c']; ?>">
										</div>
										<div class="form-group ">
											<input type="text" class="form-control" placeholder="Bergabung Sejak (dd/mm/yyyy)" name="start_c" value="<?= $portfolio['start_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Hingga (dd/mm/yyyy)" name="end_c" value="<?= $portfolio['end_c']; ?>">
										</div>
										<div class="form-group">
											<textarea id="message" cols="30" rows="7" class="form-control" placeholder="Deskripsi mengenai job-desc dan pencapaian" name="desc_c"><?= $portfolio['desc_c']; ?></textarea>
										</div>
										<br>
								</div>					
							</div>
						</div>
					</div>
					<div><br><br></div>
					<div class="row">
						<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
							<h3 class="one">Riwayat Pendidikan</h3><h4>(3 Pendidikan Terakhir)</h4>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama Institusi" name="nama_a" value="<?= $portfolio['nama_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Jenjang" name="jenjang_a" value="<?= $portfolio['jenjang_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Peminatan/Jurusan" name="jurusan_a" value="<?= $portfolio['jurusan_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Tahun kelulusan" name="tahun_a" value="<?= $portfolio['tahun_a']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nilai akhir/IPK" name="nilai_a" value="<?= $portfolio['nilai_a']; ?>">
										</div>
										<br>
								</div>					
							</div>
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-push-1 animate-box" data-animate-effect="fadeInLeft">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama Institusi" name="nama_b" value="<?= $portfolio['nama_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Jenjang" name="jenjang_b" value="<?= $portfolio['jenjang_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Peminatan/Jurusan" name="jurusan_b" value="<?= $portfolio['jurusan_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Tahun kelulusan" name="tahun_b" value="<?= $portfolio['tahun_b']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nilai akhir/IPK" name="nilai_b" value="<?= $portfolio['nilai_b']; ?>">
										</div>
								</div>					
							</div>
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama Institusi" name="nama_c" value="<?= $portfolio['nama_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Jenjang" name="jenjang_c" value="<?= $portfolio['jenjang_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Peminatan/Jurusan" name="jurusan_c" value="<?= $portfolio['jurusan_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Tahun kelulusan" name="tahun_c" value="<?= $portfolio['tahun_c']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nilai akhir/IPK" name="nilai_c" value="<?= $portfolio['nilai_c']; ?>">
										</div>
										<div class="form-group">
											<input type="submit" class="btn btn-primary btn-send-message" value="Simpan">
										</div>
										<br>
									
								</div>					
							</div>
						</div>
					</div>
					</form>
				</div>
			</div>


			
		</div>