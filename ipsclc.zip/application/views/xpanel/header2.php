<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url(); ?>asset/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="<?php echo base_url(); ?>asset/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>X-Panel</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url(); ?>asset/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url(); ?>asset/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="<?php echo base_url(); ?>asset/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url(); ?>asset/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url(); ?>asset/css/themify-icons.css" rel="stylesheet">

</head>

<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
        Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
        Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
    -->

        <?php 
            $select1 = null;
            $select2 = null;
            $select3 = null;
            $select4 = null;
                if($this->uri->segment(1)=="dashboard"){
                    $select1 = "active";
                    $title = "Dashboard";
                } elseif($this->uri->segment(1)==="membership") {
                    $select2 = "active";
                    $title = "Users";
                } elseif($this->uri->segment(1)==="manage_articles") {
                    $select3 = "active";
                    $title = "Articles";
                } elseif($this->uri->segment(1)==="categories") {
                    $select4 = "active";
                    $title = "Categories";
                } else{
                    $select1 = "";
                } 
                
        ?>

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="<?php echo base_url();?>dashboard" class="simple-text">
                    IPSCLC X-Panel
                </a>
            </div>
                    <ul class="nav">
                <li class= "<?= $select1 ?>">
                    <a href="<?php echo base_url();?>dashboard">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
               <li class= "<?= $select2 ?>">
                    <a href="<?php echo base_url();?>membership">
                        <i class="ti-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li class= "<?= $select3 ?>">
                    <a href="<?php echo base_url();?>manage_articles">
                        <i class="ti-file"></i>
                        <p>Articles</p>
                    </a>
                </li>
                <li class= "<?= $select4 ?>">
                    <a href="<?php echo base_url();?>categories">
                        <i class="ti-view-list-alt"></i>
                        <p>Categories</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#"> <?= $title; ?></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="<?php echo base_url(); ?>Auth/logout">
                                <i class="ti-settings"></i>
                                <p>Logout</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
            <?php if($this->session->flashdata('category_created')): ?>
            <?php 
                echo '<p class="alert alert-success">'.$this->session->flashdata('category_created').'</p>'; 
            ?>
            <?php endif; ?>
             <?php if($this->session->flashdata('article_approved')): ?>
            <?php 
                echo '<p class="alert alert-success">'.$this->session->flashdata('article_approved').'</p>'; 
            ?>
            <?php endif; ?>
             <?php if($this->session->flashdata('article_rejected')): ?>
            <?php 
                echo '<p class="alert alert-danger">'.$this->session->flashdata('article_rejected').'</p>'; 
            ?>
            <?php endif; ?>
                </div>
            </div>
        </div>
