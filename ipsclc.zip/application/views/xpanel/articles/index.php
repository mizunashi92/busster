<div id="colorlib-main">

			<div class="colorlib-blog">
				<div class="colorlib-narrow-content">
					<h3 align = "center">Articles Panel</h3>
					
					<?php
						if($this->session->flashdata('article_updated')){echo "<div class='alert alert-success'>
					  	<strong>Success!</strong>"
						.$this->session->flashdata('article_updated')
						."</div>";}
						if($this->session->flashdata('articles_deleted')){echo "<div class='alert alert-success'>
						<strong>Success!</strong>"
						.$this->session->flashdata('articles_deleted')
						."</div>";}
					?>
					 <a href="<?php echo base_url(); ?>articles/create" class="btn btn-primary">+</a>
					<table id="news_panel" class="table table-striped table-bordered" style="width:100%">
				        <thead>
				            <tr>
				                <th>Title</th>
				                <th>Content</th>
				                <?php if($_SESSION['role_id']==2){
				                	echo " <th>Status/Reason</th>";
				                }?>
				                <th>Action</th>
				            </tr>
				        </thead>
				        <tbody>
				        	<?php foreach($posts as $row) : ?>	
				            <tr class=<?php if($row->status==0){ echo 'info';}elseif($row->status==2){echo 'warning';} ?>>
				                <td><a href="#" data-toggle="tooltip" title="<?=$row->reason?>"><?php echo substr($row->title, 0, 30); ?></a></td>
				                <td><?php echo substr($row->content, 0, 30); ?></td>
				                <?php if($_SESSION['role_id']==2){
				                	echo "<td>";
					                	if($row->status==0){
					                		echo "Pending";
					                	}elseif($row->status==1){
					                		echo "Published";
					                	}else{
					                		echo "Feedback";
					                	}
					                	echo "</td>";
				                	}
				                	?>
				            	
				                <td>
				                	<a class="btn btn-info btn-xs pull-left" href="<?php echo site_url('/articles/read/'.$row->slug); ?>"><span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
				                	</a> 
									<a class="btn btn-success btn-xs pull-left" href="<?php echo site_url('/articles/update/'.$row->slug); ?>"><span class="icon"><i class="flaticon-worker"></i></span>
									</a>
									<?php echo form_open('/articles/doDelete/'.$row->id); ?>
										<input type="submit" value="D" class="btn btn-danger btn-xs flaticon-skyline">
									</form>
								</td>
				            </tr>
				            <?php endforeach; ?>
				        </tbody>
				        <tfoot>
				            <tr>
				                <th>Title</th>
				                <th>Content</th>
				                <th>Action</th>
				            </tr>
				        </tfoot>
				    </table>
				</div>
			</div>
		</div>