<div id="colorlib-main">

			<div class="colorlib-blog">
				<div class="colorlib-narrow-content">
					<h3 align = "center">Articles Panel</h3>
					<div class="main">
						
						<div class="form-group">
							<h3><?= $post->title ?></h3>
						</div>
						<div class="form-group">
							<?= $post->content ?>
						</div>
						<div class="form-group">
							<b>Tags:</b>
							<?php 
								$tags = $post->tags;
								$tag = explode(",", $tags);
								 
								for ( $i = 0; $i < count( $tag ); $i++ ) {
									echo " <span class='label label-default'> ". $tag[$i] . " </span> &nbsp;";
								}
							?>
						</div>
						<div class="form-group">
							<img src="<?php echo base_url();?>assets/articles/<?=$post->img ?>" style="width: 150px;">
	    				</div>
					</div>
				</div>
			</div>
		</div>