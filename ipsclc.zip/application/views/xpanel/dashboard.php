		<div id="colorlib-main">

			<div class="colorlib-contact">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta">Profile Data</span>
							<h2 class="colorlib-heading">Fill your Details</h2>
						</div>
					</div>
					<div class="row">
						<?php echo form_open_multipart('dashboard/update_profile'); ?>
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
									
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nama" name="name" required value="<?= $profile['name']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Email" name="email" value="<?= $profile['email']; ?>" required>
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Nomor HP/Telpon" name="phone" value="<?= $profile['phone']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Tempat Lahir" name="ttl" value="<?= $profile['ttl']; ?>">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Tanggal Lahir (dd/mm/yyyy)" name="tgl" value="<?= $profile['tgl']; ?>">
										</div>
										<div class="form-group">
											<input type="submit" class="btn btn-primary btn-send-message" value="Simpan">
										</div>
									
								</div>
								
							</div>
						</div>
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
									<div class="form-group text-center">
										<img class="img-s" src="<?php echo base_url(); ?>assets/users/<?= $profile['img'];?>" alt="" width="128px">
									</div>
									<div class="form-group">
										<textarea id="message" cols="30" rows="7" class="form-control" placeholder="Alamat" name="address"><?= $profile['address']; ?></textarea>
									</div>
									<div class="form-group">
										<input type="hidden" name="image" value="<?= $profile['img'];?>">
										<input type="file" name="userfile"  size="20" />
									</div>
								</div>
								
							</div>
						</div>
						</form>
					</div>
				</div>
			</div>
		<div id="colorlib-counter" class="colorlib-counters" style="background-image: url(<?php echo base_url();?>assets/images/cover_bg_1.jpg);" data-stellar-background-ratio="0.5">
				<div class="overlay"></div>
				<div class="colorlib-narrow-content">
					<div class="row">
					</div>
					<div class="row">
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-skyline"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $submitted->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Articles Submitted</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-engineer"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $approved->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Approved</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $rank->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Current Rank</span>
						</div>
						<div class="col-md-3 text-center animate-box">
							<span class="icon"><i class="flaticon-worker"></i></span>
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?= $whole->total ?>" data-speed="5000" data-refresh-interval="50"></span>
							<span class="colorlib-counter-label">Whole IPSCLC Articles</span>
						</div>
					</div>
				</div>
			</div>

			
		</div>
	