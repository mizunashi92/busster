<div id="colorlib-main">

			<div class="colorlib-blog">
				<div class="colorlib-narrow-content">
					<h3 align = "center">Articles Panel</h3>
					<table id="news_panel" class="table table-striped table-bordered" style="width:100%">
				        <thead>
				            <tr>
				                <th>Title</th>
				                <th>Content</th>
				                <th>Action</th>
				            </tr>
				        </thead>
				        <tbody>
				        	<?php foreach($posts as $row) : ?>	
				            <tr>
				                <td><?php echo substr($row->title, 0, 30); ?></td>
				                <td><?php echo substr($row->content, 0, 30); ?></td>
				                <td>
				                	<a class="btn btn-info btn-xs pull-left" href="<?php echo site_url('/admin/read_posts/'.$row->slug); ?>"><span class="icon"><i class="flaticon-architect-with-helmet"></i></span>
				                	</a> 
									<a class="btn btn-success btn-xs pull-left" href="<?php echo site_url('/admin/update_posts/'.$row->slug); ?>"><span class="icon"><i class="flaticon-worker"></i></span>
									</a>
									<?php echo form_open('/admin/delete_posts/'.$row->slug); ?>
										<input type="submit" value="D" class="btn btn-danger btn-xs flaticon-skyline">
									</form>
								</td>
				            </tr>
				            <?php endforeach; ?>
				        </tbody>
				        <tfoot>
				            <tr>
				                <th>Title</th>
				                <th>Content</th>
				                <th>Action</th>
				            </tr>
				        </tfoot>
				    </table>
				</div>
			</div>

			
		</div>