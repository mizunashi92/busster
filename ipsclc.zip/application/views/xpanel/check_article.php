        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                              
                            </div>
                            <div class="content table-responsive table-full-width">
                              <table class="table table-striped">
                                <thead>
                                  <tr><th><?= $article->title ?></th></tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td><?= $article->content ?></td>
                                  </tr>
                                  <tr>
                                    <td class="text-center">
                                        <a href="<?php echo base_url();?>manage_articles/approve/<?=$article->id;?>" class="btn btn default">Approve</a>
                                        <a href="<?php echo base_url();?>manage_articles/reject/<?=$article->id;?>" class="btn btn danger">Reject</a>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

      