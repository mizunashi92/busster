	<div id="contents">
		<div id="blog" class="area">
			<div class="main">
				<ul class="list">
					<?php if(isset($empty)){ ?>
						<div><em><?= $empty ?></em></div>
					<?php } else {?>
					<?php foreach($posts as $row){ 
						$content  = substr($row->content,0,200);
						?>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/articles/<?= $row->img; ?>" alt="Img" height="130" width="130" />
							<div>
								<h3><?= $row->title ?> </h3>
								<p><?= $content ?> </p>
								<span class="views"><a href="<?php echo site_url('posts/view_my_article/'.$row->slug); ?>">Read more</a></span> <span class="time"><?= $row->upload_on ?> in <?= $row->name ?> <br>by <?= $row->email ?></span>
							</div>
						</li>
					<?php } }?>
				</ul>
				<div class="pagination">
					<ul>
						<li>
							<a href="blog.html">First</a>
						</li>
						<li class="selected">
							<a href="blog.html">1</a>
						</li>
						<li>
							<a href="blog.html">2</a>
						</li>
						<li>
							<a href="blog.html">3</a>
						</li>
						<li>
							<a href="blog.html">4</a>
						</li>
						<li>
							<a href="blog.html">5</a>
						</li>
						<li>
							<a href="blog.html">6</a>
						</li>
						<li>
							<a href="blog.html">7</a>
						</li>
						<li>
							<a href="blog.html">8</a>
						</li>
						<li>
							<a href="blog.html">9</a>
						</li>
						<li>
							<a href="blog.html">10</a>
						</li>
						<li class="last">
							<a href="blog.html">Last</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="sidebar">
				<h2 class="heading1">My Panel</h2>
				<div class="box2">
					<div>
						<ul class="archives">
							<li><a href="<?php echo base_url(); ?>articles/create"><img src="<?php echo base_url(); ?>asset/img/create_article.png"> Create Posts</a></li>
							<li><a href="<?php echo base_url(); ?>posts/view_my_articles"><img src="<?php echo base_url(); ?>asset/img/archieve.png"> My Posts</a></li>
							<li><a href="<?php echo base_url(); ?>users/logout"><img src="<?php echo base_url(); ?>asset/img/logout.png"> Log out</a></li>
						</ul>
					</div>
				</div>	
			</div>
		</div>
	</div>
