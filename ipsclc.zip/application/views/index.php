	<div id="contents">
		<div id="adbox">
			<div class="area">
				<ul>
					<li>
						<div>
							<h2><span>Knowledge</span> Sharing</h2>
							<p>
								Discuss about Procurement and SCM at <a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw">IPSCLC Telegram</a>
							</p>
						</div>
					</li>
					<li>
						<div>
							<h2><span>Job</span> Vacancy</h2>
							<p>
								Need information on Job Vacancy? Join us at <a href="https://t.me/joinchat/AAAAAEAejzNnRwO2A4kJiQ">IPSCLC Loker Group</a>
							</p>
						</div>
					</li>
					<li>
						<div>
							<h2><span>Training</span> and Certifications</h2>
							<p>
								See our galery at <a href="http://www.ipsclc.com/">IPSCLC Galery</a>
							</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<div class="area">
			<div class="main">
				<h2>INDONESIA PROCUREMENT SUPPLY CHAIN AND LOGISTICS</h2>
				<p>
					This is Indonesia Procurement Supply Chain and Logiatics community that is not affiliated with any specific company, Industry, organization or agency.
					IPSCLC seeks to bring together the best mind in business and industry to freely share knowledge, experiences and insights so that members can benefit.
				</p>
				<div id="features">
					<h2>WHO WE ARE?</h2>
					<ul>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/agents.png" alt="Img" height="100" width="100" />
							<h3>Training</h3>
							<p>
								Get our latest updates on trainings on our <a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw">IPSCLC Telegram</a>
							</p>
						</li>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/shopping.png" alt="Img" height="100" width="100" />
							<h3>Group Discussion</h3>
							<p>
								We invite great minds to discuss on our group chat at <u><a href="https://t.me/joinchat/D_ibeEtfItu4jIaXtq1HGw">IPSCLC Telegram</a></u>
							</p>
						</li>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/smiling.png" alt="Img" height="100" width="100" />
							<h3>Bonding</h3>
							<p>
								Widen your network through IPSCLC, a social community for people with procurement, inventory, logistics and supply chain background as well as enthusiasts on the subjects.
							</p>
						</li>
						<li>
							<img src="<?php echo base_url(); ?>asset/img/buildings.png" alt="Img" height="100" width="100" />
							<h3>Consultation</h3>
							<p>
								We are composed of several people with different backgrounds with years of experience in the implementation and consultation areas. Feel free to contact us <a href="contact.php">here</a>.
							</p>
						</li>
					</ul>
				</div>
			</div>
			<div class="blog">
				<h2>Vision and Mission</h2>
				<div class="frame">
					<img src="<?php echo base_url(); ?>asset/img/checker.jpg" alt="Img" height="216" width="268" />
				</div>
				<h3>Vision Statement</h3>
				<p>
					To be the biggest and the strongest  independent community of  Procurement ,Supply Chain and Logistics in indonesia.
									</p>
				<h3>Mission Statement</h3>
				<p>
					IPSCLC seeks to assemble the best minds in business and industry to freely share knowledge, experiences and insights for the betterment of Indonesian Procurement and Supply Chain Management as a derived benefit for its members.
				</p>
			</div>
		</div>
	</div>