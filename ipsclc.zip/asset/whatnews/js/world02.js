﻿$(document).ready(function(){

	$(window).on('load',function(){
  var mySwiper = new Swiper ('.cont01 .swiper-container', {
    loop: true,
		centeredSlides: true,
 slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
        paginationClickable: true
  });  
  var mySwiper2 = new Swiper ('.cont02 .swiper-container.step1', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideNextStart : function(swiper) {
		}
  });
  var mySwiper3 = new Swiper ('.cont02 .swiper-container.step2', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide2-text').hide();
			$('.slide2-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper4 = new Swiper ('.cont02 .swiper-container.step3', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide3-text').hide();
			$('.slide3-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper5 = new Swiper ('.cont02 .swiper-container.step4', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideNextStart : function(swiper) {
		}
  });
  var mySwiper6 = new Swiper ('.cont04 .swiper-container', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide4-text').hide();
			$('.slide4-text').eq(swiper.activeIndex).show();
		}
  });
  
	
	});

});
