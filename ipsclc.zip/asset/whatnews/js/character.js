﻿$(document).ready(function(){

charaloadcheck();
function charaloadcheck(){
	if($('.imgloaded')[0]){
		openigstart();
	}else{
		setTimeout(charaloadcheck,100);
	}
}
function openigstart(){
	if($('#baseW').width()>640){
		$.wait(400,function(){$('.wall-character').addClass('show');});
		$.wait(400,function(){$('.wall-premium').addClass('show');});
		$.wait(1100,function(){$('main .wrap').addClass('show');});
		$.wait(1350,function(){$('p.wall-change').addClass('show');});
		$.wait(1350,function(){$('ul.wall-premiumchange').addClass('show');});
		$.wait(1350,function(){$('.wall-character div a').addClass('show');});
		$.wait(1350,function(){$('.wall-premium div a').addClass('show');});
		$.wait(2300,function(){$('.pagearr').addClass('show');});
	}else{
		$.wait(400,function(){$('.wall-character').addClass('show');});
		$.wait(400,function(){$('.wall-premium').addClass('show');});
		$.wait(1100,function(){$('p.wall-change').addClass('show');});
		$.wait(1100,function(){$('ul.wall-premiumchange').addClass('show');});
		$.wait(1100,function(){$('.wall-character div a').addClass('show');});
		$.wait(1100,function(){$('.wall-premium div a').addClass('show');});
		$.wait(2050,function(){$('.pagearr').addClass('show');});
	}
	$('.swiper-container').each(function(){
		if($(this).find('.swiper-slide').length>1){
		
		}else{
			$(this).find('.swiper-pagination').remove();
			$(this).find('.swiper-button-prev').remove();
			$(this).find('.swiper-button-next').remove();
		}
	});
	var mySwiper = new Swiper ('.swiper-container', {
    loop: false,
		//effect:'fade',
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true
  });  
	
}

/* premium 無し */
$('.wall-character div a').on('click',function(){
	$('.wall-character .illust,.wall-character .model3d').toggleClass('zoom');
	return false;
});

$('p.wall-change a').on('click',function(){
	$('.wall-character').toggleClass('model');
	$(this).toggleClass('model');
	return false;
});

/* premium 有り */
$('.wall-premium div a').on('click',function(){
	$('.wall-premium .illust,.wall-premium .model3d,.wall-premium .premium').toggleClass('zoom');
	return false;
});

var premiumclass = ['change-illust','change-model','change-premium'];
$('ul.wall-premiumchange a').on('click',function(){
	if($('ul.wall-premiumchange.play')[0]){return false;}
	$('ul.wall-premiumchange').addClass('play');
	$('ul.wall-premiumchange').wait(500).removeClass('play');
	if($(this).hasClass('active')){return false;}
	$index = $('ul.wall-premiumchange a').index(this);
	$('.wall-premium').removeClass(function(index, className) {
		return (className.match(/change\-\S+/g) || []).join(' ');
	});
	$('.wall-premium').addClass(premiumclass[$index]);
	$('ul.wall-premiumchange a.active').removeClass('active');
	$(this).addClass('active');
	return false;
});


var tapCount = 0 ;
if(641>$('#baseW').width()){
	
	//k拡大縮小
	$( ".wall-character" ).on( "touchstart", function() {
	// シングルタップ判定
	if( !tapCount ) {
		++tapCount ;
		setTimeout( function() {
			tapCount = 0 ;
		}, 350 ) ;

	// ダブルタップ判定
	} else {
		$('.wall-character div a').eq(0).trigger('click');
		tapCount = 0 ;
	}
	});
	$( ".wall-premium" ).on( "touchstart", function() {
	// シングルタップ判定
	if( !tapCount ) {
		++tapCount ;
		setTimeout( function() {
			tapCount = 0 ;
		}, 350 ) ;

	// ダブルタップ判定
	} else {
		$('.wall-premium div a').eq(0).trigger('click');
		tapCount = 0 ;
	}
	});
	//切り替え
  $('.wall-character').on('touchstart', onTouchStart); //指が触れたか検知
  $('.wall-character').on('touchmove', onTouchMove); //指が動いたか検知
  $('.wall-character').on('touchend', onTouchEnd); //指が離れたか検知
  var direction, position;
  //スワイプ開始時の横方向の座標を格納
  function onTouchStart(event) {
    position = getPosition(event);
    direction = ''; //一度リセットする
  }
  //スワイプの方向（left／right）を取得
  function onTouchMove(event) {
    if (position - getPosition(event) > 70) {
      direction = 'left';
    } else if (position - getPosition(event) < -70){
      direction = 'right';
    }
  }
  function onTouchEnd(event) {
    if (direction == 'right'){
			if($('.wall-character.model')[0]){
				$('p.wall-change a').eq(0).trigger('click');
			}else{
			}
    } else if (direction == 'left'){
			if($('.wall-character.model')[0]){
			}else{
				$('p.wall-change a').eq(0).trigger('click');
			}
    }
  }
  //横方向の座標を取得
  function getPosition(event) {
    return event.originalEvent.touches[0].pageX;
  }
	
}

/*
	top
*/
if(641>$('#baseW').width()){
}else{
	$('.characterlist-wrap ul.main li a').on('mousemove',function(){
		var $index = $('.characterlist-wrap ul.main li a').index(this);
		/*
		$('.characterlist-wrap .characterlist-illust li').removeClass('hover');
		$('.characterlist-wrap .characterlist-illust li').eq($index).addClass('hover');
		*/
		$('.characterlist-wrap').removeClass(function(index, className) {
			return (className.match(/\hover\S+/g) || []).join(' ');
		});
		$('.characterlist-wrap').addClass('hover' + $index );
	}).on('mouseleave',function(){
		$('.characterlist-wrap').removeClass(function(index, className) {
			return (className.match(/\hover\S+/g) || []).join(' ');
		});
	});
}
	/**
		img modal
	*/
	var imgmodalw = '96%';
	if($('#baseW').width()>640) {
		imgmodalw = '1000px';
	}
	$(".imgmodal-lsize").colorbox({
		maxWidth:imgmodalw,
		rel:'imgmodal-lsize',
		speed:800,
		returnFocus:false,
		retinaImage:true
	});
	if($(".imgmodal").length>1){
		$('body').addClass('cboxpageing');
	}



/*
$(window).mousemove(function(){
	$(".wall-character").css({top:0-((event.clientY - ($(window).height()/2))/5)});
});
*/
	/**
		voice
	*/
	if(document.createElement('audio').canPlayType){
		$('body').append('<div id="voicePlayer"></div>');
		$('.voice li a').on('click',function(){
			var $mp3 = $(this).attr('href');
			var voice = new Audio($mp3);
			$('#voicePlayer').html(voice);
			voice.play();
			return false;
		});
		$('.voice ul').show();
	}else{
		$('.voice ul').remove();
	}

	/**
	cast modal
	*/
	if($('.castmodal')[0]){
		$('.castmodaltoggle').on('click',function(){
			$('body').toggleClass('castmodalopen');
			return false;
		});
		checkcastmodal();
		$(window).on('resize load',function(){
			checkcastmodal();
		});
	}
	function checkcastmodal(){
		if(641>$('#baseW').width()){
			$('.castmodal').css('height',$(window).outerHeight()-$('.castmodal .close').outerHeight());
			$('.castmodal').css('top',($(window).height()-$('.castmodal').height())/2);
			$('.castmodal article').css('height',($('.castmodal').innerHeight() - $('.castmodal header').outerHeight() - $('.castmodal .close').outerHeight()*0.6 ));
		}else{
			$('.castmodal').css('height',$(window).height()-150);
			$('.castmodal').css('top',($(window).height()-$('.castmodal').height()-35)/2);
			$('.castmodal article').css('height',($('.castmodal').height() - $('.castmodal header').height() -95));
		}
	}
		
	
});
