﻿var tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);	


$(document).ready(function(){



	//BGM
	var topbgm;
	$('body').append('<div style="display:none;" id="bgmPlayer"></div>');
	
if($('#baseW').width()>640){
	/* pc */
	$(document).on('click','#bgm .bgmIndex a',function(){
		$('#bgm .bgmtitle').addClass('skip');
		clearTimeout(bgmskip);
		bgmskip = setTimeout(bgmskipremove,4000);
		
		//clearTimeout(titletimer)
		//titletimer = setTimeout(bgmtitle,2000);

		$now = $('#bgm .bgmIndex a').index(this);
		$checknow = $('#bgm').attr('data-now');
		$('#bgm').attr('data-now',$now);
		$('#bgm').attr('class','title'+ (eval($now)+1))
		$mp3 = $(this).attr('href');
		$bgmtitle = $(this).attr('data-title');
		if(eval($now)!==eval($checknow)){
		$('#bgm .bgmtitle span').stop().animate({left:0-($(this).closest('.ui').width())},{duration:500,complete:function(){
			$('#bgm .bgmtitle').html('');
			$('#bgm .bgmtitle').append('<span style="left:100%"><b>'+$bgmtitle+'</b></span>');
			$('#bgm .bgmtitle span').stop().animate({left:0},500)
		}});
		}
		topbgm = new Audio($mp3);
		$('#bgmPlayer').html(topbgm);
		topbgm.loop = true;
		if($('#bgm .status').hasClass('play')){
			topbgm.play();
		}else{
			$('#bgm .status').toggleClass('play');
			topbgm.play();
		}
		return false;
	});
	
	//文中からBGM切り替え
	$(document).on('click','#bgm a.bgmplay',function(){
		$('#bgm .bgmIndex .' + $(this).attr('href')).trigger('click');
		return false;
	});
	
	//前次
	var bgmskip;
	function bgmskipremove(){
		$('#bgm .bgmtitle').removeClass('skip');
	}
	$(document).on('click','#bgm .prev a,#bgm .next a',function(){

		$('#bgm .bgmtitle').addClass('skip');
		clearTimeout(bgmskip);
		bgmskip = setTimeout(bgmskipremove,4000);
		clearTimeout(titletimer)
		titletimer = setTimeout(bgmtitle,2000);

		if($('#bgm .bgmtitle b').css('left')!='0px'){
			$('#bgm .bgmtitle b').stop(true, false).animate({'opacity':0},{duration:100,complete:function(){
				$(this).css('opacity',1).css('left',0-$('#bgm .bgmtitle b').outerWidth());
			}});
		}
		
		$songs = $('#bgm .ui .bgmIndex a').size();
		$now = $('#bgm').attr('data-now');
//		console.log($now)
		if($(this).closest('.next')[0]){
//			console.log('n')
			$now = eval($now) + 1;
			if($now>=$songs){$now=0}
		}else{
//			console.log('p')
			$now = eval($now) - 1;
			if(0>$now){$now=$songs-1}
		}
//		console.log($now)

		$('#bgm').attr('data-now',$now);
		$('#bgm').attr('class','title'+ (eval($now)+1))
		$mp3 = $('#bgm .ui .bgmIndex a').eq($now).attr('href');
		$bgmtitle = $('#bgm .ui .bgmIndex a').eq($now).attr('data-title');

		if($(this).closest('p').hasClass('next')){
			$('#bgm .bgmtitle span').stop().animate({top:50},{duration:500,complete:function(){
				$('#bgm .bgmtitle').html('');
				$('#bgm .bgmtitle').append('<span style="top:-50px"><b>'+$bgmtitle+'</b></span>');
				$('#bgm .bgmtitle span').stop().animate({top:0},500)
			}});
		}else{
			$('#bgm .bgmtitle span').stop().animate({top:-50},{duration:500,complete:function(){
				$('#bgm .bgmtitle').html('');
				$('#bgm .bgmtitle').append('<span style="top:50px"><b>'+$bgmtitle+'</b></span>');
				$('#bgm .bgmtitle span').stop().animate({top:0},500)
			}});
		}

		topbgm = new Audio($mp3);
		$('#bgmPlayer').html(topbgm);
		topbgm.loop = true;
		if($('#bgm .status').hasClass('play')){
			topbgm.play();
		}else{
//			$('#bgm .status').toggleClass('play');
//			topbgm.play();
		}
		return false;
	});

	//ON OFF
	$(document).on('click','#bgm .status a',function(){
		if($(this).hasClass('click')){return false;}
		$(this).addClass('click');
		if($('#bgm .status').hasClass('play')){
			$('#bgmPlayer').html('');
			$('#bgm .status').removeClass('play');
		}else{
			$now  = $('#bgm').attr('data-now');
			$('#bgm .bgmIndex a').eq($now).trigger('click');
		}
		setTimeout(removePlay,200);
		return false;
	});
	function removePlay(){
		$('#bgm a.click').removeClass('click');
	}
	//タイトル ティッカー
	var titletimer;
	$(window).on('load',function(){
		titletimer = setTimeout(bgmtitle,2000);
	});
	function bgmtitle(){
		if($('#bgm .bgmtitle b').outerWidth()>154){

			console.log(titletimer);
			$('#bgm .bgmtitle b').stop(true, false).animate({'left':0},10);
		
			if($('#bgm .bgmtitle.skip')[0]){
				clearTimeout(titletimer)
				titletimer = setTimeout(bgmtitle,1000);
			}else{

				$('#bgm .bgmtitle b').stop(true, false).animate({left:0-$('#bgm .bgmtitle b').outerWidth()},{duration:$('#bgm .bgmtitle b').outerWidth()*20,easing:'linear',complete:function(){
					if($('#bgm .bgmtitle.skip')[0]){
					}else{
						$('#bgm .bgmtitle b').css('left',154).stop(true, false).animate({left:0},{duration:$('#bgm .bgmtitle b').outerWidth()*10,easing:'linear',complete:function(){
							clearTimeout(titletimer)
							titletimer = setTimeout(bgmtitle,$('#bgm .bgmtitle b').outerWidth()*10+1000);
						}})
					}
				}})
			
			}
		}else{
			$('#bgm .bgmtitle b').stop(true, true).animate({'left':0},1000);
			clearTimeout(titletimer)
		}
	}
}else{
	/* sp */
	$(document).on('click','#spbgm .bgmIndex a',function(){
		$('#spbgm .bgmtitle').addClass('skip');
		clearTimeout(bgmskip);
		bgmskip = setTimeout(bgmskipremove,4000);
		
		//clearTimeout(titletimer)
		//titletimer = setTimeout(bgmtitle,2000);

		$now = $('#spbgm .bgmIndex a').index(this);
		$checknow = $('#spbgm').attr('data-now');
		$('#spbgm').attr('data-now',$now);
		$('#spbgm').attr('class','title'+ (eval($now)+1))
		$mp3 = $(this).attr('href');
		$bgmtitle = $(this).attr('data-title');
		if(eval($now)!==eval($checknow)){
		$('#spbgm .bgmtitle span').stop().animate({left:0-($(this).closest('.ui').width())},{duration:500,complete:function(){
			$('#spbgm .bgmtitle').html('');
			$('#spbgm .bgmtitle').append('<span style="left:100%"><b>'+$bgmtitle+'</b></span>');
			$('#spbgm .bgmtitle span').stop().animate({left:0},500)
		}});
		}
		topbgm = new Audio($mp3);
		$('#bgmPlayer').html(topbgm);
		topbgm.loop = true;
		if($('#spbgm .status').hasClass('play')){
			topbgm.play();
		}else{
			$('#spbgm .status').toggleClass('play');
			topbgm.play();
		}
		return false;
	});
	
	//文中からBGM切り替え
	$(document).on('click','#spbgm a.bgmplay',function(){
		$('#spbgm .bgmIndex .' + $(this).attr('href')).trigger('click');
		return false;
	});
	
	//前次
	var bgmskip;
	function bgmskipremove(){
		$('#spbgm .bgmtitle').removeClass('skip');
	}
	$(document).on('click','#spbgm .prev a,#spbgm .next a',function(){

		$('#spbgm .bgmtitle').addClass('skip');
		clearTimeout(bgmskip);
		bgmskip = setTimeout(bgmskipremove,4000);
		clearTimeout(titletimer)
		titletimer = setTimeout(bgmtitle,2000);

		if($('#spbgm .bgmtitle b').css('left')!='0px'){
			$('#spbgm .bgmtitle b').stop(true, false).animate({'opacity':0},{duration:100,complete:function(){
				$(this).css('opacity',1).css('left',0-$('#spbgm .bgmtitle b').outerWidth());
			}});
		}
		
		$songs = $('#spbgm .ui .bgmIndex a').size();
		$now = $('#spbgm').attr('data-now');
//		console.log($now)
		if($(this).closest('.next')[0]){
//			console.log('n')
			$now = eval($now) + 1;
			if($now>=$songs){$now=0}
		}else{
//			console.log('p')
			$now = eval($now) - 1;
			if(0>$now){$now=$songs-1}
		}
//		console.log($now)

		$('#spbgm').attr('data-now',$now);
		$('#spbgm').attr('class','title'+ (eval($now)+1))
		$mp3 = $('#spbgm .ui .bgmIndex a').eq($now).attr('href');
		$bgmtitle = $('#spbgm .ui .bgmIndex a').eq($now).attr('data-title');

		if($(this).closest('p').hasClass('next')){
			$('#spbgm .bgmtitle span').stop().animate({top:50},{duration:500,complete:function(){
				$('#spbgm .bgmtitle').html('');
				$('#spbgm .bgmtitle').append('<span style="top:-50px"><b>'+$bgmtitle+'</b></span>');
				$('#spbgm .bgmtitle span').stop().animate({top:0},500)
			}});
		}else{
			$('#spbgm .bgmtitle span').stop().animate({top:-50},{duration:500,complete:function(){
				$('#spbgm .bgmtitle').html('');
				$('#spbgm .bgmtitle').append('<span style="top:50px"><b>'+$bgmtitle+'</b></span>');
				$('#spbgm .bgmtitle span').stop().animate({top:0},500)
			}});
		}

		topbgm = new Audio($mp3);
		$('#bgmPlayer').html(topbgm);
		topbgm.loop = true;
		if($('#spbgm .status').hasClass('play')){
			topbgm.play();
		}else{
//			$('#spbgm .status').toggleClass('play');
//			topbgm.play();
		}
		return false;
	});

	//ON OFF
	$(document).on('click','#spbgm .status a',function(){
		if($(this).hasClass('click')){return false;}
		$(this).addClass('click');
		if($('#spbgm .status').hasClass('play')){
			$('#bgmPlayer').html('');
			$('#spbgm .status').removeClass('play');
		}else{
			$now  = $('#spbgm').attr('data-now');
			$('#spbgm .bgmIndex a').eq($now).trigger('click');
		}
		setTimeout(removePlay,200);
		return false;
	});
	function removePlay(){
		$('#spbgm a.click').removeClass('click');
	}
	//タイトル ティッカー
	var titletimer;
	$(window).on('load',function(){
		titletimer = setTimeout(bgmtitle,2000);
	});
	function bgmtitle(){
		if($('#spbgm .bgmtitle b').outerWidth()>154){

			console.log(titletimer);
			$('#spbgm .bgmtitle b').stop(true, false).animate({'left':0},10);
		
			if($('#spbgm .bgmtitle.skip')[0]){
				clearTimeout(titletimer)
				titletimer = setTimeout(bgmtitle,1000);
			}else{

				$('#spbgm .bgmtitle b').stop(true, false).animate({left:0-$('#spbgm .bgmtitle b').outerWidth()},{duration:$('#spbgm .bgmtitle b').outerWidth()*20,easing:'linear',complete:function(){
					if($('#spbgm .bgmtitle.skip')[0]){
					}else{
						$('#spbgm .bgmtitle b').css('left',154).stop(true, false).animate({left:0},{duration:$('#spbgm .bgmtitle b').outerWidth()*10,easing:'linear',complete:function(){
							clearTimeout(titletimer)
							titletimer = setTimeout(bgmtitle,$('#spbgm .bgmtitle b').outerWidth()*10+1000);
						}})
					}
				}})
			
			}
		}else{
			$('#spbgm .bgmtitle b').stop(true, true).animate({'left':0},1000);
			clearTimeout(titletimer)
		}
	}
}



	$(window).on('load',function(){
		if( getUrlVars()['to'] ){
			if(641>$(window).width()){
				$to = $('#' + getUrlVars()['to']).offset().top ;
			}else{
				$to = $('#' + getUrlVars()['to']).offset().top - 120;
			}
			$('html,body').stop().animate({scrollTop:$to},1000)
		}
	
	});
	
//whats new
	
	if($('.whatsnew ul li').size()===1){
		$('.whatsnew p.more').addClass('none');
	}
	$('.whatsnew p.more a').on('click',function(){
		$('.whatsnew ul li:nth-child(n+2)').slideToggle(500).toggleClass('show');
		return false;
	});

$(window).on("load",function(){
	twfontsize();
});
function twfontsize(){
	if($('#baseW').width()>640) {
		if($("#twitter-widget-0").contents().find('.SandboxRoot.env-bp-660 .timeline-Tweet-text').css('font-size')==='27px'){
			$("#twitter-widget-0").contents().find('.SandboxRoot.env-bp-660 .timeline-Tweet-text').css({'cssText': 'font-size: 16px !important; line-height:1.7 !important;'});
		}else{
			setTimeout(twfontsize,200);
		}
	}
}


/* opening */
charaloadcheck();
function charaloadcheck(){
	if($('.imgloaded')[0]){
		openigstart();
	}else{
		setTimeout(charaloadcheck,200);
	}
}
function openigstart(){
	$.wait(400,function() {$('.firstview').addClass('show');});
	$.wait(800,function() {$('.firstview').addClass('show2');});
	$.wait(1200,function() {$('.firstview').addClass('show3');});
	$.wait(1600,function() {$('.firstview').addClass('show4');});
	$.wait(2000,function() {$('.firstview').addClass('show5');});
}

//動画
	var player1;
	var videoID = $('#player01').html();
	if($('.pv a')[0]){
	if( $('html').hasClass('tablet') || $('html').hasClass('smartphone') ){
	}else{
		var player1='';
		$(window).on('load',function(){
			$.wait(300,function(){
				loadPlayer1(videoID);
			});
		});
		function loadPlayer1(videoID){if(!player1){
			var start=0;
			player1 = new YT.Player('player01', {
				height: '140',
				width: '244',
				videoId:videoID,
				playerVars:{"rel":0,"showinfo":0,"start": start,"controls":0,"modestbranding":1,"wmode":"transparent","autohide":1,"loop":1,'autoplay':1},
				events:{
					'onReady': onPlayerReady,
					'onStateChange': onPlayerStateChange
				}
			});
		}};
		function onPlayerReady(){
			player1.mute();
			player1.playVideo();
			//$('main .movie iframe').height($('main .movie iframe').width()*0.66857142857)
				$('main .pv iframe').attr({height: $('.pv .play ').height()+2});
				$('main .pv iframe').attr({width:Math.floor(($('.pv .play ').height()+2)*1.77777777778)});
				$('main .pv iframe').css({marginLeft:0-($('main .pv iframe').width()-$('.pv .play ').width())/2});
		}
		var moviestate=0;
		function onPlayerStateChange(){
			if(moviestate===1){
			}else{
			player1.playVideo();
			}
		}
	}
	}

});
