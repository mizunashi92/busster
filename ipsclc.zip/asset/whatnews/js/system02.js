﻿$(document).ready(function(){

  	var mySwiper = new Swiper ('.cont01 .swiper-container', {
    //loop: true,
		centeredSlides: true,
 		slidesPerView: 'auto',    // If we need pagination
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
        paginationClickable: true
		});  
  var mySwiper2 = new Swiper ('.cont03 .swiper-container', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide2-text').hide();
			$('.slide2-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper3 = new Swiper ('.cont07 .swiper-container.slide01', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideNextStart : function(swiper) {
		}
  });
  var mySwiper4 = new Swiper ('.cont07 .swiper-container.slide02', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideNextStart : function(swiper) {
		}
  });

});
