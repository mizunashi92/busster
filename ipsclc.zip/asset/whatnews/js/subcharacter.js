﻿$(document).ready(function(){
//$.guides({baseWidth:1200,inWidth:100,inHeight:100});
charaloadcheck();
function charaloadcheck(){
	if($('.imgloaded')[0]){
		openigstart();
	}else{
		setTimeout(charaloadcheck,100);
	}
}
function openigstart(){
	if($('#baseW').width()>640){
		$.wait(400,function(){$('main .wrap').addClass('show');});
		$.wait(900,function(){$('.pagearr').addClass('show');});
	}else{
		$.wait(400,function(){$('.pagearr').addClass('show');});
	}
}
	$('.swiper-container').each(function(){
		if($(this).find('.swiper-slide').length>1){
			$(this).find('nav').show();
		}else{
			//$(this).find('.swiper-pagination').remove();
			//$(this).find('.swiper-button-prev').remove();
			//$(this).find('.swiper-button-next').remove();
		}
	});
	var mySwiper = new Swiper ('.swiper-container', {
    loop: false,
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true
  });  
	//別ページから
	$(window).on('load',function(){
		if( getUrlVars()['sub'] ){
				$to = $('.' + getUrlVars()['sub']).offset().top;
				if($('#baseW').width()>640) {
					var offset = 120;
				}else{
					var offset = $('.menutoggle a').outerHeight()/2;
				}
			$('html,body').stop().animate({scrollTop:$to-offset},1000)
		}
	});
	/**
		img modal
	*/
	var imgmodalw = '90%';
	if($('#baseW').width()>640) {
		imgmodalw = '1032px';
	}
	$(".img3dmodal").colorbox({
		maxWidth:imgmodalw,
		maxHeight:"90%",
		rel:'img3dmodal',
		speed:800,
		returnFocus:false,
		//loop:false,
		retinaImage:false
	});
	if($(".img3dmodal").length>1){
		$('body').addClass('cboxpageing');
	}

	//ウィンドウリサイズでモーダル閉じる
	$(window).on('resize',function(){
		$.colorbox.close()
	});

});
