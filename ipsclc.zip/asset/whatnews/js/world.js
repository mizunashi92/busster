﻿$(document).ready(function(){

	$(window).on('load',function(){
  var mySwiper = new Swiper ('.cont03 .swiper-container.slide01', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide1-text').hide();
			$('.slide1-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper2 = new Swiper ('.cont03 .swiper-container.slide02', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide2-text').hide();
			$('.slide2-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper3 = new Swiper ('.cont04 .swiper-container.slide01', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide3-text').hide();
			$('.slide3-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper4 = new Swiper ('.cont04 .swiper-container.slide02', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideChangeStart : function(swiper) {
			//console.log(swiper.activeIndex);
			$('.slide4-text').hide();
			$('.slide4-text').eq(swiper.activeIndex).show();
		}
  });
  var mySwiper5 = new Swiper ('.cont05 .swiper-container.slide01', {
		centeredSlides: true,
 		slidesPerView: 'auto',
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    paginationClickable: true,
		onSlideNextStart : function(swiper) {
		}
  });
 
	});

});
