﻿$(document).ready(function(){

	$(window).on('load',function(){
  var mySwiper = new Swiper ('.swiper-container', {
    //loop: true,
		centeredSlides: true,
 slidesPerView: 'auto',    // If we need pagination
    pagination: '.swiper-pagination',
    // Navigation arrows
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
        paginationClickable: true
  });  
	});

});
