/*
Navicat MySQL Data Transfer

Source Server         : Allianz
Source Server Version : 50516
Source Host           : localhost:3306
Source Database       : u550095972_demo

Target Server Type    : MYSQL
Target Server Version : 50516
File Encoding         : 65001

Date: 2018-05-27 23:49:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `agents`
-- ----------------------------
DROP TABLE IF EXISTS `agents`;
CREATE TABLE `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `real_password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `polis_no` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT 'blank.jpg',
  `valid` tinyint(4) NOT NULL DEFAULT '0',
  `role` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agents
-- ----------------------------
INSERT INTO `agents` VALUES ('1', 'JackGrecko', '$2y$10$cgn7KIIire9TNROz/uJg7.LsndKUT3PQ.iPHaNfUe0DcwTM2pz9oy', 'almukayo', 'Jack Grecko', '100020000', 'wibowo.yosafat@gmail.com', '08561215451', 'dcaec2bc948e334f52e972acb6277f20.jpg', '1', '1');
INSERT INTO `agents` VALUES ('2', 'MojoDraggy', '$2y$10$7XWWaX7wmvPZyxToS5hAyuObLM7FR/Hy/LVhFpk80VaniHr.6SiCu', 'almukayo', 'Mojo Dragfy', '100020001', 'sintyadithong@gmail.com', '08127832738', 'Chamb.jpg', '1', '0');
INSERT INTO `agents` VALUES ('3', 'PeterCech', '$2y$10$xtpfu.As0xC/HYoZh4O2AO/6YPQ8dQ0ES9qOefwF1ls3FvDp.naf6', 'almukayo', 'Peter Cech', '100020002', 'sintyadithong@gmail.com', '08186372632', 'f1febbd708e82a36422cd64b1622fae7.jpg', '1', '0');
INSERT INTO `agents` VALUES ('4', 'Geronimo', '$2y$10$VMHuSJYVhfWvRHWq6lfineg9gzLVGGwe3oZc8rppc8yhOxY8BY5uK', 'almukayo', 'Ganesha Geronimo', '100020003', 'sintyadithong@gmail.com', '081329988899', 'blank.jpg', '1', '0');

-- ----------------------------
-- Table structure for `agents_info`
-- ----------------------------
DROP TABLE IF EXISTS `agents_info`;
CREATE TABLE `agents_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agents_info
-- ----------------------------
INSERT INTO `agents_info` VALUES ('1', 'Kartu Kredit Untuk Anak', 'kartu-kredit-untuk-anak', 'Kartu kredit merupakan alat pembayaran pengganti uang tunai yang mudah dan efisien. Cukup menggesek kartu satu kali, benda idaman sudah menjadi milik Anda. Kini banyak orang tua memercayakan anak-anak mereka untuk menggunakan kartu kredit.\r\n\r\nApakah salah memberi fasilitas kartu kredit pada anak? Kapan saat yang tepat memberikan kartu kredit pada anak?\r\nDi Indonesia, usia minimum seseorang untuk memiliki kartu kredit adalah 21 tahun atau 17 tahun dengan status sudah menikah dan berpenghasilan minimal 3 juta rupiah per bulan. Namun tak jarang kita temui anak berusia belia sudah berbelanja dengan kartu kredit. Kok bisa? Menurut perencana keuangan sekaligus CEO Andreas Hartono Academy, Ir. Andreas Hartono, CHt, CI, CFP, kartu kredit yang digunakan oleh anak merupakan kartu pinjaman dari orang tua. Sah-sah saja meminjamkan kartu kredit pada anak. Namun, ada hal yang harus dipertimbangkan selanjutnya, apakah si anak sudah cukup dewasa untuk menggunakan kartu kredit?\r\n\r\nAnak remaja secara mental sering dianggap labil atau masih belum bisa mengontrol emosi dan keinginan dengan baik. Keadaan tersebut dikhawatirkan akan mempengaruhi cara anak dalam membelanjakan kartu kredit. Andreas mengatakan, kedewasaan dalam mengelola keuangan antara satu anak dengan anak lain mempunyai tingkat yang berbeda-beda. Ada yang berusia belasan akhir namun belum bisa mengelola keuangan pribadinya dengan benar. Ada pula yang masih usia belia tetapi sudah mengerti dan mampu mengatur keuangannya sendiri.', '2018-02-22 00:15:54', 'Lindsay Sterling');
INSERT INTO `agents_info` VALUES ('2', 'Dana Pensiun', '10-detik-menghitung-dana-pensiun', 'Ya benar anda hanya perlu meluangkan waktu sekitar 10 detik untuk mengetahui berapa jumlah total besar uang pensiun yang anda butuhkan ketika anda memasuki usia pensiun di 55 tahun. Bagaimana caranya ? Sangat mudah dan saya akan memandu anda, sekarang anda siapkan data dan alat berikut ini :', '2018-02-22 00:15:54', 'Lindsay Sterling');
INSERT INTO `agents_info` VALUES ('3', 'Investasi Emas atau Saham atau Reksadana', 'investasi-emas-atau-saham-atau-reksadana', 'Kalau melihat data keseluruhan dari tahun 2012 hingga tahun 2015 maka kesimpulan kita sangat sederhana yaitu mau investasi apa saja semuanya cenderung menurun cukup signifikan kecuali properti saja yang penurunannya masih relatif sedikit. Dari data inilah saat ini para perencana keuangan juga sudah mulai menurunkan target investasinya. Dulu untuk reksadana saham masih cukup optimis di angka 25% sekarang hanya ditargetkan 20% untuk investasi jangka panjang di atas 10 tahun.', '2018-02-22 00:15:55', 'Lindsay Sterling');
INSERT INTO `agents_info` VALUES ('4', 'Investasi Reksadana – Investasi 100 Ribuan Untuk Pemula', 'Investasi-Reksadana-Investasi-100-Ribuan-Untuk-Pemula', '<p><strong>Investasi reksadana</strong> merupakan dewa penolong untuk orang yang mau investasi tapi modal terbatas. Nah sebelum kita bicara tentang investasi reksadana mari kita bicara dulu tentang apa itu investasi dan mengapa perlu investasi.</p>\r\n', '2018-02-23 04:04:25', 'Lindsay Sterling');

-- ----------------------------
-- Table structure for `ci_sessions`
-- ----------------------------
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ci_sessions
-- ----------------------------

-- ----------------------------
-- Table structure for `contacts`
-- ----------------------------
DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `birth_date` varchar(255) DEFAULT NULL,
  `gender` set('Pria','Wanita') DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `smoker` set('Ya','Tidak') DEFAULT NULL,
  `premium_plan` set('Bulanan','Quarter','Semester','Tahunan') DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `add_plan` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sosmed_id` varchar(255) DEFAULT NULL,
  `sosmed_type` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `ins_impor` set('Penting','Sangat Penting','Tidak Penting') DEFAULT NULL,
  `willingness` set('Bersedia','Tidak Bersedia') DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of contacts
-- ----------------------------
INSERT INTO `contacts` VALUES ('1', 'jackgrecko', '', '', null, '', null, null, '', null, '', '', '', '', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('2', 'jackgrecko', '', '', null, '', null, null, '', null, '', 'wibowo.yosafat@gmail.com', '', '', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('3', 'jackgrecko', '', '28 November', null, '', null, null, '', null, '', '', '', '', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('4', 'jackgrecko', '', '', null, 'House Husband', null, null, '', null, '', '', '', '', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('5', 'jackgrecko', '', '', null, '', null, null, '5000.0000', null, '073971293', '', 'dadadsad', 'dadada', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('6', 'jackgrecko', '', '', '', '', '', null, '', null, '', '', '', '', 'adasdsad', 'asdasdasdda', null, null, null);
INSERT INTO `contacts` VALUES ('7', 'jackgrecko', '', '', '', '', '', 'Bulanan', '', 'Sakit Kritis', '', '', '', '', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('8', 'jackgrecko', '', '', 'Pria', '', 'Ya', null, '', null, '', '', '', '', '', '', null, null, null);
INSERT INTO `contacts` VALUES ('9', 'jackgrecko', '', '', null, '', null, null, '', null, '', '', '', '', '', '', null, 'Bersedia', null);
INSERT INTO `contacts` VALUES ('10', 'jackgrecko', '', '', null, '', null, null, '', null, '', '', '', '', '', '', 'Penting', null, null);
INSERT INTO `contacts` VALUES ('11', 'jackgrecko', '', '', null, '', null, null, '', null, '', '', '', '', '', '', 'Tidak Penting', 'Tidak Bersedia', null);
INSERT INTO `contacts` VALUES ('12', 'jackgrecko', 'Yosafat Surya Wibowo', '28 November 2018', 'Pria', 'House Husband', 'Ya', 'Bulanan', '500.000,00', 'Rawat Inap', '08568183720', 'wibowo.yosafat@gmail.com', 'Geronimo', 'Instagram', 'Jakarta', '12873', 'Sangat Penting', 'Tidak Bersedia', null);
INSERT INTO `contacts` VALUES ('13', 'jackgrecko', 'Yosafat Surya Wibowo', '28 November 2018', 'Pria', 'House Husband', 'Ya', 'Bulanan', '500.000,00', 'Rawat Inap', '08568183720', 'wibowo.yosafat@gmail.com', 'Geronimo', 'Instagram', 'Jakarta', '12873', 'Sangat Penting', 'Tidak Bersedia', null);
INSERT INTO `contacts` VALUES ('14', 'jackgrecko', '', '', null, '', null, null, '', null, '', '', '', '', '', '', null, null, null);

-- ----------------------------
-- Table structure for `hit_stat`
-- ----------------------------
DROP TABLE IF EXISTS `hit_stat`;
CREATE TABLE `hit_stat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of hit_stat
-- ----------------------------
INSERT INTO `hit_stat` VALUES ('1', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '2018-04-24 18:34:40');
INSERT INTO `hit_stat` VALUES ('5', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '2018-04-24 19:45:44');
INSERT INTO `hit_stat` VALUES ('6', 'logout', 'http://localhost/allianz/logout', '::1', '2018-04-24 19:45:49');
INSERT INTO `hit_stat` VALUES ('7', 'logout', 'http://localhost/allianz/logout', '::1', '2018-04-24 19:45:52');
INSERT INTO `hit_stat` VALUES ('8', 'petercech', 'http://localhost/allianz/petercech', '::1', '2018-04-23 19:45:56');
INSERT INTO `hit_stat` VALUES ('9', 'petercech', 'http://localhost/allianz/petercech', '::1', '2018-04-24 19:46:00');
INSERT INTO `hit_stat` VALUES ('10', 'logout', 'http://localhost/allianz/logout', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('11', 'about_me', 'http://localhost/allianz/about_me', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('12', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('13', 'about_me', 'http://localhost/allianz/about_me', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('14', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('15', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('16', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('17', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('18', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('19', 'about_me', 'http://localhost/allianz/about_me', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('20', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('21', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('22', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('23', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('24', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('25', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('26', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('27', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('28', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('29', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('30', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('31', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('32', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('33', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('34', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('35', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('36', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('37', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('38', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('39', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('40', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('41', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('42', 'petercech', 'http://localhost/allianz/petercech', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('43', 'products.html', 'http://localhost/allianz/products.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('44', 'products.html', 'http://localhost/allianz/products.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('45', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('46', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('47', 'products.html', 'http://localhost/allianz/products.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('48', 'index.html', 'http://localhost/allianz/index.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('49', 'products.html', 'http://localhost/allianz/products.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('50', 'products.html', 'http://localhost/allianz/products.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('51', 'products.html', 'http://localhost/allianz/products.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('52', 'aboutme', 'http://localhost/allianz/aboutme', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('53', 'gallery.html', 'http://localhost/allianz/gallery.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('54', 'gallery.html', 'http://localhost/allianz/gallery.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('55', 'gallery', 'http://localhost/allianz/gallery', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('56', 'gallery', 'http://localhost/allianz/gallery', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('57', 'gallery.html', 'http://localhost/allianz/gallery.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('58', 'gallery', 'http://localhost/allianz/gallery', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('59', 'aboutme', 'http://localhost/allianz/aboutme', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('60', 'about', 'http://localhost/allianz/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('61', 'contact.html', 'http://localhost/allianz/contact.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('62', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('63', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('64', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('65', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('66', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('67', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('68', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('69', 'result', 'http://localhost/allianz/result', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('70', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('71', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('72', 'send', 'http://localhost/allianz/send', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('73', 'sendemailtoagent', 'http://localhost/allianz/sendemailtoagent', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('74', 'sendemailtoagent', 'http://localhost/allianz/sendemailtoagent', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('75', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('76', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('77', 'aboutme', 'http://localhost/busster-bisnis/aboutme', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('78', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('79', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('80', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('81', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('82', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('83', 'aboutme', 'http://localhost/busster-bisnis/aboutme', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('84', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('85', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('86', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('87', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('88', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('89', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('90', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('91', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('92', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('93', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('94', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('95', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('96', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('97', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('98', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('99', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('100', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('101', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('102', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('103', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('104', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('105', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('106', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('107', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('108', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('109', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('110', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('111', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('112', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('113', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('114', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('115', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('116', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('117', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('118', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('119', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('120', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('121', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('122', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('123', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('124', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('125', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('126', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('127', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('128', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('129', 'contactss', 'http://localhost/busster-bisnis/contactss', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('130', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('131', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('132', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('133', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('134', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('135', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('136', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('137', 'about', 'http://localhost/busster-bisnis/about', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('138', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('139', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('140', 'aboutjackgrecko', 'http://localhost/busster-bisnis/aboutjackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('141', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('142', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('143', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('144', 'gallery.html', 'http://localhost/allianz/gallery.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('145', 'gallery.html', 'http://localhost/allianz/gallery.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('146', 'gallery', 'http://localhost/allianz/gallery', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('147', 'gallery.html', 'http://localhost/allianz/gallery.html', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('148', 'articles', 'http://localhost/allianz/articles', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('149', 'jackgrecko', 'http://localhost/allianz/jackgrecko', '::1', '0000-00-00 00:00:00');
INSERT INTO `hit_stat` VALUES ('150', 'jackgrecko', 'http://localhost/busster-bisnis/jackgrecko', '::1', '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for `personal`
-- ----------------------------
DROP TABLE IF EXISTS `personal`;
CREATE TABLE `personal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of personal
-- ----------------------------
INSERT INTO `personal` VALUES ('1', 'OJK Catat Ada 585 Usaha Gadai Abal-abal', 'OJK-Catat-Ada 585-Usaha-Gadai-Abal-abal', 'Otoritas Jasa Keuangan (OJK) tengah membenahi industri pegadaian nasional dengan menegakkan Peraturan OJK (POJK) Nomor 31/POJK.15/2016. Dalam aturan tersebut seluruh badan usaha pegadaian harus memiliki izin.Deputi Komisioner Industri Keuangan Non Bank (IKNB) OJK Mochammad Ihsanuddin mengatakan, pihaknya telah melakukan pendataan bersama dengan PT Pegadaian (Persero). Hasilnya ada 585 usaha gadai yang belum terdaftar dan berizin OJK alias usaha gadai abal-abal.\"Dikoordinasikan dengan pegadaian sudah terdata 585 gadai yang belum terdaftar dan berizin di OJK. Itu Berdasarkan tukar tukaran data tim kita sama pegadaian,\" tuturnya di Gedung OJK, Jakarta, Jumat (25/5/2018)', 'a2b4dd67893ca294115d67e300a7a2a8.jpg', '2018-05-27 21:41:28', 'JackGrecko');
INSERT INTO `personal` VALUES ('2', 'IHSG Menguat ke 5.975', 'IHSG-Menguat-ke-5.975', 'Indeks Harga Saham Gabungan (IHSG) masih melanjutkan penguatan. Sore ini, IHSG ditutup di 5.975 didukung mulai jinaknya nilai tukar dolar AS terhadap rupiah.Nilai tukar dolar Amerika Serikat (AS) juga melemah terhadap rupiah. Dolar berada di level Rp 14.109 dibandingkan dengan posisi kemarin yang berada di Rp 14.205.Pada perdagangan preopening, IHSG bertambah 10,888 poin (0,18%) ke level 5.957,426. Indeks LQ45 juga naik 2,744 poin (0,29%) ke level 956,612.Membuka perdagangan, Jumat (25/5/2018), IHSG bergerak naik 17,120 poin (0,29%) ke 5.963,658. Indeks LQ45 naik 2,682 poin (0,28%) ke level 956,550.Pada pukul 09.05 waktu JATS, IHSG masih berada di zona positif dengan kenaikan 6,864 poin (0,12%) ke level 5.953,402. Indeks LQ45 cenderung stagnan.', '4416447ecf9cb8ddab06108c010becb6.jpg', '2018-05-27 21:42:07', 'JackGrecko');

-- ----------------------------
-- Table structure for `posts`
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` set('Asuransi Jiwa','Asuransi Kesehatan','Asuransi Penyakit Kritis','Asuransi Keluarga Lengkap','Asuransi Syariah','Asuransi Rawat Jalan','Asuransi Melahirkan','Asuransi Pendidikan') DEFAULT NULL,
  `section` set('p','b') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO `posts` VALUES ('1', '10 Detik Menghitung Dana Pensiun', '10-detik-menghitung-dana-pensiun', '<p>Ya benar anda hanya perlu meluangkan waktu sekitar 10 detik untuk mengetahui berapa jumlah total besar uang pensiun yang anda butuhkan ketika anda memasuki usia pensiun di 55 tahun. Bagaimana caranya ? Sangat mudah dan saya akan memandu anda, sekarang anda siapkan data dan alat berikut ini :</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:16:18', 'Jack Grecko');
INSERT INTO `posts` VALUES ('2', 'Investasi Emas atau Saham atau Reksadana', 'investasi-emas-atau-saham-atau-reksadana', '<p>Kalau melihat data keseluruhan dari tahun 2012 hingga tahun 2015 maka kesimpulan kita sangat sederhana yaitu mau investasi apa saja semuanya cenderung menurun cukup signifikan kecuali properti saja yang penurunannya masih relatif sedikit. Dari data inilah saat ini para perencana keuangan juga sudah mulai menurunkan target investasinya. Dulu untuk reksadana saham masih cukup optimis di angka 25% sekarang hanya ditargetkan 20% untuk investasi jangka panjang di atas 10 tahun.</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:06:58', 'Jack Grecko');
INSERT INTO `posts` VALUES ('3', 'Investasi Reksadana – Investasi 100 Ribuan', 'Investasi-Reksadana-Investasi-100-Ribuan-Untuk-Pemula', '<p><strong>Investasi reksadana</strong> merupakan dewa penolong untuk orang yang mau investasi tapi modal terbatas. Nah sebelum kita bicara tentang investasi reksadana mari kita bicara dulu tentang apa itu investasi dan mengapa perlu investasi.</p>\r\n', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:06:59', 'Jack Grecko');
INSERT INTO `posts` VALUES ('4', 'Kejar Target Keuangan di Usia Muda Pakai Cara Ini', 'Kejar-Target-Keuangan-di-Usia-Muda-Pakai-Cara-Ini', '<p><strong>Jakarta</strong> - Di dalam keseharian, seseorang tentunya akan mengalami masa-masa peningkatan. Berawal dari masa kandungan, bayi, anak-anak, remaja, dewasa, berkeluarga, memiliki anak dan cucu, hingga pada saatnya akan meninggal. Tentunya masa-masa tersebut memiliki kondisi dan tantangan yang berbeda satu sama lainnya.<br />\r\n<br />\r\nSelain itu, setiap satu masa berjalan tentu saja membutuhkan biaya untuk memenuhi segala kebutuhan yang ada. Karena itu, dibutuhkan pengelolaan keuangan yang tepat dalam setiap fase-fase kehidupan. Maka dari itu sangat dianjurkan bagi Anda agar dapat memulai segala usaha sejak dari usia muda.<br />\r\n<br />\r\nDan sudah banyak contohnya di luar sana banyak yang sudah bisa meraih kesuksesannya pada usia muda. Tapi sayangnya banyak orang yang hanya ingin meraih tanpa mengetahui langkah apa yang harus mereka tempuh untuk menggapainya.<br />\r\n<br />\r\nNah, berikut ini beberapa tips cerdas yang dapat Anda lakukan untuk mempersiapkan target keuangan usia muda:<br />\r\n<br />\r\n<strong>1. Bekerja Keras</strong><br />\r\nBiasanya seseorang pada usia 20 Tahun mungkin masih terbilang usia yang sangat muda dan akan memilih menikmati masa-masa lajangnya, banyak orang yang berpikir jika tidak ada banyak tanggungan yang harus dipenuhi dalam hidup.<br />\r\n<br />\r\nNamun, pada masa ini, Anda harus benar-benar mengerti bagaimana arti kerja keras sesungguhnya. Bekerja dari siang hingga malam hari adalah hal yang wajar Anda lakukan untuk bisa menabung guna mendapatkan kebebasan finansial pada masa yang akan datang.<br />\r\n<br />\r\nJanganlah mudah menyerah dan merasa lelah, segala kerja keras Anda akan membuah kan hasil yang tidak pernah Anda duga sebelumnya.<br />\r\n<br />\r\n<strong>2. Kelola Keuangan</strong><br />\r\nAnak muda tentu akan memiliki hasrat dan keinginan yang besar untuk memenuhi segala keinginannya, tapi jangan sampai lupa bahwa Anda juga harus memahami bagaimana cara mengendalikan pengeluaran yang baik.<br />\r\n<br />\r\nAnda juga perlu mempersiapkan keuangan untuk momen-momen pada masa yang akan datang, seperti melanjutkan pendidikan, melangsungkan pernikahan, dan masih banyak lainnya. Karena itu, pada masa lajang ini, akan lebih baik jika Anda banyak mengalihkan uang untuk disisihkan ke dalam rekening tabungan.<br />\r\n<br />\r\nUntuk mempermudah kegiatan menabung yang dilakukan, alangkah baiknya pisahkan antara rekening tabungan dan rekening pribadi.<br />\r\n<br />\r\n<strong>3. Jangan biasakan berutang</strong><br />\r\nJika Anda memiliki kartu kredit, ada baiknya berhati-hati ketika menggunakannya. Gunakan dengan bijak dan memang sesuai dengan kebutuhan. Jangan selalu mengandalkah kartu kredit untuk memenuhi segala keinginan Anda.<br />\r\n<br />\r\nIngat bahwa utang kartu kredit adalah sebuah bunga berjalan yang akan bertambah besar yang pada akhirnya akan membuat Anda terjerat pada masalah keuangan.<br />\r\n&nbsp;</p>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p><strong>Baca juga: </strong><a href=\"https://finance.detik.com/read/2018/04/06/232205/3958404/722/jangan-khawatir-tarif-ojek-online-naik-akali-pakai-cara-ini\" target=\"_blank\">Jangan Khawatir Tarif Ojek Online Naik, Akali Pakai Cara Ini</a></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><br />\r\n<strong>4. Perbanyak Relasi</strong><br />\r\nUsia muda adalah saat di mana Anda sangat mudah untuk bergaul. Ingat! Pergaulan Anda bisa menentukan masa depan Anda. Mulailah bergaul dengan mereka yang punya sifat pekerja keras, pantang menyerah dan kreatif, atau bahkan Anda bisa mulai bergaul dengan mereka yang sudah sukses pada usaha tertentu sehingga Anda juga akan mendapatkan ilmu dan dampak yang sangat bermanfaat.<br />\r\n<br />\r\n<strong>5. Mulai Membangun Usaha</strong><br />\r\nSiapa bilang membuka usaha adalah suatu kegiatan yang hanya bisa dilakukan oleh seseorang yang sudah dewasa, pada kenyatannya banyak dari para orang kaya di dunia ini yang sudah bisa meraih kesuksesan pada usia muda.<br />\r\n<br />\r\nBahkan sebagian dari mereka memulai usahanya dari usaha yang sangat kecil yang kemudian berkembang menjadi usaha yang besar. Maka dari itu mulailah membangun usaha mulai sekarang.<br />\r\n<br />\r\nAnda bisa memulai dengan cara-cara yang sederhana dengan memanfaat segala fasilitas yang Anda miliki saat ini. Seperti menggunakan smartphone dan laptop Anda untuk membuka online shop, jasa pengetik, jasa iklan social media, dan masih banyak lainnya.<br />\r\n<br />\r\nJanganlah Anda merasa takut untuk berbisnis, apapun rintangannya bahkan ketika Anda mengalami kegagalan sekalipun janganlah berputus asa, karena dari kegagalan tersebut Anda akan memiliki sebuah pengalaman berharga yang akan menjadi senjata bagi Anda meggapai kesuksesan.<br />\r\n<br />\r\nBerikut adalah beberapa tipsnya untuk dapat menggapai segala target keuangan dan menjadi sukses pada usia muda. Percayalah segala usaha yang Anda lakukan hari ini akan membuahkan hasil yang manis pada kemudian hari yang akan membuat hari tua Anda terjamin. Hanya mengetahui saja tidak cukup, segera ambil tindakan dari sekarang.<br />\r\n<br />\r\nSemoga bermanfaat.</p>\r\n<p>Kondisi fisik yang sehat dan bugar tetap membutuhkan pemeriksaan kesehatan untuk pemeliharaan. Pemeriksaan kesehatan atau medical check up rutin sebaiknya dilakukan sedikitnya 2 tahun sekali. Dana yang dibutuhkan mungkin tidak sedikit. Namun, mengobati  kondisi medis yang berat dan sudah terlambat akan jauh lebih berat daripada mengeluarkan dana untuk medical check up. </p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:07:39', 'Jack Grecko');
INSERT INTO `posts` VALUES ('5', 'Persiapan Dana Untuk Medical Checkup', 'Persiapan Dana-Untuk-Medical-Checkup', '<p><strong>Jakarta</strong> - Di dalam keseharian, seseorang tentunya akan mengalami masa-masa peningkatan. Berawal dari masa kandungan, bayi, anak-anak, remaja, dewasa, berkeluarga, memiliki anak dan cucu, hingga pada saatnya akan meninggal. Tentunya masa-masa tersebut memiliki kondisi dan tantangan yang berbeda satu sama lainnya.<br />', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:08:22', 'Jack Grecko');
INSERT INTO `posts` VALUES ('6', 'Bicara Uang Dengan Pasangan', 'Bicara-Uang-Dengan-Pasangan', '<p>Meski sudah menikah, ternyata masih banyak pasangan yang mau terbuka untuk saling bicara tentang uang. Padahal, statistik menyatakan bahwa setidaknya 70% dari pertengkaran dalam rumah tangga berakar dari masalah keuangan. Agar tidak terjadi kesalah pahaman dalam urusan keuangan, apa saja yang sebaiknya menjadi fokus bagi setiap pasangan dalam bicara uang? Simak tujuh poin berikut.</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:09:16', 'Jack Grecko');
INSERT INTO `posts` VALUES ('7', 'Mengatur Angpao Tahun Baru Imlek', 'Mengatur-Angpao-Tahun-Baru-Imlek', '<p>Meski sudah menikah, ternyata masih banyak pasangan yang mau terbuka untuk saling bicara tentang uang. Padahal, statistik menyatakan bahwa setidaknya 70% dari pertengkaran dalam rumah tangga berakar dari masalah keuangan. Agar tidak terjadi kesalah pahaman dalam urusan keuangan, apa saja yang sebaiknya menjadi fokus bagi setiap pasangan dalam bicara uang? Simak tujuh poin berikut.</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:09:16', 'Jack Grecko');
INSERT INTO `posts` VALUES ('8', '100 Juta Mimpi dengan Bonus Tahunan', '100-Juta-Mimpi-dengan-Bonus-Tahunan', '<p>Akhir tahun identik dengan libur panjang. Berita bahagia mungkin diterima terkait adanya bonus akhir tahun. Namun, di saat yang bersamaan banyak paket menarik yang ditawarkan oleh merchant online shopping, restoran hingga penawaran old and newdari beberapa hotel terkemuka yang juga tak kalah menggoda. Dengan berbagai fakta ini, bagaimana strategi mengatur keuangan yang baik, agar bonus akhir tahun yang diterima bisa bermanfaat untuk keluarga?</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'p', '2018-05-27 23:10:57', 'Jack Grecko');
INSERT INTO `posts` VALUES ('9', 'Bicara Uang Dengan Pasangan', 'Bicara-Uang-Dengan-Pasangan', '<p>Meski sudah menikah, ternyata masih banyak pasangan yang mau terbuka untuk saling bicara tentang uang. Padahal, statistik menyatakan bahwa setidaknya 70% dari pertengkaran dalam rumah tangga berakar dari masalah keuangan. Agar tidak terjadi kesalah pahaman dalam urusan keuangan, apa saja yang sebaiknya menjadi fokus bagi setiap pasangan dalam bicara uang? Simak tujuh poin berikut.</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:17:17', 'Jack Grecko');
INSERT INTO `posts` VALUES ('10', '100 Juta Mimpi dengan Bonus Tahunan', '100-Juta-Mimpi-dengan-Bonus-Tahunan', '<p>Akhir tahun identik dengan libur panjang. Berita bahagia mungkin diterima terkait adanya bonus akhir tahun. Namun, di saat yang bersamaan banyak paket menarik yang ditawarkan oleh merchant online shopping, restoran hingga penawaran old and newdari beberapa hotel terkemuka yang juga tak kalah menggoda. Dengan berbagai fakta ini, bagaimana strategi mengatur keuangan yang baik, agar bonus akhir tahun yang diterima bisa bermanfaat untuk keluarga?</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:17:16', 'Jack Grecko');
INSERT INTO `posts` VALUES ('11', 'Mengatur Angpao Tahun Baru Imlek', 'Mengatur-Angpao-Tahun-Baru-Imlek', '<p>Meski sudah menikah, ternyata masih banyak pasangan yang mau terbuka untuk saling bicara tentang uang. Padahal, statistik menyatakan bahwa setidaknya 70% dari pertengkaran dalam rumah tangga berakar dari masalah keuangan. Agar tidak terjadi kesalah pahaman dalam urusan keuangan, apa saja yang sebaiknya menjadi fokus bagi setiap pasangan dalam bicara uang? Simak tujuh poin berikut.</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:17:44', 'Jack Grecko');
INSERT INTO `posts` VALUES ('12', '10 Detik Menghitung Dana Pensiun', '10-detik-menghitung-dana-pensiun', '<p>Ya benar anda hanya perlu meluangkan waktu sekitar 10 detik untuk mengetahui berapa jumlah total besar uang pensiun yang anda butuhkan ketika anda memasuki usia pensiun di 55 tahun. Bagaimana caranya ? Sangat mudah dan saya akan memandu anda, sekarang anda siapkan data dan alat berikut ini :</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:20:42', 'Jack Grecko');
INSERT INTO `posts` VALUES ('13', 'Investasi Emas atau Saham atau Reksadana', 'investasi-emas-atau-saham-atau-reksadana', '<p>Kalau melihat data keseluruhan dari tahun 2012 hingga tahun 2015 maka kesimpulan kita sangat sederhana yaitu mau investasi apa saja semuanya cenderung menurun cukup signifikan kecuali properti saja yang penurunannya masih relatif sedikit. Dari data inilah saat ini para perencana keuangan juga sudah mulai menurunkan target investasinya. Dulu untuk reksadana saham masih cukup optimis di angka 25% sekarang hanya ditargetkan 20% untuk investasi jangka panjang di atas 10 tahun.</p>', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:20:46', 'Jack Grecko');
INSERT INTO `posts` VALUES ('14', 'Investasi Reksadana – Investasi 100 Ribuan', 'Investasi-Reksadana-Investasi-100-Ribuan-Untuk-Pemula', '<p><strong>Investasi reksadana</strong> merupakan dewa penolong untuk orang yang mau investasi tapi modal terbatas. Nah sebelum kita bicara tentang investasi reksadana mari kita bicara dulu tentang apa itu investasi dan mengapa perlu investasi.</p>\r\n', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:20:52', 'Jack Grecko');
INSERT INTO `posts` VALUES ('15', 'Kejar Target Keuangan di Usia Muda Pakai Cara Ini', 'Kejar-Target-Keuangan-di-Usia-Muda-Pakai-Cara-Ini', '<p><strong>Jakarta</strong> - Di dalam keseharian, seseorang tentunya akan mengalami masa-masa peningkatan. Berawal dari masa kandungan, bayi, anak-anak, remaja, dewasa, berkeluarga, memiliki anak dan cucu, hingga pada saatnya akan meninggal. Tentunya masa-masa tersebut memiliki kondisi dan tantangan yang berbeda satu sama lainnya.<br />', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:20:55', 'Jack Grecko');
INSERT INTO `posts` VALUES ('16', 'Persiapan Dana Untuk Medical Checkup', 'Persiapan Dana-Untuk-Medical-Checkup', '<p><strong>Jakarta</strong> - Di dalam keseharian, seseorang tentunya akan mengalami masa-masa peningkatan. Berawal dari masa kandungan, bayi, anak-anak, remaja, dewasa, berkeluarga, memiliki anak dan cucu, hingga pada saatnya akan meninggal. Tentunya masa-masa tersebut memiliki kondisi dan tantangan yang berbeda satu sama lainnya.<br />', 'fd6f658ea3d8cfe30f88afe20f760ae1.jpg', 'Asuransi Keluarga Lengkap', 'b', '2018-05-27 23:21:16', 'Jack Grecko');

-- ----------------------------
-- Table structure for `profile`
-- ----------------------------
DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotes` text NOT NULL,
  `short` text NOT NULL,
  `desc` text NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of profile
-- ----------------------------
INSERT INTO `profile` VALUES ('1', 'Alangkah mengerikannya menjadi tua dengan kenangan masa muda yang hanya berisi kemacetan jalan, ketakutan datang terlambat ke kantor, tugas-tugas rutin yang tidak menggugah semangat, dan kehidupan seperti mesin, yang hanya akan berakhir dengan pensiun tidak seberapa.', 'Aku mencintaimu. Itu sebabnya aku takkan pernah selesai mendoakan keselamatanmu', 'Barangkali hidup adalah doa yang panjang, dan sunyi adalah minuman keras. ia merasa Tuhan sedang memandangnya dengan curiga', 'JackGrecko');
INSERT INTO `profile` VALUES ('2', 'Aku kira, setiap penulis yang jujur, akhir-kelaknya akan kecewa dan dikecewakan.', 'Aku mencintaimu. Itu sebabnya aku takkan pernah selesai mendoakan keselamatanmu', 'Barangkali hidup adalah doa yang panjang, dan sunyi adalah minuman keras. ia merasa Tuhan sedang memandangnya dengan curiga', 'MojoDraggy');
INSERT INTO `profile` VALUES ('3', 'Orang boleh pandai setinggi langit, tapi selama ia tidak menulis, ia akan hilang di dalam masyarakat dan dari sejarah. Menulis adalah bekerja untuk keabadian.', 'Aku mencintaimu. Itu sebabnya aku takkan pernah selesai mendoakan keselamatanmu', 'Barangkali hidup adalah doa yang panjang, dan sunyi adalah minuman keras. ia merasa Tuhan sedang memandangnya dengan curiga', 'PeterCech');
INSERT INTO `profile` VALUES ('4', 'Dalam hidup kita, cuma satu yang kita punya, yaitu keberanian. Kalau tidak punya itu, lantas apa harga hidup kita ini?', 'Aku mencintaimu. Itu sebabnya aku takkan pernah selesai mendoakan keselamatanmu', 'Barangkali hidup adalah doa yang panjang, dan sunyi adalah minuman keras. ia merasa Tuhan sedang memandangnya dengan curiga', 'Geronimo');

-- ----------------------------
-- Table structure for `videos`
-- ----------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `created_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of videos
-- ----------------------------
INSERT INTO `videos` VALUES ('1', 'Asuransi Jiwa Yang Benar', '<iframe width=\"500\" height=\"300\" src=\"https://www.youtube.com/embed/LDZVTcmOvCg?list=UUnOac3MWao6BRDUZBzw8nVA\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', '2018-02-23 04:12:24', 'Lindsay Sterling');
