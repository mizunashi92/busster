<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Gallery extends CI_Controller {
	public function index() {
		
		$section = "p";
		$slug = FALSE;
		$data['posts'] = $this->Post_model->get_posts($slug,$section);
		//print_r($data['posts']);
		$this->load->view('templates/header');
		$this->load->view('gallery/index',$data);
		$this->load->view('templates/footer');
	}

	public function view($slug = NULL) {

		$section = "p";
		$data['post'] = $this->Post_model->get_posts($slug,$section);
		

		if(empty($data['post'])) {
			show_404();
		}

		$this->load->view('templates/header');
		$this->load->view('gallery/view',$data);
		$this->load->view('templates/footer');

	}
}