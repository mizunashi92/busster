<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Contacts extends CI_Controller {
	public function index($slug = NULL) {
		
		if($this->uri->segment(2) != NULL){

			$slug  = $this->uri->segment(2);
			$data['agent'] = $this->Agent_model->get_agent($slug);
			$data['slug'] = $this->uri->segment(2);

			
		}else{
			$data['agent'] = $this->Agent_model->get_agent($slug);
			$data['slug'] = "contact@sampledomain.com";
			$data['phone'] = "0800 4521 800 50";
			
		}

		$this->load->view('templates/header');
		$this->load->view('contacts/index', $data);
		$this->load->view('templates/footer');
	}
}
