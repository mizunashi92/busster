<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['users'] = 'admin/index';
$route['mypage'] = 'members/mypage';
$route['password'] = 'members/password';	
$route['member'] = 'members/index';	
$route['forgot'] = 'agents/forgot';	
$route['signup'] = 'agents/sign_up';	
$route['contact/(:any)'] = 'contacts/index/$1';
$route['contact'] = 'contacts/index';	
$route['videos'] = 'videos/index';
$route['posts/update'] = 'posts/update';
$route['posts/create'] = 'posts/create';
$route['posts/(:any)'] = 'posts/view/$1';
$route['posts'] = 'posts/index';
$route['articles/(:any)'] = 'pages/view_post/$1';
$route['contents'] = 'contents/index';
$route['default_controller'] = 'pages/view';
$route['(:any)'] = 'pages/view_agent/$1';	
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
