/*
Navicat MySQL Data Transfer

Source Server         : Allianz
Source Server Version : 50516
Source Host           : localhost:3306
Source Database       : u550095972_demo

Target Server Type    : MYSQL
Target Server Version : 50516
File Encoding         : 65001

Date: 2018-02-23 04:47:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `agents`
-- ----------------------------
DROP TABLE IF EXISTS `agents`;
CREATE TABLE `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `real_password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `polis_no` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT 'blank.jpg',
  `valid` tinyint(4) NOT NULL DEFAULT '0',
  `role` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agents
-- ----------------------------
INSERT INTO `agents` VALUES ('1', 'JackGrecko', '$2y$10$cgn7KIIire9TNROz/uJg7.LsndKUT3PQ.iPHaNfUe0DcwTM2pz9oy', 'almukayo', 'Jack Grecko', '100020000', 'jack@gmail.com', '08561215451', 'Jack.jpg', '1', '1');
INSERT INTO `agents` VALUES ('2', 'MojoDraggy', '$2y$10$7XWWaX7wmvPZyxToS5hAyuObLM7FR/Hy/LVhFpk80VaniHr.6SiCu', 'almukayo', 'Mojo Dragfy', '100020001', 'mojo@gmail.com', '08127832738', 'Chamb.jpg', '1', '0');
INSERT INTO `agents` VALUES ('3', 'PeterCech', '$2y$10$xtpfu.As0xC/HYoZh4O2AO/6YPQ8dQ0ES9qOefwF1ls3FvDp.naf6', 'almukayo', 'Peter Cech', '100020002', 'Peter@gmail.com', '08186372632', 'Cech.jpg', '1', '0');

-- ----------------------------
-- Table structure for `ci_sessions`
-- ----------------------------
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ci_sessions
-- ----------------------------

-- ----------------------------
-- Table structure for `posts`
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO `posts` VALUES ('1', 'Kartu Kredit Untuk Anak', 'kartu-kredit-untuk-anak', 'Kartu kredit merupakan alat pembayaran pengganti uang tunai yang mudah dan efisien. Cukup menggesek kartu satu kali, benda idaman sudah menjadi milik Anda. Kini banyak orang tua memercayakan anak-anak mereka untuk menggunakan kartu kredit.\r\n\r\nApakah salah memberi fasilitas kartu kredit pada anak? Kapan saat yang tepat memberikan kartu kredit pada anak?\r\nDi Indonesia, usia minimum seseorang untuk memiliki kartu kredit adalah 21 tahun atau 17 tahun dengan status sudah menikah dan berpenghasilan minimal 3 juta rupiah per bulan. Namun tak jarang kita temui anak berusia belia sudah berbelanja dengan kartu kredit. Kok bisa? Menurut perencana keuangan sekaligus CEO Andreas Hartono Academy, Ir. Andreas Hartono, CHt, CI, CFP, kartu kredit yang digunakan oleh anak merupakan kartu pinjaman dari orang tua. Sah-sah saja meminjamkan kartu kredit pada anak. Namun, ada hal yang harus dipertimbangkan selanjutnya, apakah si anak sudah cukup dewasa untuk menggunakan kartu kredit?\r\n\r\nAnak remaja secara mental sering dianggap labil atau masih belum bisa mengontrol emosi dan keinginan dengan baik. Keadaan tersebut dikhawatirkan akan mempengaruhi cara anak dalam membelanjakan kartu kredit. Andreas mengatakan, kedewasaan dalam mengelola keuangan antara satu anak dengan anak lain mempunyai tingkat yang berbeda-beda. Ada yang berusia belasan akhir namun belum bisa mengelola keuangan pribadinya dengan benar. Ada pula yang masih usia belia tetapi sudah mengerti dan mampu mengatur keuangannya sendiri.', '2018-02-22 00:15:54', 'Lindsay Sterling');
INSERT INTO `posts` VALUES ('2', 'Dana Pensiun', '10-detik-menghitung-dana-pensiun', 'Ya benar anda hanya perlu meluangkan waktu sekitar 10 detik untuk mengetahui berapa jumlah total besar uang pensiun yang anda butuhkan ketika anda memasuki usia pensiun di 55 tahun. Bagaimana caranya ? Sangat mudah dan saya akan memandu anda, sekarang anda siapkan data dan alat berikut ini :', '2018-02-22 00:15:54', 'Lindsay Sterling');
INSERT INTO `posts` VALUES ('3', 'Investasi Emas atau Saham atau Reksadana', 'investasi-emas-atau-saham-atau-reksadana', 'Kalau melihat data keseluruhan dari tahun 2012 hingga tahun 2015 maka kesimpulan kita sangat sederhana yaitu mau investasi apa saja semuanya cenderung menurun cukup signifikan kecuali properti saja yang penurunannya masih relatif sedikit. Dari data inilah saat ini para perencana keuangan juga sudah mulai menurunkan target investasinya. Dulu untuk reksadana saham masih cukup optimis di angka 25% sekarang hanya ditargetkan 20% untuk investasi jangka panjang di atas 10 tahun.', '2018-02-22 00:15:55', 'Lindsay Sterling');
INSERT INTO `posts` VALUES ('4', 'Investasi Reksadana – Investasi 100 Ribuan Untuk Pemula', 'Investasi-Reksadana-Investasi-100-Ribuan-Untuk-Pemula', '<p><strong>Investasi reksadana</strong> merupakan dewa penolong untuk orang yang mau investasi tapi modal terbatas. Nah sebelum kita bicara tentang investasi reksadana mari kita bicara dulu tentang apa itu investasi dan mengapa perlu investasi.</p>\r\n', '2018-02-23 04:04:25', 'Lindsay Sterling');

-- ----------------------------
-- Table structure for `videos`
-- ----------------------------
DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of videos
-- ----------------------------
INSERT INTO `videos` VALUES ('1', 'Asuransi Jiwa Yang Benar', '<iframe width=\"500\" height=\"300\" src=\"https://www.youtube.com/embed/LDZVTcmOvCg?list=UUnOac3MWao6BRDUZBzw8nVA\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', '2018-02-23 04:12:24', 'Lindsay Sterling');
