 <!-- MAIN -->
    <main role="main">
      <!-- Content -->
      <article>
        <header class="section background-dark">
          <div class="line">        
            <h1 class="text-white margin-top-bottom-40 text-size-60 text-line-height-1">Our Products</h1>
            <p class="margin-bottom-0 text-size-16">Kenali berbagai produk kami dan temukan yang sesuai bagi anda.<br>
            Hubungi kami untuk informasi lebih lanjut.</p>
          </div>  
        </header>
        <section class="section background-white">
          <div class="line">
            <h2 class="text-size-40 margin-bottom-30">Produk rekomendasi kami</h2>
            <hr class="break-small background-primary margin-bottom-30">
            <p class="margin-bottom-40">
              Seringkali asuransi menjadi topik yang sulit dimengerti setiap orang, namun pada dasarnya setiap orang membutuhkan proteksi. Oleh karena itu, temui beberapa produk kami yang dibutuhkan banyak orang.
            </p>
          </div>   
          <div class="line text-center">
            <div class="margin">
              <?php
                $i = 1;

                foreach($posts as $post) : 
                 if(($i-1) % 3   == 0){
                    echo "<div class='row'><br>&nbsp;</div> ";
                  }  
                  
              ?>
              <a href="<?php echo site_url('/productpage/'.$user.'/'.$post['section'].'/'.$post['slug']); ?>/">
               <div class="s-12 m-6 l-4 padding">
                <div class="image-with-hover-overlay margin-bottom border-articles">
                  <div class="image-hover-overlay background-new"> 
                    <div class="image-style-articles text-center">
                        <?php if($post['image'] != null){ ?>
                    <div align=center><img src="http://bisnis.financialsecurity.id/assets/products/<?php echo $post['image']; ?>" width="12px"></div>
                  <?php } ?>
                  <br>
                  <p><b><?php echo $post['title'] ?></b></p>
                  
                         </div> 
                  </div> 
                  <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb-02.jpg" alt="" title="Portfolio Image 1" />
                </div>	
              </div>
              </a>
              <?php 
                $i++;
               
                endforeach;
                 
              ?>      
            </div>
          </div>
        </section> 
      </article>
    </main>
    
    <!-- FOOTER -->
    <footer>
      <!-- Contact Us -->
      <div class="background-primary padding text-center">
        <p class="h1">Contact Us: <?php if($agent['phone'] == NULL ){echo $phone;}else{echo $agent['phone'];} ?></p>                                                                
      </div>
      
      <!-- Main Footer -->
      <section class="background-dark full-width">
        <!-- Map -->
        <div class="s-12 m-12 l-6 margin-m-bottom-2x">
          <div class="col-sm-12 grayscale center">     
            <iframe src="<?php if($agent['url']==NULL){echo $url;}else{echo $agent['url'];} ?>" width="100%" height="450" frameborder="0" style="border:0"></iframe>
          </div>
        </div>
        
        <!-- Collumn 2 -->
        <div class="s-12 m-12 l-6 margin-m-bottom-2x">
          <div class="padding-2x">
            <div class="line">              
              <div class="float-left">
                  <i class="icon-sli-location-pin text-primary icon3x"></i>
                </div>
                <div class="margin-left-70 margin-bottom-30">
                  <h3 class="margin-bottom-0">Address</h3>
                 <p><?php if($agent['address'] == NULL ){echo $addon;}else{echo $agent['address'];} ?>
                  </p>        
                </div>
                <div class="float-left">
                  <i class="icon-sli-envelope text-primary icon3x"></i>
                </div>
                <div class="margin-left-70 margin-bottom-30">
                  <h3 class="margin-bottom-0">E-mail</h3>

                  <p><?php if($agent['email'] == NULL ){echo $slug;}else{echo $agent['email'];} ?> <br>           
                </div>
               
             
            </div>
          </div>
        </div>  
      </section>
      <hr class="break margin-top-bottom-0" style="border-color: rgba(0, 38, 51, 0.80);">
      
     