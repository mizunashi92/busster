<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Eleganter - New Amazing HTML5 Template</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/components.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/responsee.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/owl-carousel/owl.theme.css">     
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/template-style.css">
    <link href="<?php echo base_url(); ?>assets/font/font1.css" rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url(); ?>assets/font/font2.css" rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-ui.min.js"></script>      
  </head>
  
  <body class="size-1140">
  	<!-- PREMIUM FEATURES BUTTON -->
  	<a target="_blank" class="hide-s" href="<?php echo base_url(); ?>../template/eleganter-premium-responsive-business-template/" style="position:fixed;top:120px;right:-14px;z-index:10;"><img src="<?php echo base_url(); ?>assets/img/premium-features.png" alt=""></a>
    <!-- HEADER -->
    <header role="banner" class="position-absolute">    
      <!-- Top Navigation -->
      <nav class="background-transparent background-transparent-hightlight full-width sticky">
        <div class="s-12 l-2">
          <a href="<?php echo base_url(); ?>index.html" class="logo">
            <!-- Logo White Version -->
            <img class="logo-white" src="<?php echo base_url(); ?>assets/img/logo.png" alt="">
            <!-- Logo Dark Version -->
            <img class="logo-dark" src="<?php echo base_url(); ?>assets/img/logo-dark.png" alt="">
          </a>
        </div>
        <div class="top-nav s-12 l-10">
          <p class="nav-text"></p>
          <ul class="right chevron">
            <li><a href="<?php echo base_url(); ?>">Home</a></li>
            <li><a href="<?php echo base_url(); ?>productpage">Products</a></li>
            <li><a>Services</a>
              <ul>
                <li><a>Service 1</a>
                  <ul>
                    <li><a>Service 1 A</a></li>
                    <li><a>Service 1 B</a></li>
                  </ul>
                </li>
                <li><a>Service 2</a></li>
              </ul>
            </li>
            <li><a href="<?php echo base_url(); ?>aboutme">About</a></li>
            <li><a href="<?php echo base_url(); ?>gallery">Articles</a></li>
            <li><a href="<?php echo base_url(); ?>contacts">Contact</a></li>
          </ul>
        </div>
      </nav>
    </header>
  