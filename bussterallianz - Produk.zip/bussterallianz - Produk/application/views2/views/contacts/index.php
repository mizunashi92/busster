<h2><?= $title ?></h2>
<?php echo validation_errors(); ?>

<?php echo form_open('contacts/send'); ?>
	<input type="hidden" name="to" value="<?php echo $this->uri->segment(2); ?>">
    <div class="form-group col-lg-6">
      <label>First Name</label>
      <input type="text" class="form-control" placeholder="Enter first name" name="fname" required>
    </div>
    <div class="form-group col-lg-6">
      <label>Last Name</label>
      <input type="text" class="form-control" placeholder="Enter last name" name="lname">
    </div>
    <div class="form-group col-lg-6">
      <label>Email Address</label>
      <input type="email" class="form-control" placeholder="Enter email address" name="email" required>
    </div>
    <div class="form-group col-lg-6">
      <label>Telephone Number</label>
      <input type="text" class="form-control" placeholder="Enter telephone number" name="phone">
    </div>
    <div class="form-group col-lg-6">
      <label>Subject</label>
      <input type="text" class="form-control" placeholder="Enter Subject" name="subject" required>
    </div>
    <div class="form-group col-lg-12">
      <label>Comments:</label>
      <textarea class="form-control" rows="5" id="body" name="body" placeholder="Enter comments" required></textarea>
    </div>
    <div class="form-group col-lg-12">
    <button type="submit" class="btn btn-default">Submit</button>
	</div>
</form>