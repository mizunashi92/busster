<h2> <?= $title; ?> </h2>

<?php echo validation_errors(); ?>

<?php echo form_open_multipart('posts/update'); ?>
	<input type="hidden" name="id" value=" <?php echo $post['id']; ?>">
  <div class="form-group">
    <label>Title</label>
    <input type="text" class="form-control" name="title" placeholder="Add Title" value="<?php echo $post['title']; ?>" required>
  </div>
  <div class="form-group">
    <label>Body</label>
    <textarea id="editor1" class="form-control" name="body" placeholder="Add Body" required><?php echo $post['body']; ?></textarea>
  </div>
  <div class="form-group">
    <label>Section</label>
    <select name="section" class="form-control" required>
      <option value="<?php echo $post['section']; ?>"><?php if($post['section']=="b"){echo "Business";}else{echo"Product";} ?></option>
      <option value="b">Business</option>
      <option value="p">Product</option>
    </select>
  </div>
  <div class="form-group">
    <label>Image</label>
    <input type="hidden" name="image" value="<?= $post['image'];?>">
    <input type="file" name="userfile"  size="20" />
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>