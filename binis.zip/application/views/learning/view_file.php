<h2><?php echo $title; ?></h2>


<small class="post-date">Section <?php echo $files['section']; ?></small><br>
	<div class="col-lg-12 text-center">

		<img src="<?php echo base_url();?>assets/learning/<?php echo $files['img'];?>" width="800px">	<<br>

		

	</div>

<br>

	<div class="col-lg-12 text-center">

		<a href="<?php echo base_url();?>assets/learning/<?php echo $files['file'];?>" class="btn btn-default btn-sm">

			<img src="<?php echo base_url();?>assets/img/download.png">Download here

		</a> 

	</div>

<br>

