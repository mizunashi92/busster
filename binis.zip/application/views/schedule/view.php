<h2><?php echo $post['name']; ?></h2>
<?php if($post['image'] != null){ ?>
       <img src="<?php echo site_url(); ?>assets/schedules/<?php echo $post['image']; ?>" class="imagedropshadow">
      <?php } ?><br>

<small class="post-date">Posted on: <?php echo $post['created_at']; ?></small><br>
<div class="post-body">
	<?php echo $post['desc']; ?>
</div>
