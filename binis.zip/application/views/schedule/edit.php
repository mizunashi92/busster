<h2> <?= $title; ?> </h2>



<?php echo validation_errors(); ?>





<?php echo form_open_multipart('schedule/update'); ?>

  <input type="hidden" name="id" value=" <?php echo $post['id']; ?>">

  <div class="form-group col-lg-12">

    <label>Name</label>

    <input type="text" class="form-control" name="name" placeholder="Add event name, Asian Expo 2019" value="<?php echo $post['name']; ?>" required autofocus>

  </div>

  <div class="form-group col-lg-12">

    <label>Location</label>

    <textarea class="form-control" name="location" placeholder="Add Location, Cyanide and Happiness Street No 7" required><?php echo $post['location']; ?></textarea>

  </div>

  <div class="form-group col-lg-3">

    <label>Date</label>

    <input type="text" class="form-control" name="date" placeholder="Add Date, 02 Jan 2019" value="<?php echo $post['date']; ?>" required autofocus>

  </div>

  <div class="form-group col-lg-12">

    <label>Information</label>

    <textarea class="form-control" name="desc" placeholder="Add information, No Sandal No Drugs and Alcohol"><?php echo $post['desc']; ?></textarea>

  </div>
<div class="form-group col-lg-12">
    <label>Image</label>
    <font size="1"><br>(for best views, upload a landscape oriented photo. Make sure it is less than 1024 x 1024 pixels and no bigger than 2MB)</font>
    <input type="hidden" name="image" value="<?= $post['image'];?>">
    <input type="file" name="userfile"  size="20" />
  </div>

  <div class="form-group col-lg-12">

  <button type="submit" class="btn btn-default">Submit</button>

  </div>

</form>