<h2> <?= $title ?> </h2>

<h3> <?= $title_post ?> </h3>
<?php foreach($posts as $post) : ?>
	<h5><a href="<?php echo site_url('/articles/'.$post['slug']); ?>"><?php echo $post['title']; ?></a></h5>
			
			<?php if($post['image'] != null){ ?>
			 <img src="<?php echo site_url(); ?>assets/posts/<?php echo $post['image']; ?>">
			<?php } ?>

			
			<small class="post-date">Posted on: <?php echo $post['created_at']; ?></small>
			<br>
			<?php echo word_limiter($post['body'],60); ?>
			<small class="post-by"><?php echo $post['created_by']; ?></small>
			<a href="whatsapp://send?text=<?php echo site_url('/articles/'.$post['slug']); ?>" data-action="share/whatsApp/share"><img src="<?php echo site_url(); ?>assets/images/whatsapp.png" width="32px"></a>
			<a href="whatsapp://send?text=http://chillyfacts.com/create-whatsapp-share-button-on-websites" data-action="share/whatsapp/share">Share in Whatsapp</a>
<?php endforeach; ?>

<h3><?php echo $video['title']; ?></h3>
<?php echo $video['url']; ?>